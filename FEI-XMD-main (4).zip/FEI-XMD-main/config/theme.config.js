export default {
  botTitle: "🤖 ꜰᴇɪ xᴍᴅ ʙᴏᴛ",
  menu: {
    top: "╭━━〔 ",
    titleEnd: " 〕━━┈⊷",
    infoLine: "┃ ✫ ",
    itemLine: "┃ ✫✧│ ",
    blankLine: "┃",
    bottom: "╰━━━━━━━━━━━━┈⊷"
  },
  sections: [
    { key: "General", title: "🏠 ɢᴇɴᴇʀᴀʟ", categories: ["General"] },
    {
      key: "AI Chat",
      title: "🧠 ᴀɪ ᴄʜᴀᴛ",
      categories: ["AI & Chat"],
      excludeNames: ["flux", "pollination", "tts", "tts2", "tts3", "tts4", "tts5"]
    },
    {
      key: "AI Media",
      title: "🎨 ᴀɪ ᴍᴇᴅɪᴀ",
      commandNames: ["flux", "pollination", "tts", "tts2", "tts3", "tts4", "tts5", "vn2text"]
    },
    { key: "News Desk", title: "📰 ɴᴇᴡs ᴅᴇsᴋ", categories: ["News"] },
    { key: "Group Tools", title: "👥 ɢʀᴏᴜᴘ ᴛᴏᴏʟs", categories: ["Group"] },
    { key: "Downloads", title: "📥 ᴅᴏᴡɴʟᴏᴀᴅs", categories: ["Downloads"] },
    {
      key: "Fun Games",
      title: "🎮 ғᴜɴ ɢᴀᴍᴇs",
      commandNames: [
        "calc", "poll", "coinflip", "dice", "8ball", "choose",
        "trivia", "riddle", "activity", "pokemon", "wcg", "wrg"
      ]
    },
    {
      key: "Fun Mix",
      title: "🎉 ғᴜɴ ᴍɪx",
      categories: ["Fun"],
      excludeNames: ["calc", "poll", "coinflip", "dice", "8ball", "choose", "trivia", "riddle", "activity", "pokemon"]
    },
    {
      key: "Anime Info",
      title: "🌸 ᴀɴɪᴍᴇ ɪɴғᴏ",
      categories: ["Anime Info", "Anime Rankings"]
    },
    {
      key: "Anime Art",
      title: "🖼 ᴀɴɪᴍᴇ ᴀʀᴛ",
      categories: ["Anime Random", "Anime Tools", "Anime Images"]
    },
    {
      key: "Anime GIFs",
      title: "🎞 ᴀɴɪᴍᴇ ɢɪғs",
      commandNames: [
        "angry", "baka", "bite", "bleh", "blowkiss", "blush", "bonk", "bored", "carry", "clap",
        "confused", "cry", "cuddle", "dance", "facepalm", "feed", "handhold", "handshake", "happy", "highfive"
      ]
    },
    {
      key: "Anime Reactions",
      title: "💞 ᴀɴɪᴍᴇ ʀᴇᴀᴄᴛɪᴏɴs",
      commandNames: [
        "hug", "kabedon", "kick2", "kiss", "lappillow", "laugh", "lurk", "nod", "nom", "nope",
        "nya", "pat", "peck", "poke", "pout", "punch", "run", "salute", "shake", "shoot"
      ]
    },
    {
      key: "Anime Moves",
      title: "⚡ ᴀɴɪᴍᴇ ᴍᴏᴠᴇs",
      commandNames: [
        "shocked", "shrug", "sip", "slap", "sleep", "smile", "smug", "spin", "stare", "tableflip",
        "teehee", "think", "thumbsup", "tickle", "wag", "wave", "wink", "yawn", "yeet"
      ]
    },
    { key: "Canvas Tools", title: "🖼 ᴄᴀɴᴠᴀs ᴛᴏᴏʟs", categories: ["Canvas"] },
    { key: "Media Tools", title: "🛠️ ᴍᴇᴅɪᴀ ᴛᴏᴏʟs", categories: ["Media & Tools"], excludeNames: ["vn2text"] },
    { key: "Chat Privacy", title: "🔒 ᴄʜᴀᴛ ᴘʀɪᴠᴀᴄʏ", categories: ["Chat & Privacy"] },
    { key: "Status Tools", title: "📱 sᴛᴀᴛᴜs ᴛᴏᴏʟs", categories: ["Status", "Presence"] },
    { key: "Owner Tools", title: "👑 ᴏᴡɴᴇʀ ᴛᴏᴏʟs", categories: ["Owner", "Bot Settings"] }
  ]
};
