const digits = value => String(value || "").replace(/\D/g, "");
const ids = value => String(value || "").split(",").map(item => item.trim()).filter(Boolean);
const pairingMethod = String(process.env.PAIRING_METHOD || "terminal").trim().toLowerCase();

export default {
  name: String(process.env.BOT_NAME || "FEI XMD").trim(),
  version: String(process.env.BOT_VERSION || "1.0.0").trim(),
  prefix: String(process.env.PREFIX || ".").trim() || ".",
  ownerName: String(process.env.OWNER_NAME || "Benfei Tech").trim(),
  ownerNumber: digits(process.env.OWNER_NUMBER || "2348169155634").trim(),
  defaultMode: "public",
  pairingMethod: pairingMethod === "telegram" ? "telegram" : "terminal",
  telegramToken: String(process.env.TELEGRAM_BOT_TOKEN || "").trim(),
  telegramAllowedUserIds: ids(process.env.TELEGRAM_ALLOWED_USER_IDS),
  channel: {
    name: "𝐁𝐄𝐍𝐅𝐄𝐈 𝐓𝐄𝐂𝐇™",
    // This JID enables WhatsApp's native View channel attribution.
    jid: "120363413231189335@newsletter"
  },
  // Replace with your own image URL, or use an empty string to disable menu imagery.
  imageUrl: "https://res.cloudinary.com/dqqyvozdw/image/upload/v1792360232/v4sflvek2dkoljg2mvhz.jpg",
  maxAppendAgeMs: 120000
};
