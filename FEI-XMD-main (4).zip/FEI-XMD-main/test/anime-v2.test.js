import test from "node:test";
import assert from "node:assert/strict";
import animeCommands, {
  ANIME_COMMAND_NAMES,
  ANIME_REACTION_NAMES,
  cleanAnimeText
} from "../commands/anime-v2.js";
import { loadCommands } from "../handlers/command-loader.js";

test("anime pack contains the info, ranking, random, tool, image, and reaction commands", () => {
  assert.ok(animeCommands.length >= 95, "Expected the full anime command collection");
  assert.equal(new Set(ANIME_COMMAND_NAMES).size, ANIME_COMMAND_NAMES.length, "Anime command names must be unique");
  assert.equal(ANIME_REACTION_NAMES.length, 59);
  for (const command of animeCommands) {
    assert.equal(typeof command.name, "string");
    assert.equal(typeof command.run, "function");
    assert.ok(command.category);
    assert.ok(command.description);
  }
});

test("existing commands are preserved and the anime waifu image uses a versioned name", async () => {
  const { lookup } = await loadCommands();
  assert.equal(lookup.get("waifu").name, "waifu");
  assert.equal(lookup.get("waifu2").name, "waifu2");
  assert.equal(lookup.get("kick").name, "kick");
  assert.equal(lookup.get("kick2").name, "kick2");
  for (const name of ["anime", "manga", "animequote", "whatanime", "animehelp", "animemenu", "waifu2", "kick2"]) {
    assert.ok(lookup.has(name), "Missing ." + name);
  }
});

test("all anime v2 commands load without duplicate names or aliases", async () => {
  const { lookup, commands } = await loadCommands();
  for (const name of ANIME_COMMAND_NAMES) {
    assert.ok(lookup.has(name), "Missing command: " + name);
    assert.equal(lookup.get(name).name, name);
    assert.equal(commands.filter(command => command.name === name).length, 1);
  }
});

test("anime descriptions hide AniList spoiler tags and decode HTML", () => {
  assert.equal(cleanAnimeText("Line<br>Two &amp; Three ~!secret reveal!~"), "Line Two & Three [spoiler hidden]");
  assert.equal(cleanAnimeText("<b>Hidden</b> text", 8), "Hidden…");
});
