import test from "node:test";
import assert from "node:assert/strict";
import { getViewOnceEmojiCommand, getViewOnceReplyEmojiCommand, hasViewOnceWrapperDeep, isVv2EmojiShortcut } from "../lib/view-once-shortcuts.js";

test("vv emoji aliases target the current chat, not the DM", () => {
  for (const emoji of ["😎", "😏", "🥰"]) {
    assert.equal(getViewOnceEmojiCommand(emoji), "vv");
    assert.equal(getViewOnceEmojiCommand("." + emoji, "."), "vv");
  }
});

test("the existing vv2 emoji shortcuts still target the bot DM", () => {
  for (const emoji of ["❤️", "💙", "😊", "🫣", "👍"]) {
    assert.equal(getViewOnceEmojiCommand(emoji), "vv2");
    assert.equal(getViewOnceEmojiCommand("." + emoji, "."), "vv2");
    assert.equal(isVv2EmojiShortcut(emoji), true);
  }
});

test("view-once emoji aliases only resolve when the emoji is sent as a reply", () => {
  for (const emoji of ["😎", "😏", "🥰", "❤️", "💙", "😊", "🫣", "👍"]) {
    assert.equal(getViewOnceReplyEmojiCommand(emoji, null), null);
    assert.equal(getViewOnceReplyEmojiCommand(emoji, {}), null);
    assert.equal(getViewOnceReplyEmojiCommand(emoji, { stanzaId: "quoted-message-id" }),
      ["😎", "😏", "🥰"].includes(emoji) ? "vv" : "vv2");
  }
});

test("emoji matching accepts WhatsApp variation-selector differences", () => {
  assert.equal(getViewOnceEmojiCommand("❤"), "vv2");
  assert.equal(getViewOnceEmojiCommand("❤️"), "vv2");
});

test("view-once detection handles wrapped, nested, and flattened quoted media", () => {
  assert.equal(hasViewOnceWrapperDeep({ ephemeralMessage: { message: { viewOnceMessageV2: { message: { imageMessage: {} } } } } }), true);
  assert.equal(hasViewOnceWrapperDeep({ imageMessage: { viewOnce: true, mediaKey: Buffer.from([1, 2]) } }), true);
  assert.equal(hasViewOnceWrapperDeep({ imageMessage: { caption: "ordinary image" } }), false);
});
