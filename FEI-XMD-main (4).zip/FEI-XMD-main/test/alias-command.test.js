import test from "node:test";
import assert from "node:assert/strict";
import config from "../config/bot.config.js";
import theme from "../config/theme.config.js";
import { buildMenu } from "../lib/menu.js";
import { loadCommands } from "../handlers/command-loader.js";

const GROUP = "120363000000000000@g.us";
const ADMIN = "2348000000001@s.whatsapp.net";
const BOT = "2348000000000@s.whatsapp.net";
const MEMBER = "2348000000002@s.whatsapp.net";

test(".alias lists hidden aliases, emoji shortcuts, and their functions", async () => {
  const { commands, lookup } = await loadCommands();
  const command = lookup.get("alias");
  assert.ok(command, ".alias should be registered");

  let output = "";
  await command.run({
    commands,
    config: { prefix: "." },
    reply: async text => { output = String(text); }
  });

  for (const expected of [
    "👋 / .👋 (type in a group or react to a group message) → .hidetag",
    "💯 / 🙂 → .save",
    "😎 / 😏 / 🥰 → .vv",
    "❤️ / 💙 / 😊 / 🫣 / 👍 → .vv2",
    "connected WhatsApp account's own DM",
    "current chat",
    "your DM with the bot",
    "not as WhatsApp reactions"
  ]) {
    assert.ok(output.includes(expected), ".alias output is missing: " + expected);
  }

  const menu = buildMenu({
    pushName: "Tester",
    mode: "public",
    connected: true,
    config,
    theme,
    commands
  });
  assert.ok(menu.includes("┃ ✫✧│ .alias"), ".alias should be discoverable in the main menu");
});

test(".tag sends its mention message without newsletter attribution", async () => {
  const { lookup } = await loadCommands();
  const command = lookup.get("tag");
  assert.ok(command);

  const sent = [];
  const replies = [];
  const ctx = {
    command: "tag",
    args: "",
    jid: GROUP,
    senderJid: ADMIN,
    owner: true,
    sock: {
      user: { id: BOT },
      groupMetadata: async () => ({
        id: GROUP,
        subject: "Test group",
        participants: [
          { id: ADMIN, admin: "admin" },
          { id: BOT, admin: "admin" },
          { id: MEMBER }
        ]
      })
    },
    reply: async (...args) => { replies.push(args); },
    send: async (...args) => { sent.push(args); }
  };

  await command.run(ctx);

  assert.equal(sent.length, 1);
  assert.equal(sent[0][1], true, "the command should still quote the triggering message");
  assert.equal(sent[0][2], false, "newsletter attribution must be explicitly disabled");
  assert.ok(Array.isArray(sent[0][0].mentions));
  assert.equal(sent[0][0].contextInfo?.forwardedNewsletterMessageInfo, undefined);
  assert.equal(replies.length, 0);
});
