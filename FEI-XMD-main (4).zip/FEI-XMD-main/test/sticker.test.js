import test from "node:test";
import assert from "node:assert/strict";
import { loadCommands } from "../handlers/command-loader.js";

test("sticker is a real command and gives usage guidance when no media is supplied", async () => {
  const { lookup } = await loadCommands();
  const command = lookup.get("sticker");
  assert.ok(command, "sticker should be registered");
  assert.equal(command.description.includes("Convert an image"), true);

  const replies = [];
  await command.run({
    jid: "2348000000000@s.whatsapp.net",
    args: "",
    config: { prefix: "." },
    msg: { key: { remoteJid: "2348000000000@s.whatsapp.net" }, message: { conversation: ".sticker" } },
    sock: {},
    reply: async text => replies.push(String(text))
  });

  assert.equal(replies.length, 1);
  assert.match(replies[0], /send an image or video|reply to an image\/video/i);
});


test("sticker refuses quoted view-once media without trying to download it", async () => {
  const { lookup } = await loadCommands();
  const command = lookup.get("sticker");
  const replies = [];
  const ctx = {
    jid: "2348000000000@s.whatsapp.net",
    args: "",
    config: { prefix: "." },
    msg: {
      key: { remoteJid: "2348000000000@s.whatsapp.net", id: "command-2" },
      message: {
        extendedTextMessage: {
          text: ".sticker",
          contextInfo: {
            stanzaId: "quoted-view-once",
            quotedMessage: {
              viewOnceMessage: {
                message: { imageMessage: { mimetype: "image/jpeg" } }
              }
            }
          }
        }
      }
    },
    sock: {},
    reply: async text => replies.push(String(text))
  };

  await command.run(ctx);
  assert.equal(replies.length, 1);
  assert.match(replies[0], /view-once media cannot be converted/i);
});
