import test from "node:test";
import assert from "node:assert/strict";
import config from "../config/bot.config.js";
import { POWERED_FOOTER } from "../lib/api-client.js";
import { withChannelAttribution } from "../lib/channel.js";
import { buildViewOnceCaption, viewOncePayload } from "../commands/custom/vv.js";

test("vv confirmation keeps the original caption and ends with the styled Benfei Tech footer", () => {
  const caption = buildViewOnceCaption({
    media: { caption: "Original media caption" }
  });

  assert.ok(caption.startsWith("Media extracted from view-once successfully ✅"));
  assert.ok(caption.includes("Original media caption"));
  assert.ok(caption.endsWith(POWERED_FOOTER));
});

test("vv confirmation caption stays within the WhatsApp media-caption limit and keeps its footer", () => {
  const caption = buildViewOnceCaption({
    media: { caption: "A".repeat(3000) }
  });

  assert.ok(caption.length <= 1024);
  assert.ok(caption.endsWith(POWERED_FOOTER));
});

test("view-once media payload includes the configured newsletter attribution", () => {
  const payload = withChannelAttribution(
    config,
    {
      image: Buffer.from("sample-media"),
      caption: "Media extracted from view-once successfully ✅"
    },
    true
  );

  assert.equal(
    payload.contextInfo.forwardedNewsletterMessageInfo.newsletterJid,
    config.channel.jid
  );
  assert.equal(
    payload.contextInfo.forwardedNewsletterMessageInfo.newsletterName,
    config.channel.name
  );
});

test("vv2 media payload stays unbranded and preserves audio settings", () => {
  const buffer = Buffer.from("sample-audio");
  const payload = viewOncePayload({
    kind: "audio",
    buffer,
    media: { mimetype: "audio/ogg; codecs=opus", ptt: true }
  });

  assert.equal(payload.audio, buffer);
  assert.equal(payload.mimetype, "audio/ogg; codecs=opus");
  assert.equal(payload.ptt, true);
  assert.equal(payload.caption, undefined);
});
