import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createSessionManager } from "../lib/session-manager.js";

async function withTempDirectory(run) {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "fei-xmd-sessions-test-"));
  try {
    await run(directory);
  } finally {
    await fs.rm(directory, { recursive: true, force: true });
  }
}

test("session manager routes first pairing to the existing primary account", async () => {
  await withTempDirectory(async dataDirectory => {
    const requested = [];
    const manager = createSessionManager({
      dataDirectory,
      maxSessions: 2,
      getPrimaryStatus: () => ({
        phoneNumber: "",
        paired: false,
        connected: false,
        status: "awaiting-pairing"
      }),
      requestPrimaryPairingCode: async phone => {
        requested.push(phone);
        return "ABCD1234";
      },
      deletePrimarySession: async () => {}
    });

    try {
      await manager.start();
      const code = await manager.requestPairingCode("2348012345678");
      assert.equal(code, "ABCD1234");
      assert.deepEqual(requested, ["2348012345678"]);
      const sessions = await manager.getSessions();
      assert.equal(sessions.length, 1);
      assert.equal(sessions[0].label, "primary");
      assert.equal(sessions[0].phoneNumber, "2348012345678", "the pending primary number should be visible");
      assert.equal(sessions[0].status, "awaiting pairing");
    } finally {
      await manager.stop();
    }
  });
});

test("session manager blocks a different number while primary pairing is pending", async () => {
  await withTempDirectory(async dataDirectory => {
    const manager = createSessionManager({
      dataDirectory,
      maxSessions: 2,
      getPrimaryStatus: () => ({ paired: false, connected: false, status: "awaiting-pairing" }),
      requestPrimaryPairingCode: async () => "ABCD1234",
      deletePrimarySession: async () => {}
    });

    try {
      await manager.start();
      await manager.requestPairingCode("2348012345678");
      await assert.rejects(
        manager.requestPairingCode("2348098765432"),
        /pairing request is already waiting/i
      );
    } finally {
      await manager.stop();
    }
  });
});

test("session manager respects the configured total-session limit", async () => {
  await withTempDirectory(async dataDirectory => {
    const manager = createSessionManager({
      dataDirectory,
      maxSessions: 1,
      getPrimaryStatus: () => ({
        phoneNumber: "2348012345678",
        paired: true,
        connected: true,
        status: "connected"
      }),
      requestPrimaryPairingCode: async () => "should-not-run",
      deletePrimarySession: async () => {}
    });

    try {
      await manager.start();
      await assert.rejects(
        manager.requestPairingCode("2348098765432"),
        /session limit reached/i
      );
    } finally {
      await manager.stop();
    }
  });
});

test("session manager can remove the primary account by its phone number", async () => {
  await withTempDirectory(async dataDirectory => {
    let deleted = false;
    const manager = createSessionManager({
      dataDirectory,
      maxSessions: 2,
      getPrimaryStatus: () => ({
        phoneNumber: "2348012345678",
        paired: true,
        connected: true,
        status: "connected"
      }),
      requestPrimaryPairingCode: async () => "unused",
      deletePrimarySession: async () => { deleted = true; }
    });

    try {
      await manager.start();
      const result = await manager.deleteSession("2348012345678");
      assert.equal(deleted, true);
      assert.match(result, /primary session disconnected/i);
    } finally {
      await manager.stop();
    }
  });
});
