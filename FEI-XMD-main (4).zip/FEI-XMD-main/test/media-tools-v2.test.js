import test from "node:test";
import assert from "node:assert/strict";
import { createMediaToolsV2Commands } from "../commands/media-tools-v2.js";
import { POWERED_FOOTER } from "../lib/api-client.js";

function context(name, args) {
  const sent = [];
  const replies = [];
  return {
    sent,
    replies,
    ctx: {
      command: name,
      args,
      config: { prefix: "." },
      send: async (...values) => { sent.push(values); },
      reply: async (...values) => { replies.push(values); }
    }
  };
}

function findCommand(commands, name) {
  const command = commands.find(item => item.name === name);
  assert.ok(command, "missing command " + name);
  return command;
}

test("Flux and Pollination return images with powered footer and newsletter attribution", async () => {
  const calls = [];
  const commands = createMediaToolsV2Commands({
    requestJson: async (url, params) => {
      calls.push({ url, params });
      if (url.endsWith("/ai/pollination2")) return { success: true, data: { imageUrl: "https://image.pollinations.ai/prompt/flux-image" } };
      if (url.endsWith("/ai/polination")) return { success: true, result: { url: "https://image.pollinations.ai/prompt/pollination-image" } };
      throw new Error("Unexpected endpoint " + url);
    }
  });

  for (const [name, endpoint, params] of [
    ["flux", "/ai/pollination2", { action: "generate", prompt: "a cat", model: "flux", format: "jpg", safe: "true" }],
    ["pollination", "/ai/polination", { action: "generate", prompt: "a cat", shape: "square" }]
  ]) {
    const { ctx, sent } = context(name, "a cat");
    await findCommand(commands, name).run(ctx);
    assert.equal(sent.length, 1);
    assert.ok(sent[0][0].image.url.startsWith("https://image.pollinations.ai/"));
    assert.ok(sent[0][0].caption.includes(POWERED_FOOTER));
    assert.equal(sent[0][2], true, "generated image should carry newsletter attribution");
    assert.equal(calls.at(-1).url.endsWith(endpoint), true);
    assert.deepEqual(calls.at(-1).params, params);
  }
});

test("TikTok stalk formats profile statistics and attaches branding to the avatar", async () => {
  const calls = [];
  const commands = createMediaToolsV2Commands({
    requestJson: async (url, params) => {
      calls.push({ url, params });
      return {
        creator: "Zell API",
        user: {
          id: "6758547229869769734",
          uniqueId: "benfei",
          nickname: "Ben Fei",
          verified: false,
          privateAccount: false,
          avatarLarger: "https://p16-common-sign.tiktokcdn-us.com/avatars/profile.jpeg"
        },
        stats: { followerCount: 2, followingCount: 0, heartCount: 0, videoCount: 0 }
      };
    }
  });
  const { ctx, sent } = context("tiktokstalk", "@benfei");
  await findCommand(commands, "tiktokstalk").run(ctx);
  assert.equal(calls[0].url, "https://zellapi.autos/stalk/tiktok");
  assert.deepEqual(calls[0].params, { username: "benfei" });
  assert.ok(sent[0][0].image.url.includes("tiktokcdn-us.com"));
  assert.match(sent[0][0].caption, /@benfei/);
  assert.match(sent[0][0].caption, /Followers: 2/);
  assert.ok(sent[0][0].caption.includes(POWERED_FOOTER));
  assert.equal(sent[0][2], true);
});

test("lyrics provides metadata, source link and a short excerpt rather than a full lyric dump", async () => {
  const lyrics = "A".repeat(1000);
  const commands = createMediaToolsV2Commands({
    requestJson: async () => ({
      success: true,
      found: true,
      title: "Safe Haven",
      artist: "Omah Lay",
      url: "https://www.azlyrics.com/lyrics/omahlay/safehaven.html",
      lyrics
    })
  });
  const { ctx, sent } = context("lyrics", "safe haven");
  await findCommand(commands, "lyrics").run(ctx);
  const text = sent[0][0].text;
  assert.match(text, /Safe Haven/);
  assert.match(text, /Omah Lay/);
  assert.ok(text.includes("Lyrics page: https://www.azlyrics.com/"));
  assert.ok(text.includes("Excerpt: “" + "A".repeat(90) + "…”"));
  assert.ok(text.includes(POWERED_FOOTER));
  assert.equal(sent[0][2], true);
});
