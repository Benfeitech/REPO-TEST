import test from "node:test";
import assert from "node:assert/strict";
import { cleanNewsText, parseNewsFeed, NEWS_SOURCES } from "../commands/news.js";

test("the news menu defines all 14 configured sources with feed and fallback URLs", () => {
  assert.equal(Object.keys(NEWS_SOURCES).length, 14);
  for (const source of Object.values(NEWS_SOURCES)) {
    assert.match(source.feedUrl, /^https?:\/\//);
    assert.match(source.homeUrl, /^https?:\/\//);
  }
});

test("RSS headlines extract titles, summaries, dates, and links", () => {
  const xml = "<?xml version=\"1.0\"?><rss><channel><item>" +
    "<title><![CDATA[Headline &amp; update]]></title>" +
    "<link>https://news.example/story/1</link>" +
    "<description><![CDATA[<p>A short <strong>summary</strong> &amp; details.</p>]]></description>" +
    "<pubDate>Tue, 13 Oct 2026 12:00:00 GMT</pubDate>" +
    "</item><item><title>Second story</title><link>https://news.example/story/2</link></item></channel></rss>";
  const articles = parseNewsFeed(xml, "https://news.example/feed.xml", 5);

  assert.equal(articles.length, 2);
  assert.equal(articles[0].title, "Headline & update");
  assert.equal(articles[0].summary, "A short summary & details.");
  assert.match(articles[0].date, /13 Oct 2026/);
  assert.equal(articles[0].link, "https://news.example/story/1");
  assert.equal(articles[1].title, "Second story");
});

test("Atom entries support namespaced tags and alternate links", () => {
  const xml = "<feed xmlns=\"http://www.w3.org/2005/Atom\">" +
    "<entry><title>Atom headline</title>" +
    "<link rel=\"self\" href=\"https://news.example/api/1\"/>" +
    "<link rel=\"alternate\" href=\"/story/atom-1\"/>" +
    "<updated>2026-10-14T01:00:00Z</updated><summary>Atom summary</summary></entry></feed>";
  const articles = parseNewsFeed(xml, "https://news.example/feed.xml", 3);

  assert.equal(articles.length, 1);
  assert.equal(articles[0].title, "Atom headline");
  assert.equal(articles[0].link, "https://news.example/story/atom-1");
  assert.equal(articles[0].summary, "Atom summary");
});

test("news text cleans HTML and truncates long fields", () => {
  assert.equal(cleanNewsText("<p>Hello <b>world</b> &amp; friends</p>"), "Hello world & friends");
  assert.equal(cleanNewsText("abcdefghij", 6), "abcde…");
});

test("news parser respects the requested story limit and rejects unsafe link schemes", () => {
  const xml = "<rss><channel>" +
    "<item><title>One</title><link>javascript:alert(1)</link></item>" +
    "<item><title>Two</title><link>https://news.example/2</link></item>" +
    "<item><title>Three</title><link>https://news.example/3</link></item>" +
    "</channel></rss>";
  const articles = parseNewsFeed(xml, "https://news.example/feed.xml", 2);

  assert.equal(articles.length, 2);
  assert.equal(articles[0].link, "");
  assert.equal(articles[1].link, "https://news.example/2");
});
