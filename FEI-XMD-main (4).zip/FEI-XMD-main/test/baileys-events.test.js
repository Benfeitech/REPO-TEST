import test from "node:test";
import assert from "node:assert/strict";
import { getChatSettings, setChatSetting } from "../lib/feature-state.js";
import {
  handleIncomingFeatureMessage,
  handleDeletedMessages,
  handleMessageUpdates,
  downloadOriginalMedia
} from "../lib/baileys-events.js";

const CHAT = "120000000000000@s.whatsapp.net";
const SENDER = "2348012345678@s.whatsapp.net";

function message(id, text) {
  return {
    key: { remoteJid: CHAT, participant: SENDER, id, fromMe: false },
    message: { conversation: text },
    messageTimestamp: Math.floor(Date.now() / 1000)
  };
}

test("view-once media is streamed from the inner media payload before generic fallback", async () => {
  const imageMessage = {
    url: "https://media.example.invalid/encrypted-image",
    mediaKey: Buffer.from([1, 2, 3]),
    mimetype: "image/jpeg"
  };
  const original = {
    key: { remoteJid: CHAT, participant: SENDER, id: "view-once-download-1", fromMe: false },
    message: {
      ephemeralMessage: {
        message: { viewOnceMessageV2: { message: { imageMessage } } }
      }
    }
  };
  const sock = { updateMediaMessage: async message => message };
  let receivedMedia;
  let receivedType;
  let fallbackCalled = false;
  const streamDownloader = async (media, type) => {
    receivedMedia = media;
    receivedType = type;
    return (async function* () {
      yield Buffer.from("cached-");
      yield Buffer.from("view-once-media");
    })();
  };
  const downloaded = await downloadOriginalMedia(sock, original, async () => {
    fallbackCalled = true;
    return Buffer.from("fallback");
  }, streamDownloader);

  assert.equal(receivedMedia, imageMessage);
  assert.equal(receivedType, "image");
  assert.equal(fallbackCalled, false);
  assert.equal(downloaded.toString(), "cached-view-once-media");
});

test("directly flagged view-once media uses the view-once streaming path", async () => {
  const imageMessage = {
    url: "https://media.example.invalid/flagged-view-once-image",
    mediaKey: Buffer.from([4, 5, 6]),
    mimetype: "image/jpeg",
    viewOnce: true
  };
  const original = {
    key: { remoteJid: CHAT, participant: SENDER, id: "view-once-flagged-1", fromMe: false },
    message: { imageMessage }
  };
  let streamed = false;
  const downloaded = await downloadOriginalMedia(
    { updateMediaMessage: async message => message },
    original,
    async () => { throw new Error("Generic downloader should not be used for flagged view-once media."); },
    async (media, type) => {
      streamed = media === imageMessage && type === "image";
      return (async function* () { yield Buffer.from("flagged-view-once-bytes"); })();
    }
  );
  assert.equal(streamed, true);
  assert.equal(downloaded.toString(), "flagged-view-once-bytes");
});


test("status auto-view reads incoming statuses and reacts once with the original key and phone JIDs", async () => {
  const old = await getChatSettings("global");
  const sent = [];
  const read = [];
  const sock = {
    user: { id: "2348000000000:4@s.whatsapp.net", lid: "4444000000000@lid" },
    sendMessage: async (...args) => {
      sent.push(args);
      return { key: { remoteJid: args[0], id: "status-reaction-send" } };
    },
    relayMessage: async () => { throw new Error("Status reactions should use sendMessage's native react wrapper."); },
    readMessages: async keys => { read.push(keys); }
  };
  const status = {
    key: {
      remoteJid: "status@broadcast",
      participant: "4444000000000@lid",
      participantPn: SENDER,
      id: "contact-status-relay-1",
      fromMe: false
    },
    message: { imageMessage: { caption: "A contact status" } }
  };
  await setChatSetting("global", "autoview", false);
  await setChatSetting("global", "statusreact", true);
  await setChatSetting("global", "statusreactmode", "🔥");
  await setChatSetting("global", "statusreactkeys", []);
  try {
    await handleIncomingFeatureMessage(sock, status, { prefix: "." });
    await handleIncomingFeatureMessage(sock, status, { prefix: "." });
    assert.equal(read.length, 2);
    assert.equal(sent.length, 1);
    assert.equal(sent[0][0], "status@broadcast");
    assert.equal(sent[0][1].react.text, "🔥");
    assert.equal(sent[0][1].react.key, status.key, "the original status key must be passed through unchanged");
    assert.deepEqual(sent[0][2], {
      statusJidList: [SENDER, "2348000000000@s.whatsapp.net"]
    });
    assert.ok(sent[0][2].statusJidList.every(jid => jid.endsWith("@s.whatsapp.net")));
    assert.ok(!sent[0][2].statusJidList.includes("status@broadcast"));
    assert.ok(!sent[0][2].statusJidList.some(jid => jid.endsWith("@lid")));
  } finally {
    await setChatSetting("global", "autoview", Boolean(old.autoview));
    await setChatSetting("global", "statusreact", Boolean(old.statusreact));
    await setChatSetting("global", "statusreactmode", old.statusreactmode || "random");
    await setChatSetting("global", "statusreactkeys", Array.isArray(old.statusreactkeys) ? old.statusreactkeys : []);
  }
});

test("status auto-react resolves an LID sender through Baileys and refuses LID-only recipient lists", async () => {
  const old = await getChatSettings("global");
  const sent = [];
  const status = {
    key: {
      remoteJid: "status@broadcast",
      participant: "5555000000000@lid",
      id: "contact-status-lid-map-1",
      fromMe: false
    },
    message: { conversation: "Status without participantPn" }
  };
  const sock = {
    user: { id: "2348000000000@s.whatsapp.net" },
    signalRepository: {
      lidMapping: {
        getPNForLID: async lid => lid === "5555000000000@lid" ? "2348111222333@s.whatsapp.net" : null
      }
    },
    sendMessage: async (...args) => { sent.push(args); return {}; },
    readMessages: async () => {}
  };
  await setChatSetting("global", "statusreact", true);
  await setChatSetting("global", "statusreactmode", "💯");
  await setChatSetting("global", "statusreactkeys", []);
  try {
    await handleIncomingFeatureMessage(sock, status, { prefix: "." });
    assert.equal(sent.length, 1);
    assert.deepEqual(sent[0][2], {
      statusJidList: ["2348111222333@s.whatsapp.net", "2348000000000@s.whatsapp.net"]
    });
    assert.equal(sent[0][1].react.key, status.key);
  } finally {
    await setChatSetting("global", "statusreact", Boolean(old.statusreact));
    await setChatSetting("global", "statusreactmode", old.statusreactmode || "random");
    await setChatSetting("global", "statusreactkeys", Array.isArray(old.statusreactkeys) ? old.statusreactkeys : []);
  }
});

test("anti-delete handles both delete events and revoke update stubs; anti-edit reads nested editedMessage payloads", async () => {
  const sent = [];
  const sock = {
    sendMessage: async (jid, content) => {
      sent.push({ jid, content });
      return { key: { remoteJid: jid, id: "test-output" } };
    },
    sendPresenceUpdate: async () => {}
  };

  await setChatSetting(CHAT, "antidel", true);
  await setChatSetting(CHAT, "antiedit", true);

  try {
    const viaDeleteEvent = message("delete-event-1", "Original text deleted");
    await handleIncomingFeatureMessage(sock, viaDeleteEvent, { prefix: "." });
    await handleDeletedMessages(sock, { keys: [{ remoteJid: CHAT, id: viaDeleteEvent.key.id }] });
    assert.ok(sent.some(item => item.content.text && item.content.text.includes("Original text deleted")),
      "messages.delete should report the cached text");

    const viaRevokeUpdate = message("delete-update-1", "Text deleted through revoke update");
    await handleIncomingFeatureMessage(sock, viaRevokeUpdate, { prefix: "." });
    await handleMessageUpdates(sock, [{
      key: { remoteJid: CHAT, id: viaRevokeUpdate.key.id, participant: SENDER },
      update: { message: null, messageStubType: 1 }
    }]);
    assert.ok(sent.some(item => item.content.text && item.content.text.includes("Text deleted through revoke update")),
      "REVOKE messageStubType updates should use anti-delete handling");

    const edited = message("edit-update-1", "Original message before edit");
    await handleIncomingFeatureMessage(sock, edited, { prefix: "." });
    await handleMessageUpdates(sock, [{
      key: { remoteJid: CHAT, id: edited.key.id, participant: SENDER },
      update: { message: { editedMessage: { message: { conversation: "Revised message after edit" } } } }
    }]);
    const alert = sent.find(item => item.content.text && item.content.text.includes("Revised message after edit"));
    assert.ok(alert, "MESSAGE_EDIT payload should report the updated text");
    assert.ok(alert.content.text.includes("Original message before edit"), "edit alert should preserve the original text");
  } finally {
    await setChatSetting(CHAT, "antidel", false);
    await setChatSetting(CHAT, "antiedit", false);
  }
});

test("anti-delete routes group deletions to bot DM for dm and to both destinations for both", async () => {
  const GROUP = "120363000000000000@g.us";
  const GROUP_SENDER = "2348012345678@s.whatsapp.net";
  const SELF_DM = "2348000000000@s.whatsapp.net";
  const SELF_DEVICE_JID = "2348000000000:4@s.whatsapp.net";
  const oldGlobal = await getChatSettings("global");
  const oldGroup = await getChatSettings(GROUP);
  const sent = [];
  const sock = {
    user: { id: SELF_DEVICE_JID },
    sendMessage: async (jid, content) => {
      sent.push({ jid, content });
      return { key: { remoteJid: jid, id: "test-output" } };
    }
  };

  const makeGroupMessage = (id, text) => ({
    ...message(id, text),
    key: { ...message(id, text).key, remoteJid: GROUP, participant: GROUP_SENDER }
  });

  try {
    await setChatSetting(GROUP, "antidel", true);
    await setChatSetting("global", "deltarget", "dm");

    const dmOnly = makeGroupMessage("route-dm-only", "DM-only deleted text");
    await handleIncomingFeatureMessage(sock, dmOnly, { prefix: "." });
    await handleDeletedMessages(sock, { keys: [{ remoteJid: GROUP, id: dmOnly.key.id }] });

    assert.ok(sent.some(item => item.jid === SELF_DM && String(item.content.text || item.content.caption || "").includes("DM-only deleted text")),
      "deltarget=dm should deliver to the normalized bot account DM JID");
    assert.ok(!sent.some(item => item.jid === GROUP),
      "deltarget=dm should not send the alert back to the original group");

    sent.length = 0;
    await setChatSetting("global", "deltarget", "both");
    const both = makeGroupMessage("route-both", "Both-destinations deleted text");
    await handleIncomingFeatureMessage(sock, both, { prefix: "." });
    await handleDeletedMessages(sock, { keys: [{ remoteJid: GROUP, id: both.key.id }] });

    assert.ok(sent.some(item => item.jid === GROUP && String(item.content.text || item.content.caption || "").includes("Both-destinations deleted text")),
      "deltarget=both should send the alert to the original group");
    assert.ok(sent.some(item => item.jid === SELF_DM && String(item.content.text || item.content.caption || "").includes("Both-destinations deleted text")),
      "deltarget=both should also deliver the alert to the bot account's own DM");
  } finally {
    await setChatSetting(GROUP, "antidel", Boolean(oldGroup.antidel));
    await setChatSetting("global", "deltarget", oldGlobal.deltarget || "chat");
  }
});



test("anti-delete tracks group originals when global delivery targets dm or both", async () => {
  const GROUP = "120363000000000000@g.us";
  const GROUP_SENDER = "2348012345678@s.whatsapp.net";
  const SELF_DM = "2348000000000@s.whatsapp.net";
  const SELF_DEVICE_JID = "2348000000000:4@s.whatsapp.net";
  const oldGlobal = await getChatSettings("global");
  const oldGroup = await getChatSettings(GROUP);
  const sent = [];
  const sock = {
    user: { id: SELF_DEVICE_JID },
    sendMessage: async (jid, content) => {
      sent.push({ jid, content });
      return { key: { remoteJid: jid, id: "group-global-target-test" } };
    }
  };

  try {
    await setChatSetting(GROUP, "antidel", false);
    await setChatSetting("global", "deltarget", "both");
    const original = {
      key: { remoteJid: GROUP, participant: GROUP_SENDER, id: "global-target-group-original", fromMe: false },
      message: { conversation: "Group message must still be recovered" },
      messageTimestamp: Math.floor(Date.now() / 1000),
      pushName: "Group sender"
    };

    await handleIncomingFeatureMessage(sock, original, { prefix: "." });
    await handleDeletedMessages(sock, { keys: [{ remoteJid: GROUP, id: original.key.id }] });

    assert.ok(sent.some(item => item.jid === GROUP && String(item.content.text || "").includes("Group message must still be recovered")),
      "global both delivery must retain and restore the original group message in the group");
    assert.ok(sent.some(item => item.jid === SELF_DM && String(item.content.text || "").includes("Group message must still be recovered")),
      "global both delivery must also restore the group message to the bot DM");
  } finally {
    await setChatSetting(GROUP, "antidel", Boolean(oldGroup.antidel));
    await setChatSetting("global", "deltarget", oldGlobal.deltarget || "chat");
  }
});


test("anti-delete reports view-once messages and labels them clearly", async () => {
  const oldChat = await getChatSettings(CHAT);
  const sent = [];
  const sock = {
    sendMessage: async (jid, content) => {
      sent.push({ jid, content });
      return { key: { remoteJid: jid, id: "view-once-test-output" } };
    }
  };
  await setChatSetting(CHAT, "antidel", true);
  try {
    const viewOnce = {
      key: { remoteJid: CHAT, participant: SENDER, id: "view-once-delete-1", fromMe: false },
      message: {
        viewOnceMessageV2: {
          message: { imageMessage: { mimetype: "image/jpeg", caption: "ephemeral image" } }
        }
      },
      messageTimestamp: Math.floor(Date.now() / 1000)
    };
    await handleIncomingFeatureMessage(sock, viewOnce, { prefix: "." });
    await handleDeletedMessages(sock, { keys: [{ remoteJid: CHAT, id: viewOnce.key.id }] });

    const alertText = sent
      .map(item => String(item.content.text || item.content.caption || ""))
      .find(value => value.includes("DELETED MESSAGE"));
    assert.ok(alertText, "view-once message should produce an anti-delete alert");
    assert.match(alertText, /IMAGE · view-once/, "alert should identify the original as view-once media");
    assert.match(alertText, /ephemeral image/, "alert should preserve the available image caption");
  } finally {
    await setChatSetting(CHAT, "antidel", Boolean(oldChat.antidel));
  }
});


test("global anti-delete captures unsaved senders in private chats and groups with source attribution", async () => {
  const UNKNOWN_DM = "2348098765001@s.whatsapp.net";
  const UNKNOWN_GROUP = "120363999000001@g.us";
  const UNKNOWN_GROUP_SENDER = "2348098765002@s.whatsapp.net";
  const oldGlobal = await getChatSettings("global");
  const oldDm = await getChatSettings(UNKNOWN_DM);
  const oldGroup = await getChatSettings(UNKNOWN_GROUP);
  const sent = [];
  const sock = {
    user: { id: "2348000000000:4@s.whatsapp.net" },
    groupMetadata: async jid => ({
      id: jid,
      subject: "Unknown Senders Test Group",
      participants: []
    }),
    sendMessage: async (jid, content) => {
      sent.push({ jid, content });
      return { key: { remoteJid: jid, id: "unknown-sender-anti-delete-alert" } };
    }
  };

  try {
    await setChatSetting("global", "antidel", true);
    await setChatSetting("global", "deltarget", "chat");
    await setChatSetting(UNKNOWN_DM, "antidel", false);
    await setChatSetting(UNKNOWN_GROUP, "antidel", false);

    const directMessage = {
      key: { remoteJid: UNKNOWN_DM, id: "global-unknown-dm", fromMe: false },
      message: { conversation: "Deleted private message from an unsaved number" },
      messageTimestamp: Math.floor(Date.now() / 1000),
      pushName: "Unsaved Private Sender"
    };
    await handleIncomingFeatureMessage(sock, directMessage, { prefix: "." });
    await handleDeletedMessages(sock, { keys: [{ remoteJid: UNKNOWN_DM, id: directMessage.key.id }] });

    const groupMessage = {
      key: {
        remoteJid: UNKNOWN_GROUP,
        participant: UNKNOWN_GROUP_SENDER,
        id: "global-unknown-group",
        fromMe: false
      },
      message: { conversation: "Deleted group message from a non-contact" },
      messageTimestamp: Math.floor(Date.now() / 1000),
      pushName: "Unsaved Group Member"
    };
    await handleIncomingFeatureMessage(sock, groupMessage, { prefix: "." });
    await handleDeletedMessages(sock, { keys: [{ remoteJid: UNKNOWN_GROUP, id: groupMessage.key.id }] });

    const directAlert = sent.find(item =>
      item.jid === UNKNOWN_DM &&
      String(item.content.text || "").includes("Deleted private message from an unsaved number")
    );
    assert.ok(directAlert, "the global switch should recover messages from unknown private-chat senders");
    assert.match(directAlert.content.text, /Unsaved Private Sender/);
    assert.match(directAlert.content.text, /@2348098765001/);
    assert.match(directAlert.content.text, /Origin:\* Private chat/);

    const groupAlert = sent.find(item =>
      item.jid === UNKNOWN_GROUP &&
      String(item.content.text || "").includes("Deleted group message from a non-contact")
    );
    assert.ok(groupAlert, "the global switch should recover messages from non-contact group members");
    assert.match(groupAlert.content.text, /Unsaved Group Member/);
    assert.match(groupAlert.content.text, /@2348098765002/);
    assert.match(groupAlert.content.text, /Group: Unknown Senders Test Group/);
  } finally {
    await setChatSetting(UNKNOWN_DM, "antidel", Boolean(oldDm.antidel));
    await setChatSetting(UNKNOWN_GROUP, "antidel", Boolean(oldGroup.antidel));
    await setChatSetting("global", "antidel", Boolean(oldGlobal.antidel));
    await setChatSetting("global", "deltarget", oldGlobal.deltarget || "chat");
  }
});
