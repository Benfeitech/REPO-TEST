import test from "node:test";
import assert from "node:assert/strict";
import { attachDeleteAlertToMedia } from "../lib/baileys-events.js";
import { POWERED_FOOTER, withPoweredFooter } from "../lib/api-client.js";

const ALERT = [
  "╭━━〔 🗑️ *DELETED MESSAGE* 〕━━┈⊷",
  "┃ ✧ *Sender:* John (@2348012345678)",
  "┃ ✧ *Type:* IMAGE",
  "┃ ✧ *Content:*",
  "┃ ✧ Original caption",
  "┃ ✧ *Detected:* 12:00 PM",
  "╰━━━━━━━━━━━━┈⊷"
].join("\n");

test("deleted image alert is appended as a caption and keeps the original media payload", () => {
  const image = Buffer.from("image-bytes");
  const result = attachDeleteAlertToMedia({ image, mimetype: "image/jpeg" }, ALERT, ["2348012345678@s.whatsapp.net"]);

  assert.equal(result.image, image);
  assert.equal(result.mimetype, "image/jpeg");
  assert.match(result.caption, /DELETED MESSAGE/);
  assert.match(result.caption, /Original caption/);
  assert.ok(result.caption.endsWith(POWERED_FOOTER));
  assert.deepEqual(result.mentions, ["2348012345678@s.whatsapp.net"]);
  assert.ok(result.caption.length <= 1024);
});

test("deleted video alert is appended as a caption with the Benfei Tech footer", () => {
  const video = Buffer.from("video-bytes");
  const result = attachDeleteAlertToMedia({ video, mimetype: "video/mp4" }, ALERT);

  assert.equal(result.video, video);
  assert.equal(result.mimetype, "video/mp4");
  assert.match(result.caption, /DELETED MESSAGE/);
  assert.ok(result.caption.endsWith(POWERED_FOOTER));
  assert.ok(result.caption.length <= 1024);
});

test("the alert helper does not merge the alert into non-visual media", () => {
  assert.equal(attachDeleteAlertToMedia({ audio: Buffer.from("audio") }, ALERT), null);
  assert.equal(attachDeleteAlertToMedia(null, ALERT), null);
});

test("Powered by Benfei Tech uses the bot menu's small-cap lettering style", () => {
  assert.equal(POWERED_FOOTER, "⚡ *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ʙᴇɴꜰᴇɪ ᴛᴇᴄʜ*");
  assert.ok(withPoweredFooter("Alert content").endsWith(POWERED_FOOTER));
});
