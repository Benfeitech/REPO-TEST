import test from "node:test";
import assert from "node:assert/strict";
import { createGroupActivityCommands } from "../commands/group-activity.js";
import { loadCommands } from "../handlers/command-loader.js";
import config from "../config/bot.config.js";
import theme from "../config/theme.config.js";
import { buildMenu } from "../lib/menu.js";

const GROUP = "120363000000000000@g.us";
const TARGET = "2348011111111@s.whatsapp.net";
const CALLER = "2348022222222@s.whatsapp.net";

function find(commands, name) {
  const command = commands.find(item => item.name === name);
  assert.ok(command, "missing command ." + name);
  return command;
}

function context(overrides = {}) {
  const replies = [];
  const sends = [];
  const testContext = { replies, sends, sendCalls: [] };
  testContext.ctx = {
      jid: GROUP, command: "lore", args: "", senderJid: CALLER,
      config: { prefix: "." },
      msg: { key: { remoteJid: GROUP }, message: { conversation: ".lore" } },
      sock: { user: { id: "2348099999999@s.whatsapp.net" } },
      reply: async text => { replies.push(String(text)); },
      send: async (...args) => { sends.push(args[0]); testContext.sendCalls.push(args); },
      groupHistory: {
        getRecentMessages: async () => [],
        getMembers: async () => ({}),
        getDailyRanking: async () => ({ date: "2026-01-01", total: 0, members: [] })
      },
      ...overrides
    };
  return testContext;
}

test("all five group activity commands politely refuse private chats", async () => {
  const commands = createGroupActivityCommands({ askAI: async () => "unused" });
  for (const name of ["roast", "lore", "tldr", "ghost", "top"]) {
    const { ctx, replies, sends } = context({ jid: CALLER });
    await find(commands, name).run(ctx);
    const output = ["ghost", "top"].includes(name) ? sends[0] && sends[0].text : replies[0];
    assert.match(output || "", /only works inside a WhatsApp group/i, name);
  }
});

test(".roast uses the selected member's history and enforces a cooldown", async () => {
  const prompts = [];
  const commands = createGroupActivityCommands({
    askAI: async prompt => { prompts.push(prompt); return "They type like every message is a season finale."; }
  });
  const messages = Array.from({ length: 12 }, (_, index) => ({
    id: "m" + index, senderJid: TARGET, senderName: "Ada",
    timestamp: Date.now() - (12 - index) * 1000,
    text: "I have another dramatic update number " + index,
    type: "text", isReaction: false, isBotCommand: false, fromMe: false
  }));
  const { ctx, replies } = context({
    command: "roast",
    msg: {
      key: { remoteJid: GROUP, id: "command-roast" },
      message: { extendedTextMessage: { text: ".roast @Ada", contextInfo: { mentionedJid: [TARGET] } } }
    },
    groupHistory: { getRecentMessages: async () => messages, getMembers: async () => ({}) }
  });

  await find(commands, "roast").run(ctx);
  assert.equal(prompts.length, 1);
  assert.ok(prompts[0].includes("Ada"));
  assert.ok(prompts[0].includes("light-hearted"));
  assert.match(replies[0], /Friendly roast for Ada/);
  await find(commands, "roast").run(ctx);
  assert.match(replies[1], /60-second cooldown/i);
  assert.equal(prompts.length, 1);
});

test(".lore and .tldr send AI results using WhatsApp-friendly text", async () => {
  const prompts = [];
  const commands = createGroupActivityCommands({
    askAI: async prompt => {
      prompts.push(prompt);
      return prompt.includes("epic fantasy saga") ? "The group entered the Crystal Era." :
        "*Main topics*\n- Launch plan\n\n*Key decisions*\n- Ada will test it\n\n*Action items / open questions*\n- Ben to share results";
    }
  });
  const messages = [{
    senderJid: TARGET, senderName: "Ada", timestamp: Date.now(),
    text: "We should launch the project next week.", type: "text",
    isReaction: false, isBotCommand: false, fromMe: false
  }];
  const history = { getRecentMessages: async () => messages };

  const loreContext = context({ command: "lore", groupHistory: history });
  await find(commands, "lore").run(loreContext.ctx);
  assert.ok(prompts[0].includes("Ada: We should launch"));
  assert.ok(loreContext.sends[0].text.includes("Crystal Era"));

  const tldrContext = context({ command: "tldr", groupHistory: history });
  await find(commands, "tldr").run(tldrContext.ctx);
  assert.ok(prompts[1].includes("open questions"));
  assert.ok(tldrContext.sends[0].text.includes("*Main topics*"));
});

test(".top shows medal rankings and the group daily total without newsletter attribution", async () => {
  const commands = createGroupActivityCommands();
  const { ctx, sends, sendCalls } = context({
    command: "top",
    groupHistory: {
      getDailyRanking: async () => ({
        date: "2026-10-18", total: 12,
        members: [
          { senderJid: TARGET, name: "Ada", count: 7 },
          { senderJid: CALLER, name: "Ben", count: 5 }
        ]
      })
    }
  });
  await find(commands, "top").run(ctx);
  assert.match(sends[0].text, /🥇 \*Ada\* — 7 messages/);
  assert.match(sends[0].text, /🥈 \*Ben\* — 5 messages/);
  assert.match(sends[0].text, /Total group messages today:\* 12/);
  assert.equal(sendCalls[0][2], false, "top must not attach newsletter attribution");
});

test(".top reconstructs today's ranking from saved messages if daily counters are empty", async () => {
  const commands = createGroupActivityCommands();
  const now = Date.now();
  const todayText = timestamp => ({
    senderJid: TARGET, senderName: "Ada", timestamp, text: "hello", type: "text",
    isReaction: false, isBotCommand: false, fromMe: false
  });
  const { ctx, sends } = context({
    command: "top",
    groupHistory: {
      getDailyRanking: async () => ({ date: "today", total: 0, members: [] }),
      getMembers: async () => ({}),
      getRecentMessages: async () => [
        todayText(now - 5000),
        { ...todayText(now - 4000), senderJid: CALLER, senderName: "Ben" },
        { ...todayText(now - 3000), isBotCommand: true, text: ".tldr" },
        { ...todayText(now - 2000), isReaction: true, type: "reaction" },
        { ...todayText(now - 1000), fromMe: true }
      ]
    }
  });
  await find(commands, "top").run(ctx);
  assert.match(sends[0].text, /🥇 \*Ada\* — 1 message/);
  assert.match(sends[0].text, /🥈 \*Ben\* — 1 message/);
  assert.match(sends[0].text, /Total group messages today:\* 2/);
});

test(".ghost tags the actual phone JID and uses the saved display name rather than a LID number", async () => {
  const commands = createGroupActivityCommands();
  const lid = "123456789012345@lid";
  const phone = "2348011111111@s.whatsapp.net";
  const now = Date.now();
  const { ctx, sends, sendCalls } = context({
    command: "ghost",
    sock: {
      user: { id: "2348099999999@s.whatsapp.net" },
      signalRepository: {
        lidMapping: {
          getPNForLID: async jid => {
            assert.equal(jid, lid);
            return phone;
          }
        }
      },
      groupMetadata: async () => ({
        participants: [
          { id: lid, notify: "Ada Fei" },
          { id: CALLER, notify: "Ben" }
        ]
      })
    },
    groupHistory: {
      getMembers: async () => ({
        [lid]: { name: "Ada Fei", lastMessageTimestamp: now - 3 * 86400000 },
        [CALLER]: { name: "Ben", lastMessageTimestamp: now - 2 * 86400000 }
      })
    }
  });
  await find(commands, "ghost").run(ctx);
  assert.match(sends[0].text, /\*Ada Fei\* @2348011111111/);
  assert.doesNotMatch(sends[0].text, /123456789012345/);
  assert.ok(sends[0].mentions.includes(phone), "ghost must send the real mention JID");
  assert.equal(sendCalls[0][2], false, "ghost must not attach newsletter attribution");
});

test("all six new commands are registered and appear in the existing dynamic menu", async () => {
  const { commands } = await loadCommands();
  const menu = buildMenu({ pushName: "Tester", mode: "public", connected: true, config, theme, commands });
  for (const name of ["roast", "lore", "tldr", "ghost", "top", "vn2text"]) {
    assert.ok(commands.some(command => command.name === name), "missing command " + name);
    assert.ok(menu.includes("." + name), "missing menu entry ." + name);
  }
});
