import test from "node:test";
import assert from "node:assert/strict";
import { canRunCommand, shouldProcessUpsertMessage } from "../lib/command-policy.js";

test("private mode allows only owner commands", () => {
  assert.equal(canRunCommand("private", false), false);
  assert.equal(canRunCommand("private", true), true);
  assert.equal(canRunCommand("public", false), true);
});

test("append history is not dispatched as commands; only fresh self-authored commands are retained", () => {
  assert.equal(shouldProcessUpsertMessage("append", "120363000000000@g.us"), false);
  assert.equal(shouldProcessUpsertMessage("append", "status@broadcast"), true);
  assert.equal(shouldProcessUpsertMessage("notify", "120363000000000@g.us"), true);

  const selfMessage = { key: { fromMe: true } };
  assert.equal(shouldProcessUpsertMessage("append", "120363000000000@g.us", selfMessage, 3000, 100000, 120000, 105000), true);
  assert.equal(shouldProcessUpsertMessage("append", "120363000000000@g.us", selfMessage, 8000, 100000, 120000, 105000), false,
    "messages timestamped before the current connection should not be replayed");
  assert.equal(shouldProcessUpsertMessage("append", "120363000000000@g.us", selfMessage, null, 100000, 120000, 105000), false,
    "messages without a reliable timestamp should not be replayed");
});
