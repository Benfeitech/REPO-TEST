import test from "node:test";
import assert from "node:assert/strict";
import { loadCommands } from "../handlers/command-loader.js";
import { POWERED_FOOTER } from "../lib/api-client.js";
import { getChatSettings, setChatSetting } from "../lib/feature-state.js";

const GROUP = "120000000000000@g.us";
const ADMIN = "2348000000001@s.whatsapp.net";
const BOT = "2348000000000@s.whatsapp.net";

test("gcstatus sends into the current group with group-status metadata and progress reactions", async () => {
  const { lookup } = await loadCommands();
  const command = lookup.get("gcstatus");
  assert.ok(command, "gcstatus command should be registered");
  assert.equal(lookup.get("groupstatus"), command, "groupstatus alias must use the same implementation");
  const sent = [];
  const reactions = [];
  const responses = [];
  const replies = [];
  const channel = { jid: "120363413231189335@newsletter", name: "𝐁𝐄𝐍𝐅𝐄𝐈 𝐓𝐄𝐂𝐇™" };
  const ctx = {
    jid: GROUP, senderJid: ADMIN, owner: true, args: "Group-only status test",
    config: { prefix: ".", channel },
    msg: { key: { remoteJid: GROUP, id: "command-1", participant: ADMIN }, message: { conversation: ".gcstatus Group-only status test" } },
    sock: {
      user: { id: BOT },
      groupMetadata: async () => ({ id: GROUP, subject: "Test group", participants: [{ id: ADMIN, admin: "admin" }, { id: BOT }] }),
      sendMessage: async (...args) => {
        sent.push(args);
        return { key: { remoteJid: args[0], id: "status-upload-1" }, message: args[1] };
      }
    },
    react: async emoji => { reactions.push(emoji); },
    send: async content => { responses.push(content); },
    reply: async text => { replies.push(String(text)); }
  };
  await command.run(ctx);
  assert.equal(sent.length, 1);
  assert.equal(sent[0][0], GROUP);
  assert.equal(sent[0][1].text, "Group-only status test");
  assert.equal(sent[0][1].backgroundColor, "#9C27B0");
  assert.equal(sent[0][1].contextInfo.isGroupStatus, true);
  assert.equal(sent[0][1].contextInfo.statusSourceType, "TEXT");
  assert.deepEqual(sent[0][1].contextInfo.statusAttributions, [{ type: 10 }]);
  assert.deepEqual(sent[0][1].contextInfo.statusAudienceMetadata, { audienceType: "CLOSE_FRIENDS" });
  assert.deepEqual(reactions, ["⏳", "✅"]);
  assert.equal(sent[0][1].contextInfo.forwardedNewsletterMessageInfo, undefined,
    "newsletter attribution belongs on the success reply, not on the posted status");
  assert.equal(responses[0].text, "✅ Group status posted successfully.\n\n" + POWERED_FOOTER);
  assert.equal(responses[0].contextInfo.forwardedNewsletterMessageInfo.newsletterJid, channel.jid);
  assert.equal(responses[0].contextInfo.forwardedNewsletterMessageInfo.newsletterName, channel.name);
  assert.deepEqual(replies, []);
});

test("gcstatus splits long text into status-sized parts", async () => {
  const { lookup } = await loadCommands();
  const command = lookup.get("gcstatus");
  const sent = [];
  const ctx = {
    jid: GROUP, senderJid: ADMIN, owner: true, args: "A".repeat(1100),
    config: { prefix: "." },
    msg: { key: { remoteJid: GROUP, id: "command-long", participant: ADMIN }, message: { conversation: ".gcstatus " + "A".repeat(1100) } },
    sock: {
      user: { id: BOT },
      groupMetadata: async () => ({ id: GROUP, participants: [{ id: ADMIN, admin: "admin" }, { id: BOT }] }),
      sendMessage: async (...args) => { sent.push(args); return { key: { remoteJid: args[0], id: "upload" + sent.length }, message: args[1] }; }
    },
    react: async () => {},
    reply: async () => {}
  };
  await command.run(ctx);
  assert.equal(sent.length, 2);
  assert.ok(sent.every(([jid, content]) => jid === GROUP && content.contextInfo.isGroupStatus && content.contextInfo.statusSourceType === "TEXT"));
});

test("autostatus exposes view and reaction controls and keeps autoview as an alias", async () => {
  const { lookup } = await loadCommands();
  const command = lookup.get("autostatus");
  assert.ok(command);
  assert.equal(command.name, "autostatus");
  assert.equal(lookup.get("autoview"), command);
  assert.match(command.description, /status reactions/i);

  const replies = [];
  const ctx = {
    owner: true,
    args: "",
    config: { prefix: "." },
    reply: async text => { replies.push(String(text)); }
  };
  await command.run(ctx);
  assert.match(replies[0], /autostatus on\/off/i);
  assert.match(replies[0], /autostatus react on\/off/i);

  const online = lookup.get("online");
  assert.ok(online);
  assert.equal(lookup.get("alwayson"), online);
});


test("antidel on enables global anti-delete across chats instead of only the command chat", async () => {
  const { lookup } = await loadCommands();
  const command = lookup.get("antidel");
  assert.ok(command, "antidel command should be registered");
  const oldGlobal = await getChatSettings("global");
  const oldGroup = await getChatSettings(GROUP);
  const replies = [];
  const ctx = {
    jid: GROUP,
    owner: true,
    args: "on",
    config: { prefix: "." },
    reply: async text => { replies.push(String(text)); }
  };

  try {
    await command.run(ctx);
    assert.equal((await getChatSettings("global")).antidel, true,
      ".antidel on must enable the global setting");
    assert.equal((await getChatSettings(GROUP)).antidel, Boolean(oldGroup.antidel),
      ".antidel on must not just modify the chat where it was sent");
    assert.match(replies[0], /Enabled antidel/i);
  } finally {
    await setChatSetting("global", "antidel", Boolean(oldGlobal.antidel));
  }
});
