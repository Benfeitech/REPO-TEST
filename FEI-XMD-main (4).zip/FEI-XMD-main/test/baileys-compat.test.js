import test from "node:test";
import assert from "node:assert/strict";
import makeWASocket, {
  Browsers,
  DisconnectReason,
  fetchLatestWaWebVersion,
  useMultiFileAuthState
} from "@whiskeysockets/baileys";

test("installed Baileys version exposes the v7 WhatsApp session and retry APIs", () => {
  assert.equal(typeof makeWASocket, "function");
  assert.equal(typeof Browsers.ubuntu, "function");
  assert.ok(DisconnectReason && typeof DisconnectReason === "object");
  assert.equal(typeof fetchLatestWaWebVersion, "function");
  assert.equal(typeof useMultiFileAuthState, "function");
});
