import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const dataDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "fei-group-moderation-"));
process.env.FEI_DATA_DIR = dataDirectory;

const { getChatSettings, setChatSetting, listWarnings } = await import("../lib/feature-state.js");
const { enforceAntibotMessage, handleIncomingFeatureMessage } = await import("../lib/baileys-events.js");

const GROUP = "120363999000001@g.us";
const BOT = "2348099999999@s.whatsapp.net";
const MEMBER = "2348011111111@s.whatsapp.net";
const ADMIN = "2348022222222:4@s.whatsapp.net";

function createSock() {
  const deleted = [];
  const sent = [];
  const kicked = [];
  const sock = {
    user: { id: BOT },
    groupMetadata: async () => ({
      id: GROUP,
      subject: "Moderation test",
      participants: [
        { id: BOT, admin: "admin" },
        { id: MEMBER, admin: null },
        { id: ADMIN, admin: "admin" }
      ]
    }),
    sendMessage: async (jid, content) => {
      if (content && content.delete) deleted.push(content.delete);
      else sent.push({ jid, content });
      return {};
    },
    groupParticipantsUpdate: async (jid, participants, action) => {
      kicked.push({ jid, participants, action });
      return [{ jid: participants[0], status: "200" }];
    }
  };
  return { sock, deleted, sent, kicked };
}

function makeMessage(id, sender, text) {
  return {
    key: { remoteJid: GROUP, participant: sender, id, fromMe: false },
    message: { conversation: text },
    pushName: "Test member",
    messageTimestamp: Math.floor(Date.now() / 1000)
  };
}

test("antibot deletes a non-admin command before dispatch", async () => {
  const old = await getChatSettings(GROUP);
  const { sock, deleted, sent } = createSock();
  await setChatSetting(GROUP, "antibot", true);
  try {
    const result = await enforceAntibotMessage(sock, makeMessage("anti-bot-1", MEMBER, ".gpt hello"), { prefix: ".", ownerNumber: "2348077777777" });
    assert.equal(result, true);
    assert.equal(deleted.length, 1);
    assert.ok(sent.some(item => /bot commands are restricted/i.test(item.content.text || "")));
    assert.ok(sent.some(item => (item.content.mentions || []).includes(MEMBER)));
  } finally {
    await setChatSetting(GROUP, "antibot", Boolean(old.antibot));
  }
});

test("warnlinks deletes links, tags the sender, counts to three, and kicks on the third warning", async () => {
  const old = await getChatSettings(GROUP);
  const { sock, deleted, sent, kicked } = createSock();
  await setChatSetting(GROUP, "warnlinks", true);
  await setChatSetting(GROUP, "antilink", false);
  try {
    for (let i = 1; i <= 3; i += 1) {
      await handleIncomingFeatureMessage(
        sock, makeMessage("warn-link-" + i, MEMBER, "please visit https://example.com/" + i),
        { prefix: ".", ownerNumber: "2348077777777" }
      );
    }
    assert.equal(deleted.length, 3);
    const notices = sent.map(item => item.content.text || "");
    assert.ok(notices.some(text => /links are not allowed in here.*1\/3/s.test(text)));
    assert.ok(notices.some(text => /links are not allowed in here.*2\/3/s.test(text)));
    assert.ok(notices.some(text => /links are not allowed in here.*3\/3/s.test(text)));
    assert.ok(notices.some(text => /removed from the group/i.test(text)));
    assert.equal(kicked.length, 1);
    assert.deepEqual(kicked[0], { jid: GROUP, participants: [MEMBER], action: "remove" });
    assert.equal((await listWarnings(GROUP)).find(item => item.jid === MEMBER)?.count, 3);
  } finally {
    await setChatSetting(GROUP, "warnlinks", Boolean(old.warnlinks));
    await setChatSetting(GROUP, "antilink", Boolean(old.antilink));
  }
});

test("admins are exempt from antibot command deletion and link warnings", async () => {
  const old = await getChatSettings(GROUP);
  const { sock, deleted, kicked } = createSock();
  await setChatSetting(GROUP, "antibot", true);
  await setChatSetting(GROUP, "warnlinks", true);
  try {
    await enforceAntibotMessage(sock, makeMessage("admin-command", ADMIN, ".gpt hello"), { prefix: ".", ownerNumber: "2348077777777" });
    await handleIncomingFeatureMessage(sock, makeMessage("admin-link", ADMIN, "https://example.com"), { prefix: ".", ownerNumber: "2348077777777" });
    assert.equal(deleted.length, 0);
    assert.equal(kicked.length, 0);
  } finally {
    await setChatSetting(GROUP, "antibot", Boolean(old.antibot));
    await setChatSetting(GROUP, "warnlinks", Boolean(old.warnlinks));
    await fs.rm(dataDirectory, { recursive: true, force: true });
  }
});
