import test from "node:test";
import assert from "node:assert/strict";
import { createVn2TextCommand } from "../commands/vn2text.js";

const GROUP = "120363000000000000@g.us";
const SENDER = "2348011111111@s.whatsapp.net";

function context(message) {
  const replies = [];
  const sends = [];
  const sendCalls = [];
  return {
    replies,
    sends,
    sendCalls,
    ctx: {
      jid: GROUP,
      config: { prefix: "." },
      sock: { user: { id: "2348099999999@s.whatsapp.net" }, updateMediaMessage: async () => {} },
      msg: {
        key: { remoteJid: GROUP, id: "command-1", fromMe: false },
        message: { extendedTextMessage: { text: ".vn2text", contextInfo: {
          stanzaId: "voice-1", participant: SENDER, quotedMessage: message
        } } }
      },
      reply: async text => { replies.push(String(text)); },
      send: async (...args) => { sends.push(args[0]); sendCalls.push(args); }
    }
  };
}

test(".vn2text downloads a replied-to voice note and sends its transcript and summary without newsletter attribution", async () => {
  const transcript = "Recognized words from a long voice note. ".repeat(100);
  let downloaded = false;
  let transcribed = false;
  const command = createVn2TextCommand({
    isConfigured: () => true,
    downloadMedia: async (ctx, quoted) => {
      downloaded = Boolean(quoted && quoted.wrapped && quoted.wrapped.key.id === "voice-1");
      return Buffer.from("fake audio");
    },
    transcribe: async () => { transcribed = true; return transcript; },
    askAI: async () => "The speaker shared an update and next steps."
  });
  const { ctx, sends, sendCalls, replies } = context({ audioMessage: { ptt: true, mimetype: "audio/ogg; codecs=opus" } });
  await command.run(ctx);
  assert.equal(downloaded, true);
  assert.equal(transcribed, true);
  assert.equal(replies.length, 0);
  assert.ok(sends.length >= 3, "long transcript should be split and followed by its summary");
  assert.ok(sends[0].text.startsWith("📝 *VOICE NOTE TRANSCRIPT*"));
  assert.ok(sends[sends.length - 1].text.includes("The speaker shared an update"));
  assert.ok(sendCalls.every(call => call[2] === false), "all messages must disable newsletter attribution");
});

test(".vn2text gives a usage hint without newsletter attribution when the replied-to item is not a voice note", async () => {
  const command = createVn2TextCommand({
    isConfigured: () => true,
    downloadMedia: async () => { throw new Error("should not download"); },
    transcribe: async () => { throw new Error("should not transcribe"); }
  });
  const { ctx, replies, sends, sendCalls } = context({ conversation: "ordinary text" });
  await command.run(ctx);
  assert.equal(replies.length, 0);
  assert.match(sends[0].text, /reply directly to a voice note/i);
  assert.equal(sends.length, 1);
  assert.equal(sendCalls[0][2], false);
});

test(".vn2text falls back to the other AI-menu services when the primary summary AI fails", async () => {
  const command = createVn2TextCommand({
    isConfigured: () => true,
    downloadMedia: async () => Buffer.from("fake audio"),
    transcribe: async () => "The speaker says the meeting has moved to Friday.",
    askAI: async () => { throw new Error("primary AI unavailable"); },
    fallbackSummarizers: [
      { name: "Gemini test fallback", ask: async prompt => {
        assert.ok(prompt.includes("meeting has moved to Friday"));
        return "The meeting was moved to Friday.";
      } },
      { name: "Unused fallback", ask: async () => { throw new Error("must not run"); } }
    ]
  });
  const { ctx, sends, sendCalls } = context({
    audioMessage: { ptt: true, mimetype: "audio/ogg; codecs=opus" }
  });
  await command.run(ctx);
  assert.ok(sends[sends.length - 1].text.includes("The meeting was moved to Friday."));
  assert.ok(sendCalls.every(call => call[2] === false));
});

test(".vn2text sends transcription errors without newsletter attribution", async () => {
  const command = createVn2TextCommand({
    isConfigured: () => true,
    downloadMedia: async () => Buffer.from("fake audio"),
    transcribe: async () => { throw new Error("transcription provider failed"); }
  });
  const { ctx, sends, sendCalls, replies } = context({
    audioMessage: { ptt: true, mimetype: "audio/ogg; codecs=opus" }
  });
  await command.run(ctx);
  assert.equal(replies.length, 0);
  assert.match(sends[0].text, /couldn't transcribe/i);
  assert.equal(sendCalls[0][2], false);
});
