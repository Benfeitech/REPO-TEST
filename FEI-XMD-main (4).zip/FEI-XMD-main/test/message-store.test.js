import test from "node:test";
import assert from "node:assert/strict";
import { createMessageStore, installMessageStore } from "../lib/message-store.js";

function makeMessage(remoteJid, id, text) {
  return { key: { remoteJid, id }, message: { conversation: text } };
}

test("message store returns message payloads for Baileys retry requests", async () => {
  const store = createMessageStore(3);
  const direct = makeMessage("2348000000001@s.whatsapp.net", "direct-1", "A private reply");
  const group = makeMessage("120000000000000@g.us", "group-1", "A group message");

  assert.equal(store.remember(direct), true);
  assert.equal(store.remember(group), true);
  assert.deepEqual(await store.getMessage(direct.key), direct.message);
  assert.deepEqual(await store.getMessage(group.key), group.message);
  assert.equal(await store.getMessage({ remoteJid: direct.key.remoteJid, id: "missing" }), undefined);
});

test("message store can answer retry requests when a JID changes from PN to LID", async () => {
  const store = createMessageStore(5);
  const outgoing = makeMessage("2348000000001@s.whatsapp.net", "stable-message-id", "Retry this payload");

  store.remember(outgoing);

  assert.deepEqual(
    await store.getMessage({ remoteJid: "998877@lid", id: "stable-message-id" }),
    outgoing.message
  );
  assert.equal(
    await store.getMessage({ remoteJid: "998877@lid", id: "missing-message-id" }),
    undefined
  );
});

test("message store is bounded and evicts oldest entries", async () => {
  const store = createMessageStore(2);
  const first = makeMessage("chat@s.whatsapp.net", "1", "first");
  const second = makeMessage("chat@s.whatsapp.net", "2", "second");
  const third = makeMessage("chat@s.whatsapp.net", "3", "third");

  store.remember(first);
  store.remember(second);
  await store.getMessage(first.key);
  store.remember(third);

  assert.equal(store.size, 2);
  assert.equal(await store.getMessage(first.key), undefined);
  assert.deepEqual(await store.getMessage(second.key), second.message);
  assert.deepEqual(await store.getMessage(third.key), third.message);
});

test("socket wrapper caches messages returned by sendMessage", async () => {
  const store = createMessageStore(5);
  const sent = makeMessage("2348000000001@s.whatsapp.net", "outgoing-1", "Delivered result");
  const socket = {
    sendMessage: async () => sent
  };

  installMessageStore(socket, store);
  const result = await socket.sendMessage(sent.key.remoteJid, { text: "Delivered result" });

  assert.equal(result, sent);
  assert.deepEqual(await store.getMessage(sent.key), sent.message);
  assert.equal(installMessageStore(socket, store), socket);
});
