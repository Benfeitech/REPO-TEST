import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";

test("online off announces unavailable and stops the persistent setting", async () => {
  const dataDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "fei-online-presence-test-"));
  const script = [
    'import { loadCommands } from "./handlers/command-loader.js";',
    'import { getChatSettings, setChatSetting } from "./lib/feature-state.js";',
    'const { lookup } = await loadCommands(); const online = lookup.get("online");',
    'if (!online) throw new Error("online command is not registered");',
    'await setChatSetting("global", "alwayson", true);',
    'const calls = []; const replies = [];',
    'await online.run({ owner: true, jid: "2348000000000@s.whatsapp.net", args: "off", config: { prefix: "." }, sock: { sendPresenceUpdate: async (...args) => calls.push(args) }, reply: async text => replies.push(String(text)) });',
    'if ((await getChatSettings("global")).alwayson !== false) throw new Error("alwayson setting was not disabled");',
    'if (JSON.stringify(calls) !== JSON.stringify([["unavailable"]])) throw new Error("global unavailable presence was not sent");',
    'if (!replies[0] || !replies[0].includes("Disabled online")) throw new Error("command did not confirm the state change");',
    'console.log("ONLINE_OFF_OK");'
  ].join("\n");
  try {
    const output = execFileSync(process.execPath, ["--input-type=module", "-e", script], { cwd: process.cwd(), env: { ...process.env, FEI_DATA_DIR: dataDirectory }, encoding: "utf8", timeout: 30000 });
    assert.match(output, /ONLINE_OFF_OK/);
  } finally {
    await fs.rm(dataDirectory, { recursive: true, force: true });
  }
});
