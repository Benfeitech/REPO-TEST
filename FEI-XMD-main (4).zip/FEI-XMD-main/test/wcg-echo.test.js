import test from "node:test";
import assert from "node:assert/strict";
import { createWordChainEchoGuard } from "../lib/wcg-echo.js";

const GROUP = "120000000000000@g.us";
const OTHER_GROUP = "120000000000001@g.us";

test("filters a Word Chain announcement echo that arrives before sendMessage resolves", () => {
  const guard = createWordChainEchoGuard();
  const text = "🎮 WORD CHAIN STARTED";
  const pending = guard.beginSend(GROUP, text, 1000);
  const echo = { key: { remoteJid: GROUP, id: "wcg-outbound-1", fromMe: true } };

  assert.equal(guard.shouldIgnore(echo, text, 1001), true);
  assert.equal(guard.shouldIgnore(echo, text, 1001.5), true,
    "duplicate echoes racing the send promise should also be filtered");
  guard.sent(pending, "wcg-outbound-1", 1002);

  assert.equal(guard.shouldIgnore(echo, text, 1003), true,
    "duplicate deliveries of the same sent message should remain filtered");
});

test("filters known outgoing message IDs without suppressing unrelated self-authored words", () => {
  const guard = createWordChainEchoGuard();
  const text = "✅ WORD accepted";
  const pending = guard.beginSend(GROUP, text, 2000);
  guard.sent(pending, "wcg-outbound-2", 2001);

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: GROUP, id: "wcg-outbound-2", fromMe: true }
  }, "different echo text", 2002), true);

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: GROUP, id: "manually-typed-word", fromMe: true }
  }, "lamp", 2002), false, "a word typed from the bot's own linked device must still reach the game");

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: GROUP, id: "wcg-outbound-2", fromMe: false }
  }, text, 2002), false, "incoming messages from other players must not be suppressed");

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: OTHER_GROUP, id: "wcg-outbound-2", fromMe: true }
  }, text, 2002), false, "message IDs are scoped to the chat");
});

test("pending text fallback is scoped to the same chat and exact text", () => {
  const guard = createWordChainEchoGuard();
  const text = "🎮 WORD CHAIN STARTED";
  guard.beginSend(GROUP, text, 3000);

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: OTHER_GROUP, id: "other-chat-echo", fromMe: true }
  }, text, 3001), false);

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: GROUP, id: "different-own-message", fromMe: true }
  }, text + " extra", 3001), false);

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: GROUP, id: "announcement-echo", fromMe: true }
  }, text, 3001), true);
});

test("text fallback expires quickly when a sent message has no returned ID", () => {
  const guard = createWordChainEchoGuard();
  const text = "✅ Game update";
  const pending = guard.beginSend(GROUP, text, 4000);
  guard.sent(pending, "", 4010);

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: GROUP, id: "late-echo", fromMe: true }
  }, text, 5000), true);

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: GROUP, id: "expired-echo", fromMe: true }
  }, text, 9011), false);
});

test("a failed send keeps only a short fallback and does not alter other chats", () => {
  const guard = createWordChainEchoGuard();
  const text = "🎮 WORD CHAIN STARTED";
  const pending = guard.beginSend(GROUP, text, 10_000);
  guard.failed(pending, 10_010);

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: GROUP, id: "ambiguous-send-echo", fromMe: true }
  }, text, 10_100), true);

  assert.equal(guard.shouldIgnore({
    key: { remoteJid: GROUP, id: "too-late", fromMe: true }
  }, text, 15_011), false);
});
