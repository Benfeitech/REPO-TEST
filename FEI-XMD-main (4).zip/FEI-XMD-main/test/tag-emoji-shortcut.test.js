import test from "node:test";
import assert from "node:assert/strict";
import { isHidetagEmojiText } from "../lib/tag-emoji-shortcut.js";

test("wave tag shortcut accepts text without a prefix and with the active prefix", () => {
  assert.equal(isHidetagEmojiText("👋", "."), true);
  assert.equal(isHidetagEmojiText(".👋", "."), true);
  assert.equal(isHidetagEmojiText("!👋", "!"), true);
  assert.equal(isHidetagEmojiText(" 👋️ ", "."), true);
});

test("wave tag shortcut does not consume ordinary text or other emoji aliases", () => {
  for (const value of ["👋 hello", "💯", "🙂", "❤️", ".👋 hello", "👋\nhello", ""]) {
    assert.equal(isHidetagEmojiText(value, "."), false, value);
  }
});
