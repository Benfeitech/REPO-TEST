import test from "node:test";
import assert from "node:assert/strict";
import canvasCommands, { CANVAS_COMMANDS } from "../commands/canvas.js";
import { loadCommands } from "../handlers/command-loader.js";

test("all nine canvas generators retain their category for consolidation into Media & Tools", async () => {
  assert.deepEqual(canvasCommands.map(command => command.name), CANVAS_COMMANDS);
  assert.equal(new Set(CANVAS_COMMANDS).size, 9);
  assert.ok(canvasCommands.every(command => command.category === "Canvas"));

  const { lookup } = await loadCommands();
  for (const name of CANVAS_COMMANDS) {
    assert.ok(lookup.has(name), "Missing canvas command ." + name);
    assert.equal(lookup.get(name).category, "Canvas");
  }
  assert.equal(lookup.get("meme").name, "meme");
  assert.equal(lookup.get("meme2").name, "meme2");
});

test("canvas commands reject missing or incorrectly separated parameters before making API requests", async () => {
  const ctx = {
    args: "",
    command: "",
    jid: "2348000000000@s.whatsapp.net",
    config: { prefix: "." },
    reply: async () => { throw new Error("A network/status message should not be sent for invalid input."); },
    send: async () => { throw new Error("The API should not be called for invalid input."); }
  };

  for (const command of canvasCommands) {
    ctx.command = command.name;
    await assert.rejects(command.run(ctx), /provide|Usage/i, "Expected argument validation for ." + command.name);
  }

  const fakeTtc = canvasCommands.find(command => command.name === "fakettc");
  ctx.command = "fakettc";
  ctx.args = "OnlyOneField";
  await assert.rejects(fakeTtc.run(ctx), /Usage/i);

  const nokia = canvasCommands.find(command => command.name === "nokiamsg");
  ctx.command = "nokiamsg";
  ctx.args = "Hello | John";
  await assert.rejects(nokia.run(ctx), /Usage/i);
});
