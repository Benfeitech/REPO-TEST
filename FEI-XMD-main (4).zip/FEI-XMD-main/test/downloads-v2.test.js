import test from "node:test";
import assert from "node:assert/strict";
import downloadCommands, { AIO_DOWNLOAD_NAMES, DOWNLOAD_V2_NAMES } from "../commands/downloads-v2.js";
import { loadCommands } from "../handlers/command-loader.js";

test("new Xrina downloaders register without replacing existing commands", async () => {
  assert.deepEqual(AIO_DOWNLOAD_NAMES, ["aio", "fb", "twitter", "instagram", "ytmp4", "tiktok"]);
  assert.deepEqual(downloadCommands.map(command => command.name), DOWNLOAD_V2_NAMES);
  assert.equal(new Set(DOWNLOAD_V2_NAMES).size, DOWNLOAD_V2_NAMES.length);

  const { lookup } = await loadCommands();
  for (const name of DOWNLOAD_V2_NAMES) {
    assert.ok(lookup.has(name), "Missing downloader ." + name);
    assert.equal(lookup.get(name).category, "Downloads");
  }
  assert.equal(lookup.get("tiktok").name, "tiktok");
  assert.equal(lookup.get("ytmp4").name, "ytmp4");
  assert.equal(lookup.get("instagram").name, "instagram");
  assert.equal(lookup.get("video").name, "video");
  assert.equal(lookup.get("play").name, "song");
});

test("downloaders reject missing input before reaching the API", async () => {
  const ctx = {
    args: "",
    command: "",
    config: { prefix: "." },
    reply: async () => { throw new Error("The downloader should validate input before sending progress."); },
    send: async () => { throw new Error("The downloader should validate input before calling the API."); }
  };

  for (const command of downloadCommands) {
    ctx.command = command.name;
    await assert.rejects(command.run(ctx), /Usage/i, "Expected an input check for ." + command.name);
  }
});

test("TikTok v2 rejects unsupported hosts", async () => {
  const command = downloadCommands.find(item => item.name === "tiktok2");
  await assert.rejects(command.run({
    args: "https://example.com/video",
    command: "tiktok2",
    config: { prefix: "." },
    reply: async () => { throw new Error("Should reject URL before sending progress."); }
  }), /supported HTTPS TikTok/i);
});
