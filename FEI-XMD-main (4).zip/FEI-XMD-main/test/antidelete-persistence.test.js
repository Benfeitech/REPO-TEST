import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";

test("anti-delete text originals survive a process restart", async () => {
  const dataDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "fei-antidelete-persist-"));
  const firstProcess = [
    'import { setChatSetting } from "./lib/feature-state.js";',
    'import { handleIncomingFeatureMessage, flushAntiDeleteCache } from "./lib/baileys-events.js";',
    'const chat = "2348000000001@s.whatsapp.net";',
    'await setChatSetting(chat, "antidel", true);',
    'const msg = { key: { remoteJid: chat, id: "persisted-before-restart", fromMe: false }, message: { conversation: "Original message saved before restart" }, messageTimestamp: Math.floor(Date.now() / 1000), pushName: "Test Sender" };',
    'const sock = { sendMessage: async () => ({ key: { remoteJid: chat, id: "test" } }) };',
    'await handleIncomingFeatureMessage(sock, msg, { prefix: "." });',
    'await flushAntiDeleteCache();'
  ].join("\n");
  const secondProcess = [
    'import { handleDeletedMessages, flushAntiDeleteCache } from "./lib/baileys-events.js";',
    'const sent = []; const chat = "2348000000001@s.whatsapp.net";',
    'const sock = { sendMessage: async (jid, content) => { sent.push({ jid, content }); return { key: { remoteJid: jid, id: "restore-test" } }; } };',
    'await handleDeletedMessages(sock, { keys: [{ remoteJid: chat, id: "persisted-before-restart" }] });',
    'await flushAntiDeleteCache();',
    'if (!sent.some(item => String(item.content.text || "").includes("Original message saved before restart"))) throw new Error("The persisted message was not restored after restart.");',
    'console.log("PERSISTED_RESTORE_OK");'
  ].join("\n");
  try {
    const env = { ...process.env, FEI_DATA_DIR: dataDirectory };
    execFileSync(process.execPath, ["--input-type=module", "-e", firstProcess], { cwd: process.cwd(), env, encoding: "utf8", stdio: "pipe", timeout: 20000 });
    const output = execFileSync(process.execPath, ["--input-type=module", "-e", secondProcess], { cwd: process.cwd(), env, encoding: "utf8", timeout: 20000 });
    assert.match(output, /PERSISTED_RESTORE_OK/);
  } finally {
    await fs.rm(dataDirectory, { recursive: true, force: true });
  }
});


test("view-once media is streamed and retained before deletion, then restored after a restart", async () => {
  const dataDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "fei-viewonce-antidelete-"));
  const firstProcess = [
    'import { setChatSetting } from "./lib/feature-state.js";',
    'import { handleIncomingFeatureMessage, flushAntiDeleteCache } from "./lib/baileys-events.js";',
    'const chat = "2348000000099@s.whatsapp.net";',
    'const id = "viewonce-persist-capture-1";',
    'await setChatSetting(chat, "antidel", true);',
    'const media = { url: "https://media.example.invalid/view-once-image", mediaKey: Buffer.from([1, 2, 3]), mimetype: "image/jpeg", caption: "Before deletion", fileLength: 24 };',
    'const msg = { key: { remoteJid: chat, participant: "2348012345678@s.whatsapp.net", id, fromMe: false }, message: { ephemeralMessage: { message: { viewOnceMessageV2: { message: { imageMessage: media } } } } }, messageTimestamp: Math.floor(Date.now() / 1000), pushName: "Test sender" };',
    'const downloaded = Buffer.alloc(9 * 1024 * 1024, 65);',
    'const streamDownloader = async (receivedMedia, type) => { if (receivedMedia !== media || type !== "image") throw new Error("The inner media payload was not passed to the streaming downloader."); return (async function* () { yield downloaded; })(); };',
    'const sock = { user: { id: "2348000000000@s.whatsapp.net" }, sendMessage: async () => ({ key: { remoteJid: chat, id: "test-send" } }) };',
    'await handleIncomingFeatureMessage(sock, msg, { prefix: "." }, streamDownloader);',
    'await flushAntiDeleteCache();',
    'console.log("VIEWONCE_CAPTURE_PERSISTED");'
  ].join("\n");
  const secondProcess = [
    'import { handleDeletedMessages, flushAntiDeleteCache } from "./lib/baileys-events.js";',
    'const sent = []; const chat = "2348000000099@s.whatsapp.net";',
    'const sock = { user: { id: "2348000000000@s.whatsapp.net" }, sendMessage: async (jid, content) => { sent.push({ jid, content }); return { key: { remoteJid: jid, id: "restored-viewonce" } }; } };',
    'await handleDeletedMessages(sock, { keys: [{ remoteJid: chat, id: "viewonce-persist-capture-1" }] });',
    'await flushAntiDeleteCache();',
    'const restored = sent.find(item => Buffer.isBuffer(item.content.image));',
    'if (!restored) throw new Error("No recovered view-once image payload was sent.");',
    'if (restored.content.image.length !== 9 * 1024 * 1024 || restored.content.image[0] !== 65) throw new Error("The persisted view-once bytes over 8 MB were not restored.");',
    'if (!String(restored.content.caption || "").includes("view-once")) throw new Error("The anti-delete report did not identify the view-once media.");',
    'console.log("VIEWONCE_DELETE_RESTORE_OK");'
  ].join("\n");
  try {
    const env = { ...process.env, FEI_DATA_DIR: dataDirectory };
    const firstOutput = execFileSync(process.execPath, ["--input-type=module", "-e", firstProcess], {
      cwd: process.cwd(), env, encoding: "utf8", timeout: 30000
    });
    assert.match(firstOutput, /VIEWONCE_CAPTURE_PERSISTED/);
    const secondOutput = execFileSync(process.execPath, ["--input-type=module", "-e", secondProcess], {
      cwd: process.cwd(), env, encoding: "utf8", timeout: 30000
    });
    assert.match(secondOutput, /VIEWONCE_DELETE_RESTORE_OK/);
  } finally {
    await fs.rm(dataDirectory, { recursive: true, force: true });
  }
});
