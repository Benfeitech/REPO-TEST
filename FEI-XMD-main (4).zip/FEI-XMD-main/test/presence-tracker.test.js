import test from "node:test";
import assert from "node:assert/strict";
import {
  recordPresenceUpdate,
  getKnownOnlineJids,
  clearPresenceCacheForTests
} from "../lib/presence-tracker.js";

test("presence tracker reports only fresh available members and normalizes device JIDs", () => {
  clearPresenceCacheForTests();
  recordPresenceUpdate({
    presences: {
      "2348011111111:3@s.whatsapp.net": { lastKnownPresence: "available" },
      "2348022222222@s.whatsapp.net": { lastKnownPresence: "composing" },
      "2348033333333@s.whatsapp.net": { lastKnownPresence: "unavailable" }
    }
  }, 1000);

  assert.deepEqual(
    getKnownOnlineJids([
      "2348011111111@s.whatsapp.net",
      "2348022222222@s.whatsapp.net",
      "2348033333333@s.whatsapp.net"
    ], 2000),
    ["2348011111111@s.whatsapp.net", "2348022222222@s.whatsapp.net"]
  );
  assert.deepEqual(getKnownOnlineJids(["2348011111111@s.whatsapp.net"], 21_001), []);
});

test("unavailable presence removes a previously online member", () => {
  clearPresenceCacheForTests();
  recordPresenceUpdate({ presences: { "2348044444444@s.whatsapp.net": { lastKnownPresence: "available" } } }, 500);
  recordPresenceUpdate({ presences: { "2348044444444@s.whatsapp.net": { lastKnownPresence: "unavailable" } } }, 900);
  assert.deepEqual(getKnownOnlineJids(["2348044444444@s.whatsapp.net"], 1000), []);
  clearPresenceCacheForTests();
});
