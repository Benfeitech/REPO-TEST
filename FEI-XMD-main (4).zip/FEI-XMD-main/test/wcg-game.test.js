import test from "node:test";
import assert from "node:assert/strict";
import { WordChainGame, wordChainRules } from "../lib/wcg-game.js";
import { loadCommands } from "../handlers/command-loader.js";

const GROUP = "120000000000000@g.us";
const HOST = "2348000000001@s.whatsapp.net";
const PLAYER_TWO = "2348000000002@s.whatsapp.net";
const PLAYER_THREE = "2348000000003@s.whatsapp.net";
const DM_HOST = "2348000000011@s.whatsapp.net";
const DM_PLAYER = "2348000000012@s.whatsapp.net";

function makeGame(options = {}) {
  return new WordChainGame({
    dictionaryCheck: async () => true,
    turnSeconds: 30,
    joinWindowMs: 60_000,
    ...options
  });
}

function joinGroupPlayers(game, count = 2, startAt = 1000) {
  const players = [
    { jid: HOST, name: "Host" },
    { jid: PLAYER_TWO, name: "Player Two" },
    { jid: PLAYER_THREE, name: "Player Three" }
  ].slice(0, count);

  game.start(GROUP, HOST, "Host", startAt);
  for (const player of players) {
    game.join(GROUP, player.jid, player.name, startAt + 100);
  }
  return players;
}

test("wcg and wrg register as multiplayer commands using the same runner", async () => {
  const { lookup } = await loadCommands();
  assert.ok(lookup.has("wcg"));
  assert.ok(lookup.has("wrg"));
  assert.equal(lookup.get("wcg").run, lookup.get("wrg").run);
  assert.equal(lookup.get("wcg").category, "Games");
  assert.equal(lookup.get("wrg").category, "Games");
  assert.match(lookup.get("wcg").description, /multiplayer/i);
});

test("starting a lobby waits Lobby: 60s and does not register the bot as a player", () => {
  const game = makeGame();
  const started = game.start(GROUP, HOST, "Host", 1000);

  assert.equal(started.ok, true);
  assert.match(started.text, /judges/i);
  assert.match(started.text, /Lobby: 60s/i);
  assert.equal(game.hasGame(GROUP), true);

  const state = game.games.get(GROUP);
  assert.equal(state.state, "lobby");
  assert.equal(state.players.length, 0);
  assert.equal(state.joinDeadline, 61_000);
});

test("typing join adds a human and announces the updated player count", async () => {
  const game = makeGame();
  game.start(GROUP, HOST, "Host", 1000);
  const first = await game.handle(GROUP, HOST, "join", "Host", 2000);
  const second = await game.handle(GROUP, PLAYER_TWO, "join", "Player Two", 3000);

  assert.equal(game.games.get(GROUP).players.length, 2);
  assert.match(first[0].text, /@2348000000001.*joined/i);
  assert.ok(first[0].mentions.includes(HOST), "joining player must be included in WhatsApp mentions");
  assert.match(first[0].text, /Players: \*1\*/);
  assert.match(second[0].text, /@2348000000002.*joined/i);
  assert.ok(second[0].mentions.includes(PLAYER_TWO), "each joining player must be tagged");
  assert.match(second[0].text, /Players: \*2\*/);
});

test("lobby sends short reminders and starts after 60 seconds", () => {
  const game = makeGame();
  joinGroupPlayers(game, 2, 1000);

  const reminder30 = game.tick(31_000);
  assert.match(reminder30[0].text, /30s left to join/i);
  assert.match(reminder30[0].text, /Players: \*2\*/);

  const reminder15 = game.tick(46_000);
  assert.match(reminder15[0].text, /15s left to join/i);

  const started = game.tick(61_000);
  assert.match(started[0].text, /WORD CHAIN STARTED/i);
  assert.match(started[0].text, /First turn/i);
  assert.match(started[0].text, /at least \*4 letters\*/i);
  assert.match(started[0].text, /30 seconds/i);
  assert.ok(started[0].text.includes("@2348000000001"), "the current player must be tagged in the start notice");
  assert.ok(started[0].text.includes("@2348000000002"), "the next player must be tagged in the start notice");
  assert.ok(started[0].mentions.includes(HOST));
  assert.ok(started[0].mentions.includes(PLAYER_TWO));
  assert.equal(game.games.get(GROUP).state, "playing");
});

test("the opening player's 30-second clock starts after the start notice is sent", () => {
  const game = makeGame();
  joinGroupPlayers(game, 2, 1000);

  game.tick(61_000);
  const beforeNotice = game.games.get(GROUP).turnDeadline;
  assert.equal(beforeNotice, 91_000);

  assert.equal(game.markStartAnnounced(GROUP, 70_000), true);
  assert.equal(game.games.get(GROUP).turnDeadline, 100_000);
  assert.equal(game.markStartAnnounced(GROUP, 75_000), false);
  assert.equal(game.games.get(GROUP).turnDeadline, 100_000);

  const afterOldDeadline = game.tick(82_000);
  assert.equal(game.games.get(GROUP).state, "playing");
  assert.equal(game.activePlayers(game.games.get(GROUP)).length, 2);
  assert.doesNotMatch(afterOldDeadline.map(item => item.text).join("\\n"), /GAME CHAMPION/i);
});

test("a valid chain advances turns, raises the minimum length, accepts longer words, and shortens the timer", async () => {
  const game = makeGame();
  joinGroupPlayers(game, 2, 1000);
  game.tick(61_000);

  const acceptedFirst = await game.handle(GROUP, HOST, "lamp", "Host", 62_000);
  assert.match(acceptedFirst[0].text, /LAMP.*accepted/i);
  assert.match(acceptedFirst[0].text, /Minimum word length:\* 5\+ English letters/i);
  assert.match(acceptedFirst[0].text, /Time left:\* 29 seconds/i);
  assert.equal(game.games.get(GROUP).lastWord, "lamp");
  assert.equal(game.games.get(GROUP).currentIndex, 1);

  // "planet" has six letters; five is the minimum at this turn, not an exact size.
  const acceptedSecond = await game.handle(GROUP, PLAYER_TWO, "planet", "Player Two", 63_000);
  assert.match(acceptedSecond[0].text, /Minimum word length:\* 6\+ English letters/i);
  assert.match(acceptedSecond[0].text, /Time left:\* 28 seconds/i);
  assert.equal(game.games.get(GROUP).words.length, 2);
  assert.equal(game.games.get(GROUP).requiredLength, 6);
});

test("an invalid answer eliminates only the current player and crowns the last survivor", async () => {
  const game = makeGame();
  joinGroupPlayers(game, 2, 1000);
  game.tick(61_000);

  const result = await game.handle(GROUP, HOST, "abc", "Host", 62_000);
  assert.match(result[0].text, /Host.*eliminated/i);
  assert.match(result[0].text, /GAME CHAMPION: Player Two/i);
  assert.match(result[0].text, /Total valid words: \*0\*/);
  assert.equal(game.hasGame(GROUP), false);
});

test("a player's second answer is ignored after their accepted word advances the turn", async () => {
  const game = makeGame();
  joinGroupPlayers(game, 2, 1000);
  game.tick(61_000);

  const first = await game.handle(GROUP, HOST, "lamp", "Host", 62_000);
  assert.match(first[0].text, /LAMP.*accepted/i);
  const duplicateAttempt = await game.handle(GROUP, HOST, "papa", "Host", 62_100);

  assert.deepEqual(duplicateAttempt, []);
  assert.equal(game.games.get(GROUP).words.length, 1);
  assert.equal(game.games.get(GROUP).currentIndex, 1);
});

test("the remaining players continue after one person fails", async () => {
  const game = makeGame();
  joinGroupPlayers(game, 3, 1000);
  game.tick(61_000);

  await game.handle(GROUP, HOST, "lamp", "Host", 62_000);
  const eliminated = await game.handle(GROUP, PLAYER_TWO, "apple", "Player Two", 63_000);
  assert.match(eliminated[0].text, /Player Two.*eliminated/i);
  assert.match(eliminated[0].text, /Current turn.*@2348000000003/i);
  assert.equal(game.activePlayers(game.games.get(GROUP)).length, 2);

  const next = await game.handle(GROUP, PLAYER_THREE, "piano", "Player Three", 64_000);
  assert.match(next[0].text, /PIANO.*accepted/i);
  assert.equal(game.games.get(GROUP).words.length, 2);
});

test("untouched three-player game stays alive until the first word is played", async () => {
  const game = makeGame();
  joinGroupPlayers(game, 3, 1000);
  game.tick(61_000);

  const firstTimeout = game.tick(91_000);
  assert.match(firstTimeout[0].text, /No first word yet/i);
  assert.match(firstTimeout[0].text, /nobody is eliminated/i);
  assert.doesNotMatch(firstTimeout[0].text, /GAME CHAMPION/i);
  assert.equal(game.hasGame(GROUP), true);
  assert.equal(game.activePlayers(game.games.get(GROUP)).length, 3);
  assert.equal(game.games.get(GROUP).currentIndex, 0);
  assert.equal(game.games.get(GROUP).turnDeadline, 121_000);

  const secondTimeout = game.tick(121_000);
  assert.match(secondTimeout[0].text, /No first word yet/i);
  assert.doesNotMatch(secondTimeout[0].text, /GAME CHAMPION/i);
  assert.equal(game.activePlayers(game.games.get(GROUP)).length, 3);
  assert.equal(game.games.get(GROUP).turnDeadline, 151_000);

  const accepted = await game.handle(GROUP, HOST, "lamp", "Host", 125_000);
  assert.match(accepted[0].text, /LAMP.*accepted/i);
  assert.equal(game.games.get(GROUP).words.length, 1);
  assert.equal(game.games.get(GROUP).currentIndex, 1);
});

test("the current player is tagged once at 5 seconds remaining and the reminder resets for the next turn", async () => {
  const game = makeGame();
  joinGroupPlayers(game, 3, 1000);
  game.tick(61_000);

  const reminder = game.tick(86_000);
  assert.equal(reminder.length, 1);
  assert.match(reminder[0].text, /5 SECONDS LEFT/i);
  assert.ok(reminder[0].text.includes("@2348000000001"));
  assert.ok(reminder[0].mentions.includes(HOST));

  assert.deepEqual(game.tick(87_000), [], "the same turn should not send duplicate 5-second reminders");

  const accepted = await game.handle(GROUP, HOST, "lamp", "Host", 87_000);
  assert.match(accepted[0].text, /LAMP.*accepted/i);
  assert.equal(game.games.get(GROUP).turnReminderSent, false);

  const nextReminder = game.tick(111_000);
  assert.equal(nextReminder.length, 1);
  assert.match(nextReminder[0].text, /5 SECONDS LEFT/i);
  assert.ok(nextReminder[0].text.includes("@2348000000002"));
  assert.ok(nextReminder[0].mentions.includes(PLAYER_TWO));
});

test("a player who misses their turn after play begins is eliminated and the survivor wins", async () => {
  const game = makeGame();
  joinGroupPlayers(game, 2, 1000);
  game.tick(61_000);

  const firstWord = await game.handle(GROUP, HOST, "lamp", "Host", 62_000);
  assert.match(firstWord[0].text, /LAMP.*accepted/i);

  const timedOut = game.tick(91_000);
  assert.match(timedOut[0].text, /Player Two.*eliminated.*ran out of time/i);
  assert.match(timedOut[0].text, /GAME CHAMPION: Host/i);
  assert.equal(game.hasGame(GROUP), false);
});

test("an empty lobby closes without pretending a game or winner exists", () => {
  const game = makeGame();
  game.start(GROUP, HOST, "Host", 1000);

  const closed = game.tick(61_000);
  assert.match(closed[0].text, /Nobody joined/i);
  assert.doesNotMatch(closed[0].text, /GAME CHAMPION/i);
  assert.equal(game.hasGame(GROUP), false);
});

test("a one-player lobby extends instead of ending when the first Lobby: 60s expire", () => {
  const game = makeGame();
  game.start(GROUP, HOST, "Host", 1000);
  game.join(GROUP, HOST, "Host", 2000);

  const extended = game.tick(61_000);
  const state = game.games.get(GROUP);
  assert.match(extended[0].text, /WAITING FOR ANOTHER PLAYER/i);
  assert.match(extended[0].text, /No one is eliminated/i);
  assert.doesNotMatch(extended[0].text, /GAME CHAMPION/i);
  assert.equal(state.state, "lobby");
  assert.equal(state.players.length, 1);
  assert.equal(state.joinDeadline, 121_000);

  const secondJoin = game.join(GROUP, PLAYER_TWO, "Player Two", 70_000);
  assert.equal(secondJoin.ok, true);
  assert.equal(game.games.get(GROUP).players.length, 2);

  const started = game.tick(121_000);
  assert.match(started[0].text, /WORD CHAIN STARTED/i);
  assert.equal(game.games.get(GROUP).state, "playing");
});

test("with several players, crash-outs continue until one champion remains after play begins", async () => {
  const game = makeGame();
  joinGroupPlayers(game, 3, 1000);
  game.tick(61_000);

  const firstWord = await game.handle(GROUP, HOST, "lamp", "Host", 62_000);
  assert.match(firstWord[0].text, /LAMP.*accepted/i);

  const firstCrashOut = game.tick(91_000);
  assert.match(firstCrashOut[0].text, /Player Two.*eliminated/i);
  assert.doesNotMatch(firstCrashOut[0].text, /GAME CHAMPION/i);
  assert.equal(game.hasGame(GROUP), true);
  assert.equal(game.activePlayers(game.games.get(GROUP)).length, 2);
  assert.match(firstCrashOut[0].text, /Current turn.*@2348000000003/i);

  const finalCrashOut = game.tick(120_000);
  assert.match(finalCrashOut[0].text, /Player Three.*eliminated/i);
  assert.match(finalCrashOut[0].text, /GAME CHAMPION: Host/i);
  assert.equal(game.hasGame(GROUP), false);
});

test("private DMs can join the same matchmaking lobby and receive game updates", async () => {
  const game = makeGame();
  game.start(DM_HOST, HOST, "DM Host", 1000);
  const joinedHost = await game.handle(DM_HOST, HOST, "join", "DM Host", 2000);
  const joinedPlayer = await game.handle(DM_PLAYER, PLAYER_TWO, "join", "DM Player", 3000);

  assert.equal(game.games.get("__fei_xmd_private_word_chain__").players.length, 2);
  assert.ok(joinedPlayer.some(message => message.chat === DM_HOST));
  assert.ok(joinedPlayer.some(message => message.chat === DM_PLAYER));

  const started = game.tick(61_000);
  assert.equal(started.length, 2);
  assert.ok(started.some(message => message.chat === DM_HOST));
  assert.ok(started.some(message => message.chat === DM_PLAYER));

  const played = await game.handle(DM_HOST, HOST, "lamp", "DM Host", 62_000);
  assert.equal(played.length, 2);
  assert.ok(played.every(message => /Current turn/.test(message.text)));
  assert.equal(game.games.get("__fei_xmd_private_word_chain__").words.length, 1);
  assert.ok(joinedHost.length > 0);
});

test("rules accurately describe human multiplayer, progressive difficulty, and both commands", () => {
  const rules = wordChainRules("!");
  assert.match(rules, /multiplayer/i);
  assert.match(rules, /judge, not a player/i);
  assert.match(rules, /60-second/i);
  assert.match(rules, /30 seconds/i);
  assert.match(rules, /at least/i);
  assert.match(rules, /one answer per turn/i);
  assert.match(rules, /5 seconds remaining/i);
  assert.match(rules, /last letter/i);
  assert.match(rules, /!wcg/);
  assert.match(rules, /!wrg/);
});
