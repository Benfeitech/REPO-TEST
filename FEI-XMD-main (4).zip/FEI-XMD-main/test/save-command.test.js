import test from "node:test";
import assert from "node:assert/strict";
import { loadCommands } from "../handlers/command-loader.js";
import config from "../config/bot.config.js";
import theme from "../config/theme.config.js";
import { buildMenu } from "../lib/menu.js";
import { createSaveCommand } from "../commands/save.js";

const OWNER = "2348111111111@s.whatsapp.net";
const CONFIG_OWNER = "2348169155634";
const CHAT = "2348012345678@s.whatsapp.net";

function makeContext(quotedMessage, options = {}) {
  const replies = [];
  const sent = [];
  const commandMessage = {
    key: { remoteJid: CHAT, id: "save-command", fromMe: false },
    message: {
      extendedTextMessage: {
        text: ".save",
        contextInfo: {
          stanzaId: "status-message-1",
          participant: CHAT,
          quotedMessage
        }
      }
    }
  };
  return {
    replies,
    sent,
    ctx: {
      jid: CHAT,
      msg: commandMessage,
      sock: {
        user: { id: OWNER },
        updateMediaMessage: async () => {},
        sendMessage: async (...args) => {
          sent.push(args);
          return { key: { remoteJid: args[0], id: "saved-message" }, message: args[1] };
        }
      },
      config: { prefix: ".", ownerNumber: CONFIG_OWNER },
      reply: async message => replies.push(String(message))
    }
  };
}

test("save registers .save and both emoji aliases without displaying emojis in the menu", async () => {
  const { lookup } = await loadCommands();
  const command = lookup.get("save");
  assert.ok(command);
  assert.equal(command.noReaction, true, ".save must not react to the triggering command");
  assert.equal(lookup.get("💯"), command);
  assert.equal(lookup.get("🙂"), command);

  const menu = buildMenu({
    pushName: "Tester",
    mode: "public",
    connected: true,
    config,
    theme,
    commands: (await loadCommands()).commands
  });
  assert.ok(menu.includes(".save"));
  assert.equal(menu.includes("💯"), false);
  assert.equal(menu.includes("🙂"), false);
});

test("save sends quoted media to the connected account even when configured owner differs", async () => {
  const quotedMessage = {
    imageMessage: { caption: "Status caption", mimetype: "image/jpeg" }
  };
  const { ctx, sent, replies } = makeContext(quotedMessage);
  const bytes = Buffer.from("test-image");
  const command = createSaveCommand({
    downloadQuotedMedia: async (context, quoted) => {
      assert.equal(quoted.info.stanzaId, "status-message-1");
      return bytes;
    }
  });

  await command.run(ctx);
  assert.equal(sent.length, 1);
  assert.equal(sent[0][0], OWNER);
  assert.equal(sent[0][1].caption, "Status caption");
  assert.deepEqual(sent[0][1].image, bytes);
  assert.deepEqual(replies, [], "successful save must not send a reply to the status owner's chat");
});

test("save sends quoted text status to the connected account's own DM", async () => {
  const { ctx, sent, replies } = makeContext({ conversation: "A text status" });
  await createSaveCommand().run(ctx);
  assert.equal(sent.length, 1);
  assert.equal(sent[0][0], OWNER);
  assert.deepEqual(sent[0][1], { text: "A text status" });
  assert.deepEqual(replies, [], "successful save must not send a reply to the status owner's chat");
});

test("save refuses view-once media", async () => {
  const { ctx, sent, replies } = makeContext({
    viewOnceMessageV2: { message: { imageMessage: { mimetype: "image/jpeg" } } }
  });
  await createSaveCommand({ downloadQuotedMedia: async () => Buffer.from("must-not-download") }).run(ctx);
  assert.equal(sent.length, 0);
  assert.match(replies.join("\n"), /View-once media cannot be saved/i);
});
