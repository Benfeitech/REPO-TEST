import test from "node:test";
import assert from "node:assert/strict";
import { loadCommands } from "../handlers/command-loader.js";

test("new moderation, summary, presence and group-management commands register without alias conflicts", async () => {
  const { commands, lookup } = await loadCommands();

  for (const name of [
    "summarize", "ban", "unban", "warn", "antibot", "onlineusers", "getgcpp",
    "gicon", "groupname", "groupdesc"
  ]) {
    assert.ok(lookup.get(name), "missing command ." + name);
  }

  assert.equal(lookup.get("summary"), lookup.get("summarize"), ".summary must alias .summarize");
  assert.equal(lookup.get("setgcpp"), lookup.get("gicon"), ".setgcpp must reuse the existing group-picture handler");
  assert.equal(lookup.get("setname"), lookup.get("groupname"), ".setname must reuse the existing group-name handler");
  assert.equal(lookup.get("setdesc"), lookup.get("groupdesc"), ".setdesc must reuse the existing group-description handler");
  assert.equal(lookup.get("ban").ownerOnly, true);
  assert.equal(lookup.get("unban").ownerOnly, true);

  const menuCommands = new Set(commands.map(command => command.name));
  for (const name of ["summarize", "onlineusers", "getgcpp", "antibot"]) {
    assert.ok(menuCommands.has(name), "." + name + " should be included in the registered command list");
  }
});
