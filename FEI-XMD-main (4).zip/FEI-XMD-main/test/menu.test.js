import test from "node:test";
import assert from "node:assert/strict";
import config from "../config/bot.config.js";
import theme from "../config/theme.config.js";
import { buildMenu, getSectionCommands } from "../lib/menu.js";
import { loadCommands } from "../handlers/command-loader.js";

const PRIORITY_ORDER = [
  "General",
  "AI Chat",
  "AI Media",
  "News Desk",
  "Group Tools",
  "Downloads",
  "Fun Games"
];

test("the first seven menu sections appear in the requested order", () => {
  assert.deepEqual(theme.sections.slice(0, 7).map(section => section.key), PRIORITY_ORDER);
});

test("every registered command appears in exactly one visible menu section", async () => {
  const { commands } = await loadCommands();

  for (const command of commands) {
    assert.equal(
      theme.sections.filter(section => getSectionCommands(section, commands).some(item => item.name === command.name)).length,
      1,
      "Command ." + command.name + " must appear in exactly one menu section"
    );
  }
});

test("all menu titles have at most two words and every section has at least eight commands", async () => {
  const { commands } = await loadCommands();

  for (const section of theme.sections) {
    assert.ok(section.key.trim().split(/\s+/).length <= 2, section.key + " title exceeds two words");
    const visibleCommands = getSectionCommands(section, commands);
    assert.ok(
      visibleCommands.length >= 8,
      section.key + " only has " + visibleCommands.length + " commands"
    );
  }
});

test("menu exposes split canvas, news, and anime sections without old long headings", async () => {
  const { commands } = await loadCommands();
  const menu = buildMenu({
    pushName: "Tester",
    mode: "public",
    connected: true,
    config,
    theme,
    commands
  });

  for (const title of ["🖼 ᴄᴀɴᴠᴀs ᴛᴏᴏʟs", "📰 ɴᴇᴡs ᴅᴇsᴋ", "💞 ᴀɴɪᴍᴇ ʀᴇᴀᴄᴛɪᴏɴs", "⚡ ᴀɴɪᴍᴇ ᴍᴏᴠᴇs"]) {
    assert.ok(menu.includes(title), "Missing menu title: " + title);
  }

  for (const oldTitle of ["🎮 ɢᴀᴍᴇs", "🖼 ᴄᴀɴᴠᴀs ᴍᴇɴᴜ", "👑 ᴏᴡɴᴇʀ ᴍᴇɴᴜ", "💬 ᴘʀᴇsᴇɴᴄᴇ & ᴀᴜᴛᴏ"]) {
    assert.equal(menu.includes(oldTitle), false, "Old title should be gone: " + oldTitle);
  }

  for (const command of [".wcg", ".wrg", ".canvasquote", ".typing", ".status", ".aljazeera", ".cnn", ".bbc"]) {
    assert.ok(menu.includes(command), "Menu is missing " + command);
  }
});

test("all news platforms are independently registered as visible menu commands", async () => {
  const { commands, lookup } = await loadCommands();
  for (const name of ["aljazeera", "cnn", "bbc", "guardian", "npr", "nytimes", "foxnews", "skynews", "dw", "france24", "washingtonpost", "timesofindia", "punchnews", "abcnews"]) {
    assert.ok(lookup.has(name), "Missing news command ." + name);
    assert.equal(lookup.get(name).category, "News");
    assert.ok(commands.some(command => command.name === name));
  }
});

test("tag aliases are registered and visible menu excludes the wave emoji alias", async () => {
  const { commands, lookup } = await loadCommands();
  const hidetag = lookup.get("hidetag");
  assert.ok(hidetag);
  assert.equal(lookup.get("tag"), hidetag);
  assert.equal(lookup.get("👋"), hidetag);
  assert.ok(hidetag.hiddenAliases.includes("👋"));

  const menu = buildMenu({
    pushName: "Tester",
    mode: "public",
    connected: true,
    config,
    theme,
    commands
  });
  const menuLines = menu.split("\n");
  assert.ok(menuLines.includes("┃ ✫✧│ .tag"), "the .tag alias should appear in the bot menu");
  assert.equal(menuLines.includes("┃ ✫✧│ .👋"), false,
    "the wave emoji is an alias but should remain hidden from the menu");
});

test("every menu trigger can display the current bot uptime", () => {
  const menu = buildMenu({
    pushName: "Tester",
    mode: "public",
    connected: true,
    config,
    theme,
    commands: [],
    uptimeSeconds: 3661
  });
  assert.ok(menu.includes("⏱️ ᴜᴘᴛɪᴍᴇ: 1h 1m 1s"));
});
