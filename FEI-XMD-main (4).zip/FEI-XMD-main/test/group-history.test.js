import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createGroupHistory, lagosDateKey } from "../lib/group-history.js";

const GROUP = "120363000000000000@g.us";
const ALICE = "2348011111111@s.whatsapp.net";
const BOB = "2348022222222@s.whatsapp.net";
const CAROL = "2348033333333@s.whatsapp.net";

function message(id, senderJid, senderName, text, timestamp, content) {
  return {
    key: { remoteJid: GROUP, participant: senderJid, id, fromMe: false },
    pushName: senderName,
    messageTimestamp: Math.floor(timestamp / 1000),
    message: content || { conversation: text }
  };
}

test("group history persists across instances and keeps only the configured recent messages", async t => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "fei-group-history-"));
  t.after(() => fs.rm(directory, { recursive: true, force: true }));
  const now = Date.now();
  const history = createGroupHistory({ dataDirectory: directory, sessionId: "test", maxMessagesPerGroup: 2 });

  await history.record(message("one", ALICE, "Alice", "first message", now - 30000), {
    senderJid: ALICE, senderName: "Alice", text: "first message"
  });
  await history.record(message("two", BOB, "Bob", ".menu", now - 20000), {
    senderJid: BOB, senderName: "Bob", text: ".menu", isBotCommand: true
  });
  await history.record(message("three", ALICE, "Alice", "second message", now - 10000), {
    senderJid: ALICE, senderName: "Alice", text: "second message"
  });
  await history.record(message("four", CAROL, "Carol", "", now - 5000, {
    reactionMessage: { text: "❤️", key: { id: "three" } }
  }), { senderJid: CAROL, senderName: "Carol", text: "" });

  await history.flush();
  const restored = createGroupHistory({ dataDirectory: directory, sessionId: "test", maxMessagesPerGroup: 2 });
  await restored.load();
  const recent = await restored.getRecentMessages(GROUP, 10);
  assert.equal(recent.length, 2);
  assert.deepEqual(recent.map(entry => entry.id), ["three", "four"]);
  assert.equal(recent[0].senderName, "Alice");
  assert.equal(recent[0].type, "text");
  assert.equal(recent[1].type, "reaction");

  const members = await restored.getMembers(GROUP);
  assert.equal(members[ALICE].lastMessageTimestamp, Math.floor((now - 10000) / 1000) * 1000);
  assert.equal(members[CAROL], undefined, "reactions should not be treated as a member speaking");

  const ranking = await restored.getDailyRanking(GROUP, now);
  assert.equal(ranking.date, lagosDateKey(now));
  assert.equal(ranking.total, 2, "a command and a reaction must not count toward the daily ranking");
  assert.deepEqual(ranking.members.map(member => [member.senderJid, member.count]), [[ALICE, 2]]);
});

test("group history ignores non-group messages and duplicate message IDs", async t => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "fei-group-history-"));
  t.after(() => fs.rm(directory, { recursive: true, force: true }));
  const history = createGroupHistory({ dataDirectory: directory, sessionId: "duplicates", maxMessagesPerGroup: 5 });
  const now = Date.now();
  const item = message("same-id", ALICE, "Alice", "hello", now);
  assert.equal(await history.record({ ...item, key: { ...item.key, remoteJid: "2348011111111@s.whatsapp.net" } }, {
    senderJid: ALICE, senderName: "Alice", text: "hello"
  }), false);
  assert.equal(await history.record(item, { senderJid: ALICE, senderName: "Alice", text: "hello" }), true);
  assert.equal(await history.record(item, { senderJid: ALICE, senderName: "Alice", text: "hello" }), false);
  assert.equal((await history.getRecentMessages(GROUP, 5)).length, 1);
});
