import test from "node:test";
import assert from "node:assert/strict";
import { createAiV2Commands } from "../commands/ai-v2.js";
import { POWERED_FOOTER } from "../lib/api-client.js";

function context(name, args) {
  const sent = [];
  const replies = [];
  return {
    sent,
    replies,
    ctx: {
      command: name,
      args,
      config: { prefix: "." },
      send: async (...values) => { sent.push(values); },
      reply: async (...values) => { replies.push(values); }
    }
  };
}

function findCommand(commands, name) {
  const command = commands.find(item => item.name === name);
  assert.ok(command, "missing command " + name);
  return command;
}

test("new AI model commands parse each endpoint's documented response field", async () => {
  const calls = [];
  const commands = createAiV2Commands({
    requestJson: async (url, params) => {
      calls.push({ url, params });
      if (url.endsWith("/ai/Secret")) return { data: { reply: "Fable answer" } };
      if (url.endsWith("/ai/Qwen-Claude-Haiku")) return { answer: "Qwen answer" };
      if (url.endsWith("/ai/Deepseek")) return { answer: "DeepSeek 3.2 answer" };
      if (url.endsWith("/ai/Deepseek2")) return { reply: "DeepSeek 4 answer" };
      if (url.endsWith("/ai/Gemini2")) return { data: { response: "Gemini answer" } };
      if (url.endsWith("/ai/zerochat")) return { data: { feedback: "Likely human", fake_percentage: 8, is_human: 92, text_words: 5 } };
      throw new Error("Unexpected endpoint " + url);
    }
  });

  const cases = [
    ["fable5", "hello", "Fable answer", "/ai/Secret", { action: "chat", message: "hello" }],
    ["qwen", "hello", "Qwen answer", "/ai/Qwen-Claude-Haiku", { message: "hello", model: "qwen" }],
    ["deepseek2", "hello", "DeepSeek 3.2 answer", "/ai/Deepseek", { message: "hello", model: "v32" }],
    ["deepseek3", "hello", "DeepSeek 4 answer", "/ai/Deepseek2", { action: "chat", message: "hello", model: "v4" }],
    ["gemini2", "hello", "Gemini answer", "/ai/Gemini2", { action: "chat", message: "hello" }]
  ];

  for (const [name, args, answer, endpoint, params] of cases) {
    const { ctx, sent, replies } = context(name, args);
    await findCommand(commands, name).run(ctx);
    assert.equal(sent.length, 1, name + " should send one response");
    assert.ok(sent[0][0].text.includes(answer), name + " used the wrong response field");
    assert.ok(sent[0][0].text.includes(POWERED_FOOTER));
    assert.equal(sent[0][2], true, name + " should attach newsletter attribution");
    assert.equal(replies.length, 0);
    const call = calls.at(-1);
    assert.ok(call.url.endsWith(endpoint));
    assert.deepEqual(call.params, params);
  }

  const { ctx, sent } = context("aidetect", "sample text");
  await findCommand(commands, "aidetect").run(ctx);
  assert.match(sent[0][0].text, /AI likelihood: 8%/);
  assert.match(sent[0][0].text, /Human likelihood: 92%/);
  assert.equal(sent[0][2], true);
});

test("all five TTS versions pass parameters, send MP3 audio, footer text and newsletter attribution", async () => {
  const calls = [];
  const commands = createAiV2Commands({
    requestJson: async (url, params) => {
      calls.push({ url, params });
      if (url.endsWith("/ai/clideo")) return { data: { previewUrl: "https://clideo.com/files/speech.mp3" } };
      if (url.endsWith("/ai/Gemini-tts")) return { result: "https://files.catbox.moe/speech.mp3" };
      if (url.endsWith("/ai/text2speech-v3")) return { audio: "https://replicate.delivery/speech.mp3" };
      if (url.endsWith("/ai/text-to-speech2")) return { result: "https://cdn.tmp.malvryx.dev/speech.mp3" };
      if (url.endsWith("/ai/Multi-Text-to-speech")) return { data: { audio_url: "https://storage.googleapis.com/speech.mp3" } };
      throw new Error("Unexpected endpoint " + url);
    }
  });

  const cases = [
    ["tts", "hello | NORMAL", "/ai/clideo", { action: "generate", text: "hello", mood: "NORMAL" }],
    ["tts2", "hello", "/ai/Gemini-tts", { text: "hello" }],
    ["tts3", "hello | woman1 | English", "/ai/text2speech-v3", { text: "hello", voice: "woman1", language: "English" }],
    ["tts4", "hello | NORMAL MALE", "/ai/text-to-speech2", { text: "hello", voice: "NORMAL MALE" }],
    ["tts5", "hello", "/ai/Multi-Text-to-speech", { action: "tts", text: "hello" }]
  ];

  for (const [name, args, endpoint, params] of cases) {
    const { ctx, sent, replies } = context(name, args);
    await findCommand(commands, name).run(ctx);
    assert.equal(sent.length, 2, name + " should send audio and a branded footer message");
    assert.equal(sent[0][0].audio.url.startsWith("https://"), true);
    assert.equal(sent[0][0].mimetype, "audio/mpeg");
    assert.equal(sent[0][2], true, name + " audio should carry newsletter attribution");
    assert.ok(sent[1][0].text.includes(POWERED_FOOTER));
    assert.equal(sent[1][2], true, name + " footer should carry newsletter attribution");
    assert.equal(replies.length, 0);
    const call = calls.at(-1);
    assert.ok(call.url.endsWith(endpoint));
    assert.deepEqual(call.params, params);
  }
});

test("TTS rejects insecure or unknown audio hosts", async () => {
  const commands = createAiV2Commands({
    requestJson: async () => ({ result: "http://example.invalid/audio.mp3" })
  });
  const { ctx, sent } = context("tts2", "hello");
  await assert.rejects(findCommand(commands, "tts2").run(ctx), /unsupported audio URL/i);
  assert.equal(sent.length, 0);
});
