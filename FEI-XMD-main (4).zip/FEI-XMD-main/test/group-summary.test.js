import test from "node:test";
import assert from "node:assert/strict";
import { buildGroupSummaryPrompt, selectGroupSummaryMessages } from "../commands/ai.js";
import { loadCommands } from "../handlers/command-loader.js";

const entry = (id, extras = {}) => ({
  id, senderJid: "2348012345678@s.whatsapp.net", senderName: "Ada",
  timestamp: 1000 + Number(id), text: "message " + id, type: "text",
  isReaction: false, isBotCommand: false, fromMe: false, ...extras
});

test("chat summary selects the most recent eligible messages and skips commands and bot messages", () => {
  const selected = selectGroupSummaryMessages([
    entry("1"),
    entry("2", { isBotCommand: true, text: ".menu" }),
    entry("3"),
    entry("4", { fromMe: true }),
    entry("5", { isReaction: true }),
    entry("6"),
    entry("7")
  ], 2);
  assert.deepEqual(selected.map(item => item.id), ["6", "7"]);
});

test("summarize command exposes chat mode and a non-conflicting summary alias", async () => {
  const { lookup } = await loadCommands();
  assert.equal(lookup.get("summarize")?.name, "summarize");
  assert.equal(lookup.get("summary")?.name, "summarize");
  assert.match(lookup.get("summarize").description, /summarize/i);
});

test("group summary prompt stays moderate and avoids repeating points", () => {
  const prompt = buildGroupSummaryPrompt([entry("1"), entry("2")], 20);
  assert.match(prompt, /about 180–300 words/i);
  assert.match(prompt, /\*Overview\*/);
  assert.match(prompt, /\*Key points\*/);
  assert.match(prompt, /\*Decisions and next steps\*/);
  assert.match(prompt, /Do not repeat a fact in multiple sections/i);
  assert.match(prompt, /REQUESTED MESSAGE COUNT: 20/);
  assert.match(prompt, /ELIGIBLE MESSAGES PROVIDED: 2/);
});
