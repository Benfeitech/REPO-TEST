import test from "node:test";
import assert from "node:assert/strict";
import funV2, { FUN_V2_NAMES, decodeFunHtml } from "../commands/fun-v2.js";
import { loadCommands } from "../handlers/command-loader.js";

test("fun v2 registers all 20 commands from the supplied Python module", () => {
  assert.equal(funV2.length, 20);
  assert.deepEqual(funV2.map(command => command.name), FUN_V2_NAMES);
  assert.equal(new Set(FUN_V2_NAMES).size, 20);
  for (const command of funV2) {
    assert.equal(command.category, "Fun");
    assert.equal(typeof command.run, "function");
    assert.ok(command.description);
  }
});

test("existing quote and fact commands are preserved with quote2 and fact2 added", async () => {
  const { lookup } = await loadCommands();
  for (const name of ["quote", "fact", "quote2", "fact2"]) assert.ok(lookup.has(name), "Missing ." + name);
  assert.equal(lookup.get("quote").name, "quote");
  assert.equal(lookup.get("fact").name, "fact");
});

test("all fun v2 commands load without duplicate command or alias names", async () => {
  const { lookup, commands } = await loadCommands();
  for (const name of FUN_V2_NAMES) {
    assert.ok(lookup.has(name), "Missing command: " + name);
    assert.equal(lookup.get(name).name, name);
    assert.equal(commands.filter(command => command.name === name).length, 1);
  }
});

test("trivia HTML entities are decoded", () => {
  assert.equal(decodeFunHtml("&quot;Hello&quot; &amp; &#39;world&#39; &#x1F680;"), "\"Hello\" & 'world' 🚀");
});
