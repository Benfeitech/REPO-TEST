import test from "node:test";
import assert from "node:assert/strict";
import { parsePairArguments } from "../lib/telegram.js";

test("Telegram pairing accepts a phone number without a session label", () => {
  assert.deepEqual(parsePairArguments(["2348012345678"]), {
    label: "",
    phoneNumber: "2348012345678"
  });
});

test("Telegram pairing accepts a named session and normalizes phone punctuation", () => {
  assert.deepEqual(parsePairArguments(["bot2", "+234-809-876-5432"]), {
    label: "bot2",
    phoneNumber: "2348098765432"
  });
});

test("Telegram pairing rejects malformed phone numbers", () => {
  assert.throws(() => parsePairArguments(["bot2", "123"]), /valid international phone number/i);
});

test("Telegram pairing validates session-name characters", () => {
  assert.throws(() => parsePairArguments(["bad name", "2348098765432"]), /session name/i);
});
