import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const dataDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "fei-command-ban-"));
process.env.FEI_DATA_DIR = dataDirectory;
const {
  getBotCommandBanAliases,
  isBotCommandBanned,
  isBotCommandBannedForSender,
  setBotCommandBanned,
  listBotCommandBans
} = await import("../lib/feature-state.js");

const USER = "2348012345678@s.whatsapp.net";
const DEVICE_JID = "2348012345678:7@s.whatsapp.net";
const OWNER = "2348099999999@s.whatsapp.net";

test("command bans match both linked-device JIDs and mapped PN/LID identities", async () => {
  const lid = "123456789012345@lid";
  const sock = {
    signalRepository: {
      lidMapping: {
        getPNForLID: async jid => jid === lid ? USER : null,
        getLIDForPN: async jid => jid === USER ? lid : null
      }
    }
  };
  try {
    await setBotCommandBanned(USER, true, OWNER);
    assert.equal(await isBotCommandBannedForSender(sock, lid), true);
    await setBotCommandBanned(lid, false, OWNER);
    await setBotCommandBanned(lid, true, OWNER);
    assert.equal(await isBotCommandBannedForSender(sock, USER), true);
  } finally {
    await setBotCommandBanned(USER, false, OWNER);
    await setBotCommandBanned(lid, false, OWNER);
  }
});

test("resolved PN/LID aliases can all be removed when unbanning", async () => {
  const lid = "123456789012345@lid";
  const sock = {
    signalRepository: {
      lidMapping: {
        getPNForLID: async jid => jid === lid ? USER : null,
        getLIDForPN: async jid => jid === USER ? lid : null
      }
    }
  };
  try {
    await setBotCommandBanned(USER, true, OWNER);
    const aliases = await getBotCommandBanAliases(sock, lid);
    assert.deepEqual(aliases, [lid, USER]);
    for (const alias of aliases) await setBotCommandBanned(alias, false, OWNER);
    assert.equal(await isBotCommandBanned(USER), false);
    assert.equal(await isBotCommandBanned(lid), false);
  } finally {
    await setBotCommandBanned(USER, false, OWNER);
    await setBotCommandBanned(lid, false, OWNER);
  }
});

test("command bans survive device JID normalization and can be removed by unban", async () => {
  try {
    assert.equal(await isBotCommandBanned(USER), false);
    await setBotCommandBanned(DEVICE_JID, true, OWNER);
    assert.equal(await isBotCommandBanned(USER), true);
    assert.ok((await listBotCommandBans()).some(item => item.jid === USER && item.by === OWNER));
    await setBotCommandBanned(USER, false, OWNER);
    assert.equal(await isBotCommandBanned(USER), false);
  } finally {
    await setBotCommandBanned(USER, false, OWNER);
    await setBotCommandBanned(DEVICE_JID, false, OWNER);
    await fs.rm(dataDirectory, { recursive: true, force: true });
  }
});
