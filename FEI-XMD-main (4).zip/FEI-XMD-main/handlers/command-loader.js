import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

async function findCommandFiles(directory) {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (entry.name.startsWith(".")) continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await findCommandFiles(fullPath));
    else if (entry.isFile() && entry.name.endsWith(".js")) files.push(fullPath);
  }
  return files.sort();
}

export async function loadCommands() {
  const directory = path.resolve(process.cwd(), "commands");
  const files = await findCommandFiles(directory);
  const commands = [];
  const lookup = new Map();

  for (const file of files) {
    const module = await import(pathToFileURL(file).href);
    const exported = module.default;
    const entries = Array.isArray(exported) ? exported : [exported];

    for (const command of entries) {
      if (!command || typeof command.name !== "string" || typeof command.run !== "function") {
        throw new Error("Invalid command export in " + path.relative(process.cwd(), file));
      }
      const normalized = {
        ...command,
        name: command.name.toLowerCase().trim(),
        aliases: (command.aliases || []).map(alias => String(alias).toLowerCase().trim())
      };
      if (!normalized.name || !normalized.category) throw new Error("Every command needs a name and category: " + file);

      for (const name of [normalized.name, ...normalized.aliases]) {
        if (!name || /\s/.test(name)) throw new Error("Invalid command name in " + file);
        if (lookup.has(name)) throw new Error("Duplicate command or alias: " + name);
        lookup.set(name, normalized);
      }
      commands.push(normalized);
    }
  }

  console.log("Loaded " + commands.length + " command definitions.");
  return { commands, lookup };
}
