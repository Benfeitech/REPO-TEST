# FEI XMD

**FEI XMD** is a modular WhatsApp bot built with [Baileys](https://github.com/WhiskeySockets/Baileys) and maintained by Benfei Tech. Commands are organized into JavaScript modules, and the command loader discovers new `.js` files placed inside `commands/` automatically.

This README documents the repository structure, setup, configuration, and the complete process for adding a command.

## Contents

- [Requirements and setup](#requirements-and-setup)
- [Repository structure](#repository-structure)
- [Configuration and local data](#configuration-and-local-data)
- [How command loading works](#how-command-loading-works)
- [Add a new command](#add-a-new-command)
- [Build a command that calls an API](#build-a-command-that-calls-an-api)
- [News commands](#news-commands)
- [Canvas commands](#canvas-commands)
- [Downloaders v2](#downloaders-v2)
- [Anime commands v2](#anime-commands-v2)
- [Test and troubleshoot a command](#test-and-troubleshoot-a-command)
- [Command modules and current limitations](#command-modules-and-current-limitations)
- [Security notes](#security-notes)

## Requirements and setup

You need **Node.js 20 or newer**, npm, and a WhatsApp account to link to the bot.

1. Clone or download this repository.
2. From the project folder, install the dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to a new file named `.env`, then enter your own settings. Do not upload your real `.env` file to GitHub.
4. Start the bot:

   ```bash
   npm start
   ```

5. Follow the terminal instructions to link the WhatsApp account. The default pairing method is terminal-based. Telegram-assisted pairing is also available when configured as described in [Configuration and local data](#configuration-and-local-data).

Useful checks:

```bash
npm run check
npm test
```

The GitHub Actions workflow also checks JavaScript syntax, runs the automated tests, loads the registered commands, and checks important menu entries.

## Repository structure

The following lists the files and folders currently used by the project. Some folders, such as `data/`, `auth_info_baileys/`, and `node_modules/`, are created locally at runtime or during installation; they are not part of the committed source tree.

```text
FEI-XMD/
├── .env.example
├── .github/
│   └── workflows/
│       └── validate.yml
├── .gitignore
├── README.md
├── commands/
│   ├── ai.js
│   ├── anime-v2.js
│   ├── api-tools.js
│   ├── baileys.js
│   ├── custom/
│   │   └── hello.js
│   ├── downloads.js
│   ├── downloads-v2.js
│   ├── canvas.js
│   ├── fun.js
│   ├── fun-v2.js
│   ├── general.js
│   ├── group.js
│   ├── news.js
│   ├── wcg.js
│   ├── owner.js
│   └── placeholders.js
├── config/
│   ├── bot.config.js
│   └── theme.config.js
├── handlers/
│   └── command-loader.js
├── lib/
│   ├── api-client.js
│   ├── xrina-api.js
│   ├── baileys-events.js
│   ├── channel.js
│   ├── message-store.js
│   ├── feature-state.js
│   ├── groups.js
│   ├── menu.js
│   ├── state.js
│   ├── telegram.js
│   ├── session-manager.js
│   ├── utils.js
│   └── wcg-game.js
├── test/
│   ├── anime-v2.test.js
│   ├── baileys-events.test.js
│   ├── baileys-compat.test.js
│   ├── message-store.test.js
│   ├── fun-v2.test.js
│   ├── canvas.test.js
│   ├── downloads-v2.test.js
│   ├── news.test.js
│   └── wcg-game.test.js
├── index.js
└── package.json
```

### Root files and folders

| Path | Purpose |
| --- | --- |
| `.env.example` | Safe template for optional environment variables such as the owner number, pairing method, Telegram pairing credentials, bot name, version, and initial prefix. Copy it to `.env` for local use. |
| `.github/workflows/validate.yml` | GitHub Actions workflow. It installs dependencies, runs the automated tests and syntax checks, loads commands, and validates the Unicode menu. |
| `.gitignore` | Lists local files and folders Git should not track, including installed dependencies, credentials, WhatsApp session files, and the saved bot-mode/prefix state file. |
| `README.md` | Project documentation and command-development guide. |
| `index.js` | Main entry point. Starts the WhatsApp socket, restores saved mode and prefix, handles pairing and reconnection, and keeps recent incoming/outgoing message payloads available for WhatsApp retry requests. |
| `package.json` | Project metadata, Node.js requirement, dependencies, and the `start`, `check`, and `test` npm scripts. |
| `commands/` | Command modules. Every `.js` file beneath this folder is discovered recursively and loaded by the command loader. |
| `config/` | Bot settings and Unicode menu appearance. |
| `handlers/` | Code responsible for discovering, validating, and registering command modules. |
| `lib/` | Shared helpers for APIs, WhatsApp events, state, formatting, groups, channel attribution, pairing, and message utilities. |
| `test/` | Automated tests for Baileys compatibility, message retry caching, message events, news parsing, Canvas commands, Xrina downloaders, Word Chain multiplayer gameplay, and existing fun/anime commands. |

### Command files

| File | What it does |
| --- | --- |
| `commands/general.js` | General commands, including the full menu/help display and basic bot/chat information. |
| `commands/owner.js` | Owner information and bot configuration commands, including settings, prefix/mode/privacy controls, and restart guidance. |
| `commands/group.js` | Group information and moderation tools such as admin listing, tagging, invite links, participant actions, and group settings. |
| `commands/fun-v2.js` | Additional API-backed fun commands: jokes, quotes, facts, animal photos, trivia, memes, Pokémon, history, riddles, Wikipedia, and NASA's picture of the day. Duplicate existing names use `quote2` and `fact2`. |
| `commands/fun.js` | Fun and utility commands such as text echoing, safe calculation, random choices, dice, and other lightweight interactions. |
| `commands/ai.js` | AI/chat commands. It submits prompts to configured AI endpoints, validates prompt length, displays a professional processing message, and formats returned text. |
| `commands/downloads.js` | Original media search and download commands. Existing names and aliases are preserved when additional versions are added. |
| `commands/downloads-v2.js` | Xrina-powered `.aio`, `.play2`, and `.tiktok2` downloaders, including format selection and direct-media fallbacks. |
| `commands/canvas.js` | Nine Xrina canvas-image commands displayed inside the consolidated Media & Tools menu. The existing `.meme` fun command is preserved; the canvas police meme is `.meme2`. |
| `commands/anime-v2.js` | Anime and manga search, character/staff/studio details, rankings, seasons, airing times, recommendations, screenshot identification, art, quotes, and reaction GIFs. Uses AniList, nekos.best, Animechan, and trace.moe. |
| `commands/api-tools.js` | API-powered media and utility commands such as website screenshots, background removal, quote/fact retrieval, profile-picture lookup, and image tools. |
| `commands/wcg.js` | Registers `.wcg` and `.wrg` for the multiplayer Word Chain game; FEI XMD judges while human players compete. |
| `commands/news.js` | Fetches and parses RSS/Atom headlines from 14 configured international and Nigerian news sources, with a homepage fallback and short source codes. Use `.news` or `.n` to show the source menu. |
| `commands/baileys.js` | Additional Baileys-based commands and account/chat features, including presence, status, privacy, anti-delete/anti-edit settings, group join requests, and the WhatsApp ban checker. |
| `commands/placeholders.js` | Registers reserved commands whose API integrations are not connected yet. These commands explicitly reply that they are reserved; they are not working implementations. Replace the placeholder with a real implementation before advertising the feature as available. |
| `commands/custom/hello.js` | Small example of a custom command. Use this folder for personal or experimental commands; the loader also discovers nested command folders. |

### Configuration files

| File | What it does |
| --- | --- |
| `config/bot.config.js` | Provides the bot name/version, initial prefix, owner details, default mode, pairing settings, channel information, menu image, and append-message age limit. Environment variables can override selected values. |
| `config/theme.config.js` | Defines the bot title, Unicode border/item characters, and menu section names/order. A command's `category` must match one of these section keys exactly to appear under that menu category. |

### Command loader

| File | What it does |
| --- | --- |
| `handlers/command-loader.js` | Recursively scans `commands/` for JavaScript files, imports each module, normalizes command and alias names, and rejects invalid or duplicate command names. It builds the lookup used when a user sends a command. |

### Shared library

| File | What it does |
| --- | --- |
| `lib/api-client.js` | Shared HTTP/API helpers, response parsing, image URL extraction, URL validation, file-name sanitization, Unicode response boxes, and the branded footer. Reuse these helpers instead of duplicating common logic. |
| `lib/baileys-events.js` | Handles incoming message automations and WhatsApp events, including cached message/poll tracking, anti-delete/anti-edit reporting, group automations, and call handling. Anti-delete media caching is bounded and excludes view-once messages. |
| `lib/channel.js` | Adds native WhatsApp channel attribution to selected outgoing messages. |
| `lib/message-store.js` | Keeps a bounded cache of recent inbound and outbound message payloads so Baileys can respond to WhatsApp message-retry requests. |
| `lib/feature-state.js` | Reads and saves per-chat feature settings and warning counts used by automations and feature commands. |
| `lib/groups.js` | Shared group metadata, admin authorization, and admin-list helpers. |
| `lib/menu.js` | Builds the full Unicode command menu from the active theme, current configuration, and loaded command definitions. |
| `lib/state.js` | Reads and saves the bot mode and chosen prefix in local state. |
| `lib/telegram.js` | Optional Telegram pairing bridge. It restricts pairing requests to the Telegram user IDs configured by the owner. |
| `lib/wcg-game.js` | In-memory Word Chain game state, dictionary lookups, player turns, lobby extensions, eliminations, and timeout handling. |
| `lib/utils.js` | Shared WhatsApp JID/message helpers, quoted-message helpers, command text extraction, and safe mathematical expression parsing. |

### Test files

| File | What it tests |
| --- | --- |
| `test/baileys-events.test.js` | Regression coverage for message-delete/revoke handling and nested edited-message payloads. |
| `test/wcg-game.test.js` | Word Chain multiplayer gameplay, lobby extensions, eliminations, winner completion, timeouts, and command registration. |

### Runtime-generated folders and files

These are created or used locally and may not appear in the GitHub tree until the application creates them.

| Path | Purpose |
| --- | --- |
| `node_modules/` | Installed npm dependencies. Create it with `npm install`; do not edit it manually. |
| `auth_info_baileys/` | WhatsApp login/session credentials created during pairing. Treat this folder as secret. |
| `data/bot-state.json` | Saved bot mode and custom prefix. |
| `data/baileys-features.json` | Saved per-chat feature settings and warning data. |
| `.env` | Your private local environment configuration, copied from `.env.example`. |

## WhatsApp message delivery recovery

FEI XMD uses Baileys `7.0.0-rc14` from a pinned fork commit that adds the pending LID-recipient normalization fix for WhatsApp status broadcasts. At startup it checks the current WhatsApp Web version and enables automatic session recreation. A bounded in-memory cache retains up to 1,000 recent incoming and outgoing message payloads for retry requests, and can fall back to a unique message ID when WhatsApp requests the same item under a PN/LID JID alias.

The retry cache is deliberately limited and is cleared when the process restarts. It helps the bot answer retries; it cannot guarantee that every recipient's WhatsApp encryption session will recover, especially if a recipient device or linked-device session is already out of sync. Keep the bot running after deploying this upgrade and test direct messages with more than one contact before relying on it.


## Deploy FEI XMD to Fly.io

FEI XMD is a long-running WhatsApp worker, not an HTTP website. Its Fly configuration therefore has no `http_service`. The WhatsApp authentication files and saved feature settings must be kept on a persistent Fly Volume.

### 1. Install Fly CLI and sign in

On Windows, open PowerShell and run:

```powershell
iwr https://fly.io/install.ps1 -useb | iex
fly auth login
```

Create a Fly.io account first if you do not already have one. Fly Machines are billed while running, and persistent volumes are billed separately.

### 2. Get the repository

```powershell
git clone https://github.com/Benfeitech/FEI-XMD.git
cd FEI-XMD
Copy-Item fly.toml.example fly.toml
```

Open `fly.toml` in VS Code. Replace `replace-with-your-unique-app-name` with a unique, lowercase Fly app name. The template uses Johannesburg (`jnb`); if you change the region, use the same region for the volume in step 4.

### 3. Create the Fly app

Use exactly the same app name you put in `fly.toml`:

```powershell
fly apps create your-unique-app-name
```

### 4. Create persistent storage

```powershell
fly volumes create fei_data --app your-unique-app-name --region jnb --size 1
```

The volume name `fei_data` and region must match `fly.toml`. The primary WhatsApp credentials stay under `/data/auth_info_baileys`, with primary settings under `/data`. Additional WhatsApp accounts run as worker processes on the same Machine, with credentials and settings isolated under `/data/sessions/<phone-number>/`. Keep this app on one Machine with its persistent volume attached: Fly Volumes are not shared between Machines. The default `FEI_MAX_SESSIONS=2` means two accounts total, including the primary account.

### 5. Configure Telegram pairing securely

Because the hosted worker does not have an interactive terminal for phone-number pairing, create a Telegram bot with BotFather and find your own numeric Telegram user ID. Set the values as Fly secrets rather than committing them to GitHub:

```powershell
fly secrets set PAIRING_METHOD=telegram TELEGRAM_BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN" TELEGRAM_ALLOWED_USER_IDS="YOUR_TELEGRAM_NUMERIC_USER_ID" OWNER_NUMBER="234XXXXXXXXX" --app your-unique-app-name
```

Replace every example value. `OWNER_NUMBER` is your owner phone number with the country code and digits only. The allowed Telegram ID must be your own numeric Telegram **user ID**, not the bot token or phone number.

### 6. Deploy and pair WhatsApp

```powershell
fly deploy --app your-unique-app-name
fly logs --app your-unique-app-name
```

In a private chat with your Telegram pairing bot, send `/pair 234XXXXXXXXX` for the primary account. After that account is connected, add a second WhatsApp account with a unique session label, for example `/pair bot2 2348098765432`. Follow the code returned for that specific number on that phone: **WhatsApp → Settings → Linked Devices → Link a Device → Link with phone number instead**. Keep pairing codes private.

Use `/sessions` to list registered accounts, `/status` or `/status bot2` to check their connection, and `/delsession 2348098765432` (or `/delsession bot2`) to log out and remove an account. Removing `primary` via `/delsession <primary-number>` also clears its local credentials and leaves the primary slot ready to pair again.

When logs show FEI XMD is online, send `.menu` to each linked WhatsApp account to test it. Use `fly logs --app your-unique-app-name` to inspect errors. Start with two total accounts on the current 1 GB machine and monitor memory before increasing `FEI_MAX_SESSIONS`.

### Important notes

Do not configure an HTTP service or automatic idle shutdown for this worker; it needs to keep its WhatsApp connection alive. Fly Volumes are persistent but local to one Machine, so the bot uses one Machine and one volume. Back up important session/settings data separately. Fly currently lists volume capacity at **$0.15 per GB per month**, plus the separate charge for the always-running Machine and network usage; check the current [Fly.io pricing page](https://fly.io/docs/about/pricing/) before deploying.


### Environment variables

The supported environment variables are listed in `.env.example`:

- `OWNER_NUMBER`: optional owner phone number, digits only. The linked WhatsApp account itself is also treated as an owner.
- `PAIRING_METHOD`: `terminal` by default; set to `telegram` to enable the Telegram pairing bridge.
- `TELEGRAM_BOT_TOKEN` and `TELEGRAM_ALLOWED_USER_IDS`: required for Telegram pairing and session management. The allow-list must contain numeric Telegram user IDs.
- `FEI_MAX_SESSIONS`: maximum total linked WhatsApp accounts, including primary; defaults to `2`. Raising it increases memory use because each additional session is a separate Node.js worker.
- `BOT_NAME`, `BOT_VERSION`, `OWNER_NAME`, and `PREFIX`: optional defaults for the name, version, owner display name, and initial command prefix.

Some settings are in `config/bot.config.js`, including channel details and the menu image URL. The theme and menu category names live in `config/theme.config.js`.

The owner can change the active prefix using the command, for example:

```text
.setprefix !
```

After this, commands should be called with `!` instead of `.`, such as `!menu`. The chosen prefix and mode are saved to `data/bot-state.json` and restored at startup.

## How command loading works

1. At startup, `handlers/command-loader.js` recursively scans `commands/` and its subfolders.
2. Every `.js` module must have a default export containing either one command object or an array of command objects.
3. Each command must have a unique `name`, a valid `category`, and a callable `run` function.
4. Optional aliases are registered as alternate ways to invoke the same command. Because duplicate names/aliases are rejected, check other command files before choosing a name.
5. The menu is built from the loaded definitions. A command appears in the right section when its `category` matches a key in `config/theme.config.js`.

**You do not need to manually register a new command in `index.js`.** Place the module under `commands/`, and the loader will pick it up on the next startup.

## Add a new command

The following example adds a working text command named `greet`.

### Step 1 — Create a file

Create `commands/custom/greet.js`. You can create your file directly in the GitHub web interface or in your code editor. The folder name is only for organization; all nested JavaScript files are discovered automatically.

### Step 2 — Add the command code

```js
export default {
  name: "greet",
  aliases: ["hi"],
  category: "General",
  description: "Reply with a greeting and optionally repeat supplied text.",

  run: async ctx => {
    const name = String(ctx.msg.pushName || "there").trim();
    const text = String(ctx.args || "").trim();

    let response = "👋 Hello, " + name + "!";
    if (text) response += "\nYou said: " + text;

    await ctx.reply(response);
  }
};
```

### Step 3 — Understand the fields

| Field | Required? | Meaning |
| --- | --- | --- |
| `name` | Yes | The main command name without the prefix. Here users type `.greet`. Use lowercase letters/numbers where practical. |
| `aliases` | No | Additional names for the same command. Here `.hi` runs the same implementation. Do not duplicate a name or alias already in the project. |
| `category` | Yes | Exact menu category key. The example uses `General`. Available keys are `General`, `Owner`, `Group`, `Fun`, `Downloads`, `AI & Chat`, `Media & Tools`, `Presence`, `Status`, `Chat & Privacy`, and `Bot Settings`. |
| `description` | Recommended | A short explanation for maintainers and anyone browsing the code. |
| `run` | Yes | An asynchronous function called when the command is used. Put the command behavior here. |
| `ownerOnly` | No | Set to `true` to restrict the command to the bot owner. Still validate arguments and permissions required by the underlying WhatsApp operation. |

### Step 4 — Use the command context

The command handler passes a context object named `ctx`. The properties most commonly needed are:

| Property | Purpose |
| --- | --- |
| `ctx.args` | Text supplied after the command, with surrounding whitespace removed. |
| `ctx.command` | Name used to invoke the command. |
| `ctx.msg` | Original Baileys message object. |
| `ctx.jid` | Destination chat JID. |
| `ctx.senderJid` | Sender's normalized WhatsApp JID. |
| `ctx.owner` | Whether this sender is recognized as the bot owner. |
| `ctx.config` | Bot configuration, including `name`, `prefix`, `ownerName`, and `version`. |
| `ctx.sock` | Active Baileys socket for WhatsApp operations. |
| `ctx.reply(text)` | Send a text reply to the command message. |
| `ctx.send(content)` | Send a Baileys message payload, including supported media payloads. |
| `ctx.react(emoji)` | React to the command message. The dispatcher also adds a category reaction before the command runs. |
| `ctx.setMode(mode)` | Save a valid `public` or `private` bot mode. |
| `ctx.setPrefix(prefix)` | Save a valid custom prefix. |
| `ctx.buildMenu()` | Build the current full Unicode menu. |

A simple argument check looks like this:

```js
run: async ctx => {
  const text = String(ctx.args || "").trim();

  if (!text) {
    await ctx.reply("Usage: " + ctx.config.prefix + ctx.command + " your text");
    return;
  }

  await ctx.reply("✅ Received: " + text);
}
```

### Step 5 — Add a new command to an existing module, if preferred

A module may export an array of command objects. For example, `commands/fun.js` contains multiple commands. Add another object to that array, using a unique `name` and the appropriate `category`. Do not replace the entire array just to add one command.

### Step 6 — Check and run it

1. Save the new file.
2. Run `node --check commands/custom/greet.js` to check its syntax.
3. Run `npm run check` and `npm test`.
4. Restart FEI XMD if it is running.
5. Send `.greet`, then try `.greet something`. Use `.menu` to confirm it appears in the menu.

The `npm run check` script lists the source files included in its local syntax command. For every new JavaScript file, run `node --check path/to/your-file.js` as shown above. GitHub Actions checks JavaScript files in the repository recursively.

## Build a command that calls an API

Only add an API command after you have confirmed the endpoint, required method, parameters, authentication requirements, and actual response structure. Do not assume fields or endpoints that the API documentation does not specify.

For example, the core pattern for a JSON API command is:

```js
export default {
  name: "exampleapi",
  category: "Media & Tools",
  description: "Example pattern for requesting an API.",

  run: async ctx => {
    const query = String(ctx.args || "").trim();
    if (!query) {
      await ctx.reply("Usage: " + ctx.config.prefix + "exampleapi your query");
      return;
    }

    await ctx.reply("_Submitting your request to the service. Please wait while processing completes._");

    const response = await fetch("https://example.com/api?query=" + encodeURIComponent(query), {
      headers: { accept: "application/json" },
      signal: AbortSignal.timeout(30000)
    });

    if (!response.ok) {
      throw new Error("The service returned HTTP " + response.status + ".");
    }

    const payload = await response.json();

    // Replace "result" with the actual documented response field.
    if (typeof payload.result !== "string" || !payload.result.trim()) {
      throw new Error("The service did not return the expected result.");
    }

    await ctx.reply("*API RESULT*\n\n" + payload.result);
  }
};
```

The `example.com` endpoint and `payload.result` field above are **illustrative only**; replace them with a real, verified endpoint and its documented response. The sample is a pattern, not an implemented feature.

When working with an existing project API, prefer the shared helpers in `lib/api-client.js` when they support the service. For example, `requestApiJson(endpoint, params)` is configured for the project's Rebix API root, while `requestExternalJson(url, params)` allows only the hosts already permitted by that helper. Review its host allow-list before using a new external provider. Use URL validation for user-supplied URLs.

For commands that send images, audio, or video, confirm the service's actual response format and send a valid Baileys payload. Handle timeouts, HTTP failures, invalid JSON, missing result fields, and unsupported media instead of reporting success prematurely.

## Test and troubleshoot a command

- **Command is unknown:** confirm the file ends in `.js`, is inside `commands/` or a subfolder, and exports a default command object/array.
- **Bot does not start:** look for syntax errors, missing imports, invalid exports, and duplicate command or alias names. The loader throws an error when a duplicate is registered.
- **Command does not appear in the expected menu section:** check the spelling/capitalization of `category` against `config/theme.config.js`.
- **A command is listed but not implemented:** check `commands/placeholders.js`; those entries intentionally report that their integration is pending.
- **A group command fails:** check whether it requires a group, group-admin privileges, or bot-admin privileges.
- **An API request fails:** verify the endpoint, parameters, API status code, response schema, and timeout. Avoid hiding failures behind a success message.
- **Anti-delete/anti-edit does not report an older message:** tracking starts only after the relevant feature is enabled and the bot receives a message while connected. Media retention is bounded; view-once media is excluded.
- **Custom prefix does not take effect:** make sure you used `.setprefix !` with the current prefix first, then use the new prefix (for example, `!menu`).

## News commands

Use `.news` or `.n` to display the news menu and short source codes. Source codes include `bbc`, `cnn`, `punch`, `aj`, `gd`, `nyt`, `fox`, `sky`, `dw`, `f24`, `wp`, `toi`, `npr`, and `abc`.

Examples:

```text
.news bbc 5
.n punch 5
.news all 1
```

A single source accepts 1–10 headlines; `all` accepts 1–2 headlines per source to keep WhatsApp messages manageable. The command reads RSS/Atom feeds from the URLs supplied in the news-source configuration, follows article links, and tries the source homepage if a feed fails. No extra npm dependency or API key is required. Some publishers may block requests or change their feed format, so individual sources can occasionally be unavailable.

## Fun commands v2

The new commands live in `commands/fun-v2.js`; the original `commands/fun.js` and other custom modules were not replaced. Existing `.quote` and `.fact` commands are preserved, while the new versions are `.quote2` and `.fact2`.

Available commands: `.joke`, `.dadjoke`, `.progjoke`, `.chuck`, `.fact2`, `.catfact`, `.dog`, `.cat`, `.fox`, `.advice`, `.quote2`, `.trivia`, `.meme`, `.numfact`, `.activity`, `.pokemon`, `.history`, `.riddle`, `.wiki`, and `.nasa`.

The integrations use the endpoints supplied in the Python script and Node.js's built-in `fetch`. No extra npm package is required. Trivia and riddles reveal their answer in a separate message after a short pause. The meme command skips items marked NSFW or spoiler, but third-party feeds can still be inaccurate or unavailable. NASA's public `DEMO_KEY` has usage limits, and any source may change or rate-limit its endpoint.

## Canvas commands

Canvas image generators use the Xrina API. Separate multiple values with a vertical bar (`|`); text-only commands accept the text directly. The generated image is sent back to the chat.

```text
.fakettc Name | Message
.wndwqute Your quote text
.canvasquote Quote text | Author name
.nokiamsg Message | Sender | Date
.meme2 Username | Meme text
.fakeff Player name | Lobby number
.fakeffduo Player one | Player two
.iqc Message text | 13:34
.ffgirl Username
```

The canvas police-meme generator uses `.meme2` because `.meme` is already registered for the existing random-meme command.

## Downloaders v2

All platform-specific commands below use the same Xrina all-in-one endpoint and media-format selection logic as `.aio`. Existing song search and the separate `.tiktok2` command remain available.

| Command | Usage |
| --- | --- |
| `.aio` | `.aio https://link-to-supported-media` |
| `.fb` | `.fb https://www.facebook.com/...` |
| `.twitter` | `.twitter https://x.com/...` |
| `.instagram` | `.instagram https://www.instagram.com/...` |
| `.ytmp4` | `.ytmp4 https://youtu.be/...` |
| `.tiktok` | `.tiktok https://www.tiktok.com/...` |
| `.play2` | `.play2 song title or artist` |
| `.tiktok2` | `.tiktok2 https://www.tiktok.com/...` |

`.aio` accepts any supported direct media link and prefers a no-watermark video when available, then another video, audio, or another usable direct file. `.fb`, `.twitter`, `.instagram`, `.ytmp4`, and `.tiktok` validate the link's platform and then use that same AIO download flow. The returned file is sent as video, audio, or document based on the format the service returns. `.play2` searches for a song and sends the returned audio. The commands depend on the third-party service and its returned links.

## Anime commands v2

The new anime commands live in `commands/anime-v2.js`. The original modules and custom commands are not replaced. Your existing `.waifu` command remains available; this added anime-image version uses `.waifu2` to avoid a duplicate command name. The help menu is available through `.animemenu` or `.animehelp`.

**Info and search:** `.anime <title>`, `.manga <title>`, `.character <name>`, `.charpic <name>`, `.staff <name>`, `.studio <name>`, `.recommend <anime>`, `.episodes <anime>`, `.animechars <anime>`, `.trailer <anime>`, `.pictures <anime>`, `.streaming <anime>`, `.review <anime>`, `.genres`, and `.genre <genre>`.

**Rankings and schedule:** `.topanime`, `.topmanga`, `.popular`, `.favorite`, `.airing`, `.upcoming`, `.trending`, `.season`, `.topchars`, `.schedule [weekday]`, and `.nextep <anime>`.

**Random and tools:** `.randomanime`, `.randommanga`, `.randomchar`, `.animequote`, and `.whatanime <public HTTPS screenshot URL>`.

**Images:** `.waifu2`, `.husbando`, `.neko`, and `.kitsune`. **Reaction GIFs:** `.angry`, `.baka`, `.bite`, `.bleh`, `.blowkiss`, `.blush`, `.bonk`, `.bored`, `.carry`, `.clap`, `.confused`, `.cry`, `.cuddle`, `.dance`, `.facepalm`, `.feed`, `.handhold`, `.handshake`, `.happy`, `.highfive`, `.hug`, `.kabedon`, `.kick2`, `.kiss`, `.lappillow`, `.laugh`, `.lurk`, `.nod`, `.nom`, `.nope`, `.nya`, `.pat`, `.peck`, `.poke`, `.pout`, `.punch`, `.run`, `.salute`, `.shake`, `.shoot`, `.shocked`, `.shrug`, `.sip`, `.slap`, `.sleep`, `.smile`, `.smug`, `.spin`, `.stare`, `.tableflip`, `.teehee`, `.think`, `.thumbsup`, `.tickle`, `.wag`, `.wave`, `.wink`, `.yawn`, and `.yeet`.

AniList queries explicitly exclude media marked adult and filter out the `Hentai` and `Ecchi` genres from media lists. The screenshot-identification command only accepts public HTTPS URLs. Requests use Node.js's built-in `fetch`, so no extra npm dependency or API key is required. AniList can rate-limit requests; nekos.best requires a meaningful User-Agent; Animechan and trace.moe availability and quotas are controlled by their providers. Reaction GIFs are sent as WhatsApp GIF-style video messages; compatibility can vary by returned file and WhatsApp client.
## Group chat summaries and moderation

Use `.summarize chat [number]` (or `.summary chat [number]`) inside a group to summarize its saved conversation. For example, `.summarize chat 150` asks for a detailed, multi-section summary of up to the latest 150 eligible saved messages. The response heading shows the number of messages actually included. It covers the overall discussion, major topics, contributions by participant, decisions, action items, open questions, and important details. Commands, bot-authored messages, and reactions are excluded from the source. History is stored by the bot, so summaries cannot include messages it never recorded; use 1–300 as the requested count. The summary output is sent without the channel newsletter attribution or a branded footer.

The bot owner can use `.ban @user` or reply to that member's message with `.ban` to prevent that user from running bot commands until restored with `.unban @user` (or by replying with `.unban`). A phone number with country code can also be supplied. These bans persist with the bot's saved feature state.

Automatic link warnings are off until the bot owner enables them inside the group with `.warn on`; use `.warn off` to disable. When enabled, links sent by non-admin members are deleted and the sender is tagged. Warning counts are tracked per member and group; the third link violation triggers a group-removal request. The existing `.warn @user` manual warning and `.warnlist` commands remain available. The separate `.antilink on/off` feature continues to work independently.

Use `.antibot on` to delete commands sent by non-admin members, tagging the sender; `.antibot off` disables that protection. The bot needs group-admin privileges to reliably delete messages and remove members.

Group utilities: `.onlineusers` lists members whose fresh online-presence updates are visible to FEI XMD, but WhatsApp presence privacy means it may not list every online member. `.getgcpp` fetches the current group's profile picture. To set it, attach an image or reply to an image with `.setgcpp`; the caller and bot must have the necessary group-admin permissions. `.setname New group name` and `.setdesc New group description` are aliases for the existing group-name and group-description commands.

The wave shortcut `👋` or `.👋` can be typed in a group to run the hidden-tag action; reacting to a group message with `👋` continues to work. Other emoji shortcuts remain reply/context-dependent where required, so media and view-once shortcuts do not trigger accidentally from ordinary emoji messages.

## Word Chain game

Use `.wcg` or `.wrg` to open a 60-second multiplayer Word Chain lobby in a group or through private-DM matchmaking. **FEI XMD is the judge, never a player.** Every human who wants to play must type `join`. If exactly one player has joined when the first 60 seconds expire, the lobby keeps extending in 60-second intervals until another person joins; it does not discard the player or declare a winner. Once at least two people have joined, the game starts and continues through eliminations until one champion remains.

The bot reminds everyone when 30 seconds and 15 seconds remain in the lobby, showing how many players have joined. At the end of 60 seconds, the game starts if at least two human players joined. During a turn, the bot tags the current player once when 5 seconds remain. If no player submits the first word, the game gives the opening player another timed chance rather than immediately eliminating anyone. In a group, players join in that group. For a private match, each participant messages FEI XMD in their own DM and types `join` while the private lobby is open; the bot sends game updates to each participant's DM. Only one private-DM matchmaking lobby can run at a time, while separate groups can run their own games.

The first player must submit an English word with at least 4 letters; longer words are allowed. Every later word must start with the previous word's final letter. Each accepted word raises the minimum required length by one, up to 12 letters, and reduces the next turn's timer by one second, down to 5 seconds. The active player has 30 seconds for the first turn. Each player gets one answer per turn: a short, repeated, unrecognised, multi-word, or wrong-letter answer eliminates that player. After the opening turn has been given a fair chance, a player who runs out of time is eliminated; if no one submits the very first word, the game offers another opening window rather than immediately eliminating anyone. The last surviving player becomes champion.

The final report crowns the last survivor as the **GAME CHAMPION** and includes total valid words, the longest word and its length, the highest required length reached, and game duration.

Use `.wcg rules` for the rules or `.wcg end` to cancel. Only the lobby starter or bot owner can cancel. Game state is kept in memory and resets if the bot process restarts. English words are checked against the bundled word list first and the free Dictionary API as a fallback; if the service cannot verify a word, it is allowed.

## Command modules and current limitations

The live `.menu` output is the most reliable list of commands currently registered by the running code. Module contents can change as features are added.

The commands in `commands/placeholders.js` that remain reserved are `toimg`, `qr`, `shorturl`, and `weather`. Sticker conversion is implemented separately in `commands/sticker.js`; it uses FFmpeg to convert regular images and short videos into WebP stickers.

Anti-delete and anti-edit tracking operates on messages received after the relevant setting is enabled and while FEI XMD is connected. Anti-delete reports include the `⚡ ᴘᴏᴡᴇʀᴇᴅ ʙʏ ʙᴇɴꜰᴇɪ ᴛᴇᴄʜ` footer. When a deleted image or video is restored, the alert is embedded in the media caption instead of being sent as a separate text message. Anti-delete may restore cached text/captions and eligible non-view-once media up to 8 MB per file, with a 32 MB in-memory media-cache limit. Large or unavailable media may not be retained, and the in-memory cache is cleared when the process restarts.

The `.menu` and `.channel` commands include native WhatsApp View channel attribution when the channel JID is configured. Other command interactions include it randomly about 40% of the time.

## Security notes

- Never commit `.env`, `auth_info_baileys/`, Telegram bot tokens, pairing codes, or other credentials.
- Treat the linked WhatsApp session as account access. Do not share the session folder.
- Keep API keys server-side and in environment variables; never hard-code private keys into commands.
- Validate user input, limit request lengths, use timeouts, and check API responses before sending results.
- Restrict owner-only operations and require the appropriate group permissions for moderation commands.
- Test features in a private test chat/group before deploying to an active community.

### Environment variables

The supported environment variables are listed in `.env.example`:

- `OWNER_NUMBER`: optional owner phone number, digits only. The linked WhatsApp account itself is also treated as an owner.
- `PAIRING_METHOD`: `terminal` by default; set to `telegram` to enable the Telegram pairing bridge.
- `TELEGRAM_BOT_TOKEN` and `TELEGRAM_ALLOWED_USER_IDS`: required for Telegram pairing. The allow-list must contain numeric Telegram user IDs.
- `BOT_NAME`, `BOT_VERSION`, `OWNER_NAME`, and `PREFIX`: optional defaults for the name, version, owner display name, and initial command prefix.

Some settings are in `config/bot.config.js`, including channel details and the menu image URL. The theme and menu category names live in `config/theme.config.js`.

The owner can change the active prefix using the command, for example:

```text
.setprefix !
```

After this, commands should be called with `!` instead of `.`, such as `!menu`. The chosen prefix and mode are saved to `data/bot-state.json` and restored at startup.

## How command loading works

1. At startup, `handlers/command-loader.js` recursively scans `commands/` and its subfolders.
2. Every `.js` module must have a default export containing either one command object or an array of command objects.
3. Each command must have a unique `name`, a valid `category`, and a callable `run` function.
4. Optional aliases are registered as alternate ways to invoke the same command. Because duplicate names/aliases are rejected, check other command files before choosing a name.
5. The menu is built from the loaded definitions. A command appears in the right section when its `category` matches a key in `config/theme.config.js`.

**You do not need to manually register a new command in `index.js`.** Place the module under `commands/`, and the loader will pick it up on the next startup.

## Add a new command

The following example adds a working text command named `greet`.

### Step 1 — Create a file

Create `commands/custom/greet.js`. You can create your file directly in the GitHub web interface or in your code editor. The folder name is only for organization; all nested JavaScript files are discovered automatically.

### Step 2 — Add the command code

```js
export default {
  name: "greet",
  aliases: ["hi"],
  category: "General",
  description: "Reply with a greeting and optionally repeat supplied text.",

  run: async ctx => {
    const name = String(ctx.msg.pushName || "there").trim();
    const text = String(ctx.args || "").trim();

    let response = "👋 Hello, " + name + "!";
    if (text) response += "\nYou said: " + text;

    await ctx.reply(response);
  }
};
```

### Step 3 — Understand the fields

| Field | Required? | Meaning |
| --- | --- | --- |
| `name` | Yes | The main command name without the prefix. Here users type `.greet`. Use lowercase letters/numbers where practical. |
| `aliases` | No | Additional names for the same command. Here `.hi` runs the same implementation. Do not duplicate a name or alias already in the project. |
| `category` | Yes | Exact menu category key. The example uses `General`. Available keys are `General`, `Owner`, `Group`, `Fun`, `Downloads`, `AI & Chat`, `Media & Tools`, `Presence`, `Status`, `Chat & Privacy`, and `Bot Settings`. |
| `description` | Recommended | A short explanation for maintainers and anyone browsing the code. |
| `run` | Yes | An asynchronous function called when the command is used. Put the command behavior here. |
| `ownerOnly` | No | Set to `true` to restrict the command to the bot owner. Still validate arguments and permissions required by the underlying WhatsApp operation. |

### Step 4 — Use the command context

The command handler passes a context object named `ctx`. The properties most commonly needed are:

| Property | Purpose |
| --- | --- |
| `ctx.args` | Text supplied after the command, with surrounding whitespace removed. |
| `ctx.command` | Name used to invoke the command. |
| `ctx.msg` | Original Baileys message object. |
| `ctx.jid` | Destination chat JID. |
| `ctx.senderJid` | Sender's normalized WhatsApp JID. |
| `ctx.owner` | Whether this sender is recognized as the bot owner. |
| `ctx.config` | Bot configuration, including `name`, `prefix`, `ownerName`, and `version`. |
| `ctx.sock` | Active Baileys socket for WhatsApp operations. |
| `ctx.reply(text)` | Send a text reply to the command message. |
| `ctx.send(content)` | Send a Baileys message payload, including supported media payloads. |
| `ctx.react(emoji)` | React to the command message. The dispatcher also adds a category reaction before the command runs. |
| `ctx.setMode(mode)` | Save a valid `public` or `private` bot mode. |
| `ctx.setPrefix(prefix)` | Save a valid custom prefix. |
| `ctx.buildMenu()` | Build the current full Unicode menu. |

A simple argument check looks like this:

```js
run: async ctx => {
  const text = String(ctx.args || "").trim();

  if (!text) {
    await ctx.reply("Usage: " + ctx.config.prefix + ctx.command + " your text");
    return;
  }

  await ctx.reply("✅ Received: " + text);
}
```

### Step 5 — Add a new command to an existing module, if preferred

A module may export an array of command objects. For example, `commands/fun.js` contains multiple commands. Add another object to that array, using a unique `name` and the appropriate `category`. Do not replace the entire array just to add one command.

### Step 6 — Check and run it

1. Save the new file.
2. Run `node --check commands/custom/greet.js` to check its syntax.
3. Run `npm run check` and `npm test`.
4. Restart FEI XMD if it is running.
5. Send `.greet`, then try `.greet something`. Use `.menu` to confirm it appears in the menu.

The `npm run check` script lists the source files included in its local syntax command. For every new JavaScript file, run `node --check path/to/your-file.js` as shown above. GitHub Actions checks JavaScript files in the repository recursively.

## Build a command that calls an API

Only add an API command after you have confirmed the endpoint, required method, parameters, authentication requirements, and actual response structure. Do not assume fields or endpoints that the API documentation does not specify.

For example, the core pattern for a JSON API command is:

```js
export default {
  name: "exampleapi",
  category: "Media & Tools",
  description: "Example pattern for requesting an API.",

  run: async ctx => {
    const query = String(ctx.args || "").trim();
    if (!query) {
      await ctx.reply("Usage: " + ctx.config.prefix + "exampleapi your query");
      return;
    }

    await ctx.reply("_Submitting your request to the service. Please wait while processing completes._");

    const response = await fetch("https://example.com/api?query=" + encodeURIComponent(query), {
      headers: { accept: "application/json" },
      signal: AbortSignal.timeout(30000)
    });

    if (!response.ok) {
      throw new Error("The service returned HTTP " + response.status + ".");
    }

    const payload = await response.json();

    // Replace "result" with the actual documented response field.
    if (typeof payload.result !== "string" || !payload.result.trim()) {
      throw new Error("The service did not return the expected result.");
    }

    await ctx.reply("*API RESULT*\n\n" + payload.result);
  }
};
```

The `example.com` endpoint and `payload.result` field above are **illustrative only**; replace them with a real, verified endpoint and its documented response. The sample is a pattern, not an implemented feature.

When working with an existing project API, prefer the shared helpers in `lib/api-client.js` when they support the service. For example, `requestApiJson(endpoint, params)` is configured for the project's Rebix API root, while `requestExternalJson(url, params)` allows only the hosts already permitted by that helper. Review its host allow-list before using a new external provider. Use URL validation for user-supplied URLs.

For commands that send images, audio, or video, confirm the service's actual response format and send a valid Baileys payload. Handle timeouts, HTTP failures, invalid JSON, missing result fields, and unsupported media instead of reporting success prematurely.

## Test and troubleshoot a command

- **Command is unknown:** confirm the file ends in `.js`, is inside `commands/` or a subfolder, and exports a default command object/array.
- **Bot does not start:** look for syntax errors, missing imports, invalid exports, and duplicate command or alias names. The loader throws an error when a duplicate is registered.
- **Command does not appear in the expected menu section:** check the spelling/capitalization of `category` against `config/theme.config.js`.
- **A command is listed but not implemented:** check `commands/placeholders.js`; those entries intentionally report that their integration is pending.
- **A group command fails:** check whether it requires a group, group-admin privileges, or bot-admin privileges.
- **An API request fails:** verify the endpoint, parameters, API status code, response schema, and timeout. Avoid hiding failures behind a success message.
- **Anti-delete/anti-edit does not report an older message:** tracking starts only after the relevant feature is enabled and the bot receives a message while connected. Media retention is bounded; view-once media is excluded.
- **Custom prefix does not take effect:** make sure you used `.setprefix !` with the current prefix first, then use the new prefix (for example, `!menu`).

## News commands

Use `.news` or `.n` to display the news menu and short source codes. Source codes include `bbc`, `cnn`, `punch`, `aj`, `gd`, `nyt`, `fox`, `sky`, `dw`, `f24`, `wp`, `toi`, `npr`, and `abc`.

Examples:

```text
.news bbc 5
.n punch 5
.news all 1
```

A single source accepts 1–10 headlines; `all` accepts 1–2 headlines per source to keep WhatsApp messages manageable. The command reads RSS/Atom feeds from the URLs supplied in the news-source configuration, follows article links, and tries the source homepage if a feed fails. No extra npm dependency or API key is required. Some publishers may block requests or change their feed format, so individual sources can occasionally be unavailable.

## Fun commands v2

The new commands live in `commands/fun-v2.js`; the original `commands/fun.js` and other custom modules were not replaced. Existing `.quote` and `.fact` commands are preserved, while the new versions are `.quote2` and `.fact2`.

Available commands: `.joke`, `.dadjoke`, `.progjoke`, `.chuck`, `.fact2`, `.catfact`, `.dog`, `.cat`, `.fox`, `.advice`, `.quote2`, `.trivia`, `.meme`, `.numfact`, `.activity`, `.pokemon`, `.history`, `.riddle`, `.wiki`, and `.nasa`.

The integrations use the endpoints supplied in the Python script and Node.js's built-in `fetch`. No extra npm package is required. Trivia and riddles reveal their answer in a separate message after a short pause. The meme command skips items marked NSFW or spoiler, but third-party feeds can still be inaccurate or unavailable. NASA's public `DEMO_KEY` has usage limits, and any source may change or rate-limit its endpoint.

## Canvas commands

Canvas image generators use the Xrina API. Separate multiple values with a vertical bar (`|`); text-only commands accept the text directly. The generated image is sent back to the chat.

```text
.fakettc Name | Message
.wndwqute Your quote text
.canvasquote Quote text | Author name
.nokiamsg Message | Sender | Date
.meme2 Username | Meme text
.fakeff Player name | Lobby number
.fakeffduo Player one | Player two
.iqc Message text | 13:34
.ffgirl Username
```

The canvas police-meme generator uses `.meme2` because `.meme` is already registered for the existing random-meme command.

## Downloaders v2

Three Xrina download commands were added without replacing existing downloader names:

| Command | Usage |
| --- | --- |
| `.aio` | `.aio https://link-to-supported-media` |
| `.play2` | `.play2 song title or artist` |
| `.tiktok2` | `.tiktok2 https://www.tiktok.com/...` |

`.aio` selects a directly downloadable video or audio format when available; otherwise it uses an available direct file format. `.play2` searches for a song and sends the returned audio. `.tiktok2` sends a TikTok video when the service returns a valid HTTPS media URL. These commands rely on the third-party service's availability and returned links.

## Anime commands v2

The new anime commands live in `commands/anime-v2.js`. The original modules and custom commands are not replaced. Your existing `.waifu` command remains available; this added anime-image version uses `.waifu2` to avoid a duplicate command name. The help menu is available through `.animemenu` or `.animehelp`.

**Info and search:** `.anime <title>`, `.manga <title>`, `.character <name>`, `.charpic <name>`, `.staff <name>`, `.studio <name>`, `.recommend <anime>`, `.episodes <anime>`, `.animechars <anime>`, `.trailer <anime>`, `.pictures <anime>`, `.streaming <anime>`, `.review <anime>`, `.genres`, and `.genre <genre>`.

**Rankings and schedule:** `.topanime`, `.topmanga`, `.popular`, `.favorite`, `.airing`, `.upcoming`, `.trending`, `.season`, `.topchars`, `.schedule [weekday]`, and `.nextep <anime>`.

**Random and tools:** `.randomanime`, `.randommanga`, `.randomchar`, `.animequote`, and `.whatanime <public HTTPS screenshot URL>`.

**Images:** `.waifu2`, `.husbando`, `.neko`, and `.kitsune`. **Reaction GIFs:** `.angry`, `.baka`, `.bite`, `.bleh`, `.blowkiss`, `.blush`, `.bonk`, `.bored`, `.carry`, `.clap`, `.confused`, `.cry`, `.cuddle`, `.dance`, `.facepalm`, `.feed`, `.handhold`, `.handshake`, `.happy`, `.highfive`, `.hug`, `.kabedon`, `.kick2`, `.kiss`, `.lappillow`, `.laugh`, `.lurk`, `.nod`, `.nom`, `.nope`, `.nya`, `.pat`, `.peck`, `.poke`, `.pout`, `.punch`, `.run`, `.salute`, `.shake`, `.shoot`, `.shocked`, `.shrug`, `.sip`, `.slap`, `.sleep`, `.smile`, `.smug`, `.spin`, `.stare`, `.tableflip`, `.teehee`, `.think`, `.thumbsup`, `.tickle`, `.wag`, `.wave`, `.wink`, `.yawn`, and `.yeet`.

AniList queries explicitly exclude media marked adult and filter out the `Hentai` and `Ecchi` genres from media lists. The screenshot-identification command only accepts public HTTPS URLs. Requests use Node.js's built-in `fetch`, so no extra npm dependency or API key is required. AniList can rate-limit requests; nekos.best requires a meaningful User-Agent; Animechan and trace.moe availability and quotas are controlled by their providers. Reaction GIFs are sent as WhatsApp GIF-style video messages; compatibility can vary by returned file and WhatsApp client.
## Word Chain game

Use `.wcg` or `.wrg` to open a 60-second multiplayer Word Chain lobby in a group or through private-DM matchmaking. **FEI XMD is the judge, never a player.** Every human who wants to play must type `join`. If exactly one player has joined when the first 60 seconds expire, the lobby keeps extending in 60-second intervals until another person joins; it does not discard the player or declare a winner. Once at least two people have joined, the game starts and continues through eliminations until one champion remains.

The bot reminds everyone when 30 seconds and 15 seconds remain in the lobby, showing how many players have joined. At the end of 60 seconds, the game starts if at least two human players joined. During a turn, the bot tags the current player once when 5 seconds remain. In a group, players join in that group. For a private match, each participant messages FEI XMD in their own DM and types `join` while the private lobby is open; the bot sends game updates to each participant's DM. Only one private-DM matchmaking lobby can run at a time, while separate groups can run their own games.

The first player must submit an English word with at least 4 letters; longer words are allowed. Every later word must start with the previous word's final letter. Each accepted word raises the minimum required length by one, up to 12 letters, and reduces the next turn's timer by one second, down to 5 seconds. The active player has 30 seconds for the first turn. Each player gets one answer per turn: a short, repeated, unrecognised, multi-word, or wrong-letter answer eliminates that player. After the opening turn has been given a fair chance, a player who runs out of time is eliminated; if no one submits the very first word, the game offers another opening window rather than immediately eliminating anyone. The last surviving player becomes champion.

The final report crowns the last survivor as the **GAME CHAMPION** and includes total valid words, the longest word and its length, the highest required length reached, and game duration.

Use `.wcg rules` for the rules or `.wcg end` to cancel. Only the lobby starter or bot owner can cancel. Game state is kept in memory and resets if the bot process restarts. English words are checked against the bundled word list first and the free Dictionary API as a fallback; if the service cannot verify a word, it is allowed.

## Command modules and current limitations

The live `.menu` output is the most reliable list of commands currently registered by the running code. Module contents can change as features are added.

The commands in `commands/placeholders.js` that remain reserved are `toimg`, `qr`, `shorturl`, and `weather`. Sticker conversion is implemented separately in `commands/sticker.js`; it uses FFmpeg to convert regular images and short videos into WebP stickers.

Anti-delete and anti-edit tracking operates on messages received after the relevant setting is enabled and while FEI XMD is connected. Anti-delete may restore cached text/captions and eligible non-view-once media up to 8 MB per file, with a 32 MB in-memory media-cache limit. Large or unavailable media may not be retained, and the in-memory cache is cleared when the process restarts.

The `.menu` and `.channel` commands include native WhatsApp View channel attribution when the channel JID is configured. Other command interactions include it randomly about 40% of the time.

## Security notes

- Never commit `.env`, `auth_info_baileys/`, Telegram bot tokens, pairing codes, or other credentials.
- Treat the linked WhatsApp session as account access. Do not share the session folder.
- Keep API keys server-side and in environment variables; never hard-code private keys into commands.
- Validate user input, limit request lengths, use timeouts, and check API responses before sending results.
- Restrict owner-only operations and require the appropriate group permissions for moderation commands.
- Test features in a private test chat/group before deploying to an active community.


## Auto status view and sticker

- Use `.autostatus on` to automatically view new status updates received from contacts, and `.autostatus off` to disable it. The command is global and owner-only. The previous `.autoview` command remains available as an alias.
- Status auto-reactions remain a separate setting: `.statusreact on/off` controls reactions and `.statusreactmode` selects the emoji. While `.statusreact` is on, FEI XMD also marks received statuses as read, even if `.autostatus` is off.
- Use `.sticker` as an image/video caption, or reply to a normal image or video with `.sticker`. Short videos are converted into animated WebP stickers. View-once media is deliberately rejected, input media is limited to 16 MB, and temporary conversion files are removed after processing.
- The Docker runtime installs FFmpeg automatically. For local execution, install FFmpeg and make sure the `ffmpeg` executable is available on your system `PATH`.



## Telegram multi-session manager

FEI XMD runs one Telegram polling controller and launches one separate Node.js worker process for each additional WhatsApp account. Only the controller polls the Telegram bot token. Each secondary account has its own auth folder and `FEI_DATA_DIR`, so message caches, feature toggles, prefix, and private/public mode do not leak between linked accounts.

Telegram commands (private chat, authorized numeric Telegram user ID only):

- `/pair 2348012345678` — pair the primary account when it is not linked yet.
- `/pair bot2 2348098765432` — add a named secondary account.
- `/sessions` or `/status` — list accounts and current connection states.
- `/status bot2` — check one account by label or number.
- `/delsession 2348098765432` or `/delsession bot2` — log out and remove that account's stored credentials and settings.

The default limit is two accounts total (primary + one secondary). Set `FEI_MAX_SESSIONS` to a higher integer only after checking that the Fly Machine has enough RAM. More workers mean more memory use, and the limit can be set from 1 to 10. Keep exactly one Fly Machine attached to the persistent volume; do not horizontally scale this app because Fly Volumes are not shared between Machines. Keep the persistent `/data` volume mounted so session registrations and credentials survive deployments.


## Presence and offline anti-delete recovery

Use `.online on` to keep FEI XMD's WhatsApp online presence refreshed, or `.online off` to announce unavailable and stop the heartbeat. The previous `.alwayson on/off` command remains an alias. This controls the presence sent by the linked bot session; it cannot determine whether the account owner is physically using their phone.

Use `.antidel on` to enable anti-delete globally across private chats and groups, including messages from people who are not saved in contacts. Use `.antidel off` to turn it off globally and clear legacy per-chat anti-delete switches. Alerts show the sender's saved/profile name or phone number/WhatsApp ID when available and include the originating group name for group messages.

When anti-delete is enabled, eligible messages and downloaded media are persisted in `FEI_DATA_DIR/antidelete-cache` so they can survive a bot restart or temporary disconnection. The cache is bounded to 1,200 messages, 8 MB per media file, and 32 MB of media in memory. On Fly.io, keep the existing `/data` volume mounted. Recovery still depends on FEI XMD having received and cached the original message before it was deleted and WhatsApp delivering a deletion event after reconnecting; messages sent and deleted while the bot is entirely disconnected cannot reliably be recovered. View-once content remains excluded from this cache and is not restored by anti-delete.
