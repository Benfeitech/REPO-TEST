import "dotenv/config";

import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  Browsers,
  fetchLatestWaWebVersion
} from "@whiskeysockets/baileys";
import pino from "pino";
import fs from "node:fs/promises";
import readline from "node:readline/promises";
import { stdin, stdout } from "node:process";

import config from "./config/bot.config.js";
import theme from "./config/theme.config.js";
import { loadCommands } from "./handlers/command-loader.js";
import { loadBotState, saveBotState, isValidPrefix } from "./lib/state.js";
import { startTelegramPairingBot } from "./lib/telegram.js";
import { createSessionManager } from "./lib/session-manager.js";
import { sendAttributedMessage, sendReply } from "./lib/channel.js";
import { buildMenu } from "./lib/menu.js";
import { unicodeBox } from "./lib/api-client.js";
import { getChatSettings, isBotCommandBannedForSender } from "./lib/feature-state.js";
import { recordPresenceUpdate } from "./lib/presence-tracker.js";
import { wordChainGame } from "./lib/wcg-game.js";
import { createWordChainEchoGuard } from "./lib/wcg-echo.js";
import { createMessageStore, installMessageStore } from "./lib/message-store.js";
import { createGroupHistory } from "./lib/group-history.js";
import { canRunCommand, shouldProcessUpsertMessage } from "./lib/command-policy.js";
import { enforceAntibotMessage, handleIncomingFeatureMessage, handleDeletedMessages, handleMessageUpdates, handleParticipantUpdate, handleCallEvent, flushAntiDeleteCache } from "./lib/baileys-events.js";
import {
  extractText,
  getContextInfo,
  getMessageAgeMs,
  getQuotedMessage,
  getSenderJid,
  isHalfPaired,
  isOwnerMessage,
  isPaired,
  getSelfJid,
  unwrapMessage
} from "./lib/utils.js";
import {
  getViewOnceReplyEmojiCommand,
  hasViewOnceWrapperDeep
} from "./lib/view-once-shortcuts.js";
import { isHidetagEmojiText } from "./lib/tag-emoji-shortcut.js";

const SESSION_DIR = String(process.env.FEI_SESSION_DIR || "./auth_info_baileys").trim();
const IS_SESSION_WORKER = process.env.FEI_SESSION_WORKER === "1";
const MAX_RECONNECTS = 8;
const logger = pino({ level: "silent" });
const processedMessageIds = new Set();
const wordChainEchoGuard = createWordChainEchoGuard();
const messageStore = createMessageStore(1000);
const groupHistory = createGroupHistory({
  dataDirectory: process.env.FEI_DATA_DIR || "./data",
  sessionId: process.env.FEI_SESSION_ID || (IS_SESSION_WORKER ? "session" : "primary"),
  maxMessagesPerGroup: process.env.FEI_GROUP_HISTORY_LIMIT || 500
});
const runtime = { connectionOpen: false, mode: config.defaultMode };

let commandDefinitions = [];
let commandLookup = new Map();
let activeSocket = null;
let activeCreds = null;
let stopped = false;
let loggedOut = false;
let reconnectAttempts = 0;
let reconnectTimer = null;
let welcomeSent = false;
let pairingInProgress = false;
let pairingDeferred = createDeferred();
let stopTelegram = null;
let stopSessionManager = null;
let sessionManager = null;
let presenceHeartbeat = null;
let connectionOpenedAt = 0;

function createDeferred() {
  let resolve;
  const promise = new Promise(done => { resolve = done; });
  return { promise, resolve };
}

const sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));

function connectionNotice() {
  return unicodeBox("✅ ғᴇɪ xᴍᴅ ᴄᴏɴɴᴇᴄᴛᴇᴅ", [
    "Status: ONLINE 🟢",
    "🤖 FEI XMD is now running.",
    "📩 Send " + config.prefix + "menu to view all commands.",
    "📢 Tap View channel to follow " + config.channel.name + "."
  ].join("\n"), { footer: false });
}

async function waitForPairingReady(timeoutMs = 45000) {
  if (activeCreds && isPaired(activeCreds)) throw new Error("This WhatsApp session is already paired.");
  const current = pairingDeferred;
  let timeout;
  try {
    await Promise.race([
      current.promise,
      new Promise((_, reject) => {
        timeout = setTimeout(() => {
          reject(new Error("WhatsApp has not finished its initial handshake. Wait briefly and request a new pairing code."));
        }, timeoutMs);
      })
    ]);
  } finally {
    clearTimeout(timeout);
  }

  if (!activeSocket || (activeSocket.ws && activeSocket.ws.readyState === 3)) {
    throw new Error("The WhatsApp connection closed. Restart FEI XMD and try again.");
  }
}

async function requestPairingCode(phoneNumber) {
  const digits = String(phoneNumber || "").replace(/\D/g, "");
  if (!/^\d{8,15}$/.test(digits)) throw new Error("Use a valid international phone number with country code, digits only.");
  if (!activeSocket || !activeCreds) throw new Error("WhatsApp is still starting. Try the pairing request again in a few seconds.");
  if (isPaired(activeCreds)) throw new Error("This WhatsApp session is already paired. Use /pair with another number to add a session.");
  if (pairingInProgress) throw new Error("A pairing request is already being processed. Please wait for it to finish.");

  pairingInProgress = true;
  try {
    await waitForPairingReady();
    await sleep(900);
    if (!activeSocket || isPaired(activeCreds)) throw new Error("The session state changed. Restart FEI XMD before requesting another code.");
    return String(await activeSocket.requestPairingCode(digits));
  } catch (error) {
    throw new Error(error && error.message ? error.message : "Could not create a pairing code. Restart FEI XMD and try again.");
  } finally {
    pairingInProgress = false;
  }
}

function sendWorkerMessage(message, callback) {
  if (typeof process.send !== "function") {
    if (typeof callback === "function") callback();
    return;
  }
  try {
    process.send(message, callback);
  } catch (error) {
    if (typeof callback === "function") callback(error);
  }
}

function notifyWorkerStatus(status = "") {
  if (!IS_SESSION_WORKER || typeof process.send !== "function") return;
  const paired = isPaired(activeCreds);
  const connected = Boolean(runtime.connectionOpen);
  sendWorkerMessage({
    type: "worker-status",
    sessionId: String(process.env.FEI_SESSION_ID || "session"),
    phoneNumber: String(process.env.FEI_SESSION_PHONE || ""),
    paired,
    connected,
    status: status || (connected ? "connected" : paired ? "disconnected" : "awaiting-pairing")
  });
}

async function handleWorkerMessage(message) {
  if (!IS_SESSION_WORKER || !message || typeof message !== "object") return;

  if (message.type === "request-pairing-code") {
    try {
      const code = await requestPairingCode(message.phoneNumber);
      sendWorkerMessage({ type: "worker-response", requestId: message.requestId, ok: true, code });
    } catch (error) {
      sendWorkerMessage({
        type: "worker-response",
        requestId: message.requestId,
        ok: false,
        error: String(error && error.message || "Could not create a pairing code.")
      });
    }
    return;
  }

  if (message.type === "delete-session") {
    stopped = true;
    loggedOut = true;
    runtime.connectionOpen = false;
    clearTimeout(reconnectTimer);
    if (presenceHeartbeat) clearInterval(presenceHeartbeat);
    const oldSocket = activeSocket;
    activeSocket = null;

    try {
      if (oldSocket && typeof oldSocket.logout === "function") {
        await Promise.race([
          oldSocket.logout().catch(() => {}),
          sleep(4000)
        ]);
      } else if (oldSocket && typeof oldSocket.end === "function") {
        oldSocket.end(undefined);
      }
    } catch {}

    try {
      await fs.rm(SESSION_DIR, { recursive: true, force: true });
      sendWorkerMessage(
        { type: "worker-response", requestId: message.requestId, ok: true, message: "Logged out and removed local credentials." },
        () => process.exit(0)
      );
      setTimeout(() => process.exit(0), 750);
    } catch (error) {
      sendWorkerMessage({
        type: "worker-response",
        requestId: message.requestId,
        ok: false,
        error: "Could not remove the local session files: " + String(error && error.message || error)
      });
    }
  }
}

async function deletePrimarySession() {
  const oldSocket = activeSocket;
  activeSocket = null;
  runtime.connectionOpen = false;
  loggedOut = true;
  pairingInProgress = false;
  clearTimeout(reconnectTimer);
  reconnectTimer = null;
  if (presenceHeartbeat) clearInterval(presenceHeartbeat);
  presenceHeartbeat = null;

  try {
    if (oldSocket && typeof oldSocket.logout === "function") {
      await Promise.race([
        oldSocket.logout().catch(() => {}),
        sleep(4000)
      ]);
    } else if (oldSocket && typeof oldSocket.end === "function") {
      oldSocket.end(undefined);
    }
  } catch {}

  await fs.rm(SESSION_DIR, { recursive: true, force: true });
  activeCreds = null;
  pairingDeferred = createDeferred();
  welcomeSent = false;
  reconnectAttempts = 0;
  loggedOut = false;
  stopped = false;
  await startSocket();
}

function getPrimarySessionStatus() {
  const ownJid = (activeSocket && getSelfJid(activeSocket)) ||
    (activeCreds && activeCreds.me && activeCreds.me.id) || "";
  const phoneNumber = String(ownJid).split("@")[0].split(":")[0].replace(/\D/g, "");
  const paired = isPaired(activeCreds);
  return {
    phoneNumber,
    paired,
    connected: Boolean(runtime.connectionOpen),
    status: runtime.connectionOpen ? "connected" : paired ? "disconnected" : "awaiting-pairing"
  };
}

function scheduleReconnect() {
  if (stopped || loggedOut || reconnectTimer) return;
  if (reconnectAttempts >= MAX_RECONNECTS) {
    console.error("Maximum reconnect attempts reached. Restart FEI XMD manually.");
    return;
  }
  reconnectAttempts += 1;
  const delay = Math.min(30000, 3000 * (2 ** (reconnectAttempts - 1)));
  console.log("Reconnecting in " + Math.round(delay / 1000) + " seconds (" + reconnectAttempts + "/" + MAX_RECONNECTS + ")...");

  reconnectTimer = setTimeout(async () => {
    reconnectTimer = null;
    try {
      await startSocket();
    } catch (error) {
      console.error("Reconnect error:", error && error.message);
      scheduleReconnect();
    }
  }, delay);
}

let wordChainTicker = null;
let wordChainTickBusy = false;

function sendWordChainMessages(sock, messages) {
  let startAnnouncementChat = null;
  return messages.reduce((promise, item) => promise.then(async () => {
    if (!sock || sock !== activeSocket || !item || !item.chat) return;
    try {
      const text = String(item.text || "");
      const echoToken = wordChainEchoGuard.beginSend(item.chat, text);
      try {
        const sent = await sendAttributedMessage(sock, item.chat, {
          text,
          mentions: Array.isArray(item.mentions) ? item.mentions : []
        }, config, null, false);
        wordChainEchoGuard.sent(echoToken, sent && sent.key && sent.key.id);
        if (/WORD CHAIN STARTED/i.test(text)) startAnnouncementChat = item.chat;
      } catch (error) {
        wordChainEchoGuard.failed(echoToken);
        throw error;
      }
    } catch (error) {
      console.warn("Word Chain message failed:", error && error.message);
    }
  }), Promise.resolve()).then(() => {
    // Start the opening clock after the notice has been sent to every match participant.
    if (startAnnouncementChat) wordChainGame.markStartAnnounced(startAnnouncementChat, Date.now());
  });
}

async function handleViewOnceEmojiShortcut(sock, msg, text) {
  const body = unwrapMessage(msg.message);

  // A WhatsApp reaction is not a reply command. Never turn reactions like ❤️ or 👍
  // into view-once commands; these shortcuts run only when the owner replies with
  // the emoji as message text.
  if (body && body.reactionMessage) return false;

  const contextInfo = getContextInfo(msg.message) || {};
  const shortcutCommand = getViewOnceReplyEmojiCommand(text, contextInfo, config.prefix);
  if (!shortcutCommand) return false;

  const senderJid = getSenderJid(msg, sock);
  if (!isOwnerMessage(msg, senderJid, sock, config)) return false;

  let quoted = getQuotedMessage(msg);
  if (contextInfo.stanzaId) {
    // WhatsApp can omit the view-once wrapper from quotedMessage. Prefer the
    // original cached envelope when it is available so Baileys gets the flags.
    const storedTarget = await messageStore.getMessage({
      remoteJid: (msg.key && msg.key.remoteJid) || "",
      id: contextInfo.stanzaId
    });
    if (hasViewOnceWrapperDeep(storedTarget)) quoted = storedTarget;
  }

  // Keep shortcuts out of the menu. The emoji only acts as a command when sent
  // as a reply; reacting with the same emoji to a message is ignored here.
  const synthetic = {
    ...msg,
    __feiEmojiShortcut: true,
    message: {
      extendedTextMessage: {
        text: config.prefix + shortcutCommand,
        contextInfo: { ...contextInfo, ...(quoted ? { quotedMessage: quoted } : {}) }
      }
    }
  };
  await handleCommand(sock, synthetic);
  return true;
}

async function handleHidetagEmojiShortcut(sock, msg) {
  const body = unwrapMessage(msg.message);
  const reaction = body && body.reactionMessage;
  const emoji = String(reaction && reaction.text || "")
    .trim().normalize("NFC").replace(/\uFE0F/g, "");
  if (emoji !== "👋") return false;

  const jid = String(msg.key && msg.key.remoteJid || "");
  const targetKey = reaction && reaction.key;
  if (!jid.endsWith("@g.us") || !targetKey || !targetKey.id ||
      (targetKey.remoteJid && targetKey.remoteJid !== jid)) return false;

  // The wave reaction is an alias for the hidden-tag command in group chats.
  // The command itself enforces the group's admin requirements.
  const synthetic = {
    ...msg,
    __feiEmojiShortcut: true,
    __feiReactionKey: targetKey,
    message: {
      extendedTextMessage: {
        text: config.prefix + "hidetag",
        contextInfo: {}
      }
    }
  };
  await handleCommand(sock, synthetic);
  return true;
}


async function handleHidetagTextShortcut(sock, msg, text) {
  const jid = String(msg && msg.key && msg.key.remoteJid || "");
  if (!jid.endsWith("@g.us")) return false;
  if (!isHidetagEmojiText(text, config.prefix)) return false;

  const synthetic = {
    ...msg,
    __feiEmojiShortcut: true,
    message: {
      extendedTextMessage: {
        text: config.prefix + "hidetag",
        contextInfo: {}
      }
    }
  };
  await handleCommand(sock, synthetic);
  return true;
}

async function handleSaveEmojiShortcut(sock, msg, text) {
  const normalized = String(text || "").trim().normalize("NFC").replace(/\uFE0F/g, "");
  if (normalized !== "💯" && normalized !== "🙂") return false;

  const body = unwrapMessage(msg.message);
  if (body && body.reactionMessage) return false;

  const contextInfo = getContextInfo(msg.message) || {};
  if (!contextInfo.stanzaId) return false;

  const synthetic = {
    ...msg,
    __feiEmojiShortcut: true,
    message: {
      extendedTextMessage: {
        text: config.prefix + "save",
        contextInfo
      }
    }
  };
  await handleCommand(sock, synthetic);
  return true;
}

function startWordChainTicker() {
  if (wordChainTicker) clearInterval(wordChainTicker);
  wordChainTicker = setInterval(async () => {
    if (wordChainTickBusy || !activeSocket || !runtime.connectionOpen) return;
    wordChainTickBusy = true;
    try {
      const messages = wordChainGame.tick(Date.now());
      await sendWordChainMessages(activeSocket, messages);
    } catch (error) {
      console.warn("Word Chain timer failed:", error && error.message);
    } finally {
      wordChainTickBusy = false;
    }
  }, 1000);
  if (typeof wordChainTicker.unref === "function") wordChainTicker.unref();
}

async function startSocket() {
  if (stopped || loggedOut) return;
  connectionOpenedAt = 0;
  console.log("\nConnecting FEI XMD to WhatsApp...");
  let session = await useMultiFileAuthState(SESSION_DIR);

  if (isHalfPaired(session.state.creds)) {
    console.log("Removing a leftover half-finished pairing session...");
    await fs.rm(SESSION_DIR, { recursive: true, force: true });
    session = await useMultiFileAuthState(SESSION_DIR);
  }

  activeCreds = session.state.creds;
  pairingDeferred = createDeferred();
  if (isPaired(activeCreds)) pairingDeferred.resolve();

  let version;
  try {
    const latest = await fetchLatestWaWebVersion();
    version = latest.version;
    console.log("WhatsApp Web version: " + version.join("."));
    if (!latest.isLatest) console.warn("Using Baileys bundled WhatsApp Web version because the live version could not be confirmed.");
  } catch {
    console.warn("Could not fetch latest WhatsApp Web version; using the installed library fallback.");
  }

  const sock = makeWASocket({
    ...(version ? { version } : {}),
    auth: session.state,
    logger,
    browser: Browsers.ubuntu("Chrome"),
    printQRInTerminal: false,
    syncFullHistory: false,
    markOnlineOnConnect: false,
    enableAutoSessionRecreation: true,
    getMessage: key => messageStore.getMessage(key)
  });

  installMessageStore(sock, messageStore);
  activeSocket = sock;
  if (presenceHeartbeat) clearInterval(presenceHeartbeat);
  presenceHeartbeat = setInterval(async () => {
    if (sock !== activeSocket) return;
    try {
      const settings = await getChatSettings("global");
      if (settings.alwayson) await sock.sendPresenceUpdate("available");
    } catch {}
  }, 25000);
  if (typeof presenceHeartbeat.unref === "function") presenceHeartbeat.unref();
  sock.ev.on("presence.update", update => {
    recordPresenceUpdate(update);
  });
  sock.ev.on("creds.update", async () => {
    if (sock !== activeSocket) return;
    await session.saveCreds();
    notifyWorkerStatus();
  });

  sock.ev.on("connection.update", async update => {
    const connection = update.connection;
    const lastDisconnect = update.lastDisconnect;
    if (sock !== activeSocket) return;
    if (update.qr && !isPaired(activeCreds)) {
      pairingDeferred.resolve();
      notifyWorkerStatus("awaiting-pairing");
    }

    if (connection === "open") {
      runtime.connectionOpen = true;
      connectionOpenedAt = Date.now();
      reconnectAttempts = 0;
      notifyWorkerStatus("connected");
      console.log("\nFEI XMD v" + config.version + " is online.");

      if (!welcomeSent) {
        const selfJid = getSelfJid(sock);
        if (selfJid) {
          try {
            const message = config.imageUrl
              ? { image: { url: config.imageUrl }, caption: connectionNotice() }
              : { text: connectionNotice() };
            await sendAttributedMessage(sock, selfJid, message, config, null, true);
            welcomeSent = true;
          } catch (error) {
            console.error("Could not send the connection notice:", error && error.message);
            try {
              await sendAttributedMessage(sock, selfJid, { text: connectionNotice() }, config, null, true);
              welcomeSent = true;
            } catch {
              console.error("Connection notice fallback failed.");
            }
          }
        }
      }
    }

    if (connection === "close") {
      runtime.connectionOpen = false;
      connectionOpenedAt = 0;
      const status = lastDisconnect && lastDisconnect.error &&
        lastDisconnect.error.output && lastDisconnect.error.output.statusCode;
      const unpaired = !isPaired(activeCreds);
      console.log("Connection closed. Status: " + (status == null ? "unknown" : status));

      if (status === 405) console.warn("WhatsApp rejected this client version. Check for a Baileys update.");
      else if (status === DisconnectReason.restartRequired) console.log("WhatsApp requested a socket restart.");
      else if (status === DisconnectReason.timedOut) console.log("WhatsApp connection timed out.");

      if (status === DisconnectReason.loggedOut) {
        loggedOut = true;
        notifyWorkerStatus("logged-out");
        console.error("WhatsApp session logged out. Remove your local session folder and restart to pair again.");
        return;
      }
      notifyWorkerStatus(unpaired ? "awaiting-pairing" : "disconnected");
      if (unpaired && status !== DisconnectReason.restartRequired) {
        await fs.rm(SESSION_DIR, { recursive: true, force: true }).catch(() => {});
      }
      scheduleReconnect();
    }
  });

  sock.ev.on("messages.upsert", async payload => {
    if (payload.type !== "notify" && payload.type !== "append") return;
    for (const msg of payload.messages || []) {
      const jid = msg.key && msg.key.remoteJid;
      if (!jid || !msg.message) continue;
      // Keep recent inbound and self-sent messages available for WhatsApp retry requests.
      messageStore.remember(msg);

      const messageAgeMs = payload.type === "append" && jid !== "status@broadcast"
        ? getMessageAgeMs(msg)
        : null;
      if (!shouldProcessUpsertMessage(
        payload.type,
        jid,
        msg,
        messageAgeMs,
        connectionOpenedAt,
        config.maxAppendAgeMs
      )) continue;

      const text = extractText(msg.message);
      if (jid.endsWith("@g.us")) {
        try {
          await groupHistory.record(msg, {
            senderJid: getSenderJid(msg, sock),
            senderName: msg.pushName,
            text,
            isBotCommand: text.startsWith(config.prefix)
          });
        } catch (error) {
          console.warn("Group message history tracking failed:", error && error.message || error);
        }
      }

      // Enforce group antibot before any feature handlers or bot commands run.
      if (await enforceAntibotMessage(sock, msg, config)) continue;
      const featureAction = await handleIncomingFeatureMessage(sock, msg, config);
      if (featureAction === "blocked-command") continue;
      if (jid.endsWith("@broadcast") || jid.endsWith("@newsletter")) continue;
      const normalizedShortcutText = String(text || "").trim().normalize("NFC").replace(/\uFE0F/g, "");
      const isCommandShortcut = isHidetagEmojiText(text, config.prefix) ||
        ["💯", "🙂"].includes(normalizedShortcutText);
      if (isCommandShortcut && await isBotCommandBannedForSender(sock, getSenderJid(msg, sock))) {
        await sendReply(sock, jid,
          "🚫 Your access to FEI XMD commands is suspended. Contact the bot owner to request an unban.",
          msg, config, {}, false
        ).catch(() => {});
        continue;
      }
      if (await handleViewOnceEmojiShortcut(sock, msg, text)) continue;
      if (await handleHidetagEmojiShortcut(sock, msg)) continue;
      // Reactions are separate events, not message text or command replies.
      // Ignore other reactions so they cannot reach the emoji shortcuts or games.
      if (unwrapMessage(msg.message)?.reactionMessage) continue;
      if (await handleSaveEmojiShortcut(sock, msg, text)) continue;
      if (await handleHidetagTextShortcut(sock, msg, text)) continue;
      if (!text.startsWith(config.prefix)) {
        // Ignore only self-echoes of messages emitted by the Word Chain sender.
        // This does not suppress ordinary words typed from the bot's linked device.
        if (wordChainEchoGuard.shouldIgnore(msg, text)) continue;
        const senderJid = getSenderJid(msg, sock);
        if (wordChainGame.hasGame(jid) && await isBotCommandBannedForSender(sock, senderJid)) continue;
        const gameMessages = await wordChainGame.handle(jid, senderJid, text, msg.pushName, Date.now());
        await sendWordChainMessages(sock, gameMessages);
        continue;
      }

      const id = msg.key && msg.key.id;
      const messageKey = jid + ":" + String(id || "");
      if (id && processedMessageIds.has(messageKey)) continue;
      if (id) {
        processedMessageIds.add(messageKey);
        if (processedMessageIds.size > 1500) {
          const first = processedMessageIds.values().next().value;
          if (first) processedMessageIds.delete(first);
        }
      }
      await handleCommand(sock, msg);
    }
  });

  sock.ev.on("messages.delete", payload => {
    handleDeletedMessages(sock, payload).catch(error => console.warn("Message-delete tracking failed:", error && error.message));
  });
  sock.ev.on("messages.update", updates => {
    handleMessageUpdates(sock, updates).catch(error => console.warn("Message-update tracking failed:", error && error.message));
  });
  sock.ev.on("group-participants.update", update => {
    handleParticipantUpdate(sock, update).catch(error => console.warn("Participant event failed:", error && error.message));
  });
  sock.ev.on("call", calls => {
    handleCallEvent(sock, calls).catch(error => console.warn("Call event failed:", error && error.message));
  });
}

function reactionFor(definition) {
  if (definition.name === "menu") return "🌺";
  if (definition.category === "AI & Chat") return "🧠";
  if (definition.category === "Downloads") return "📥";
  if (definition.category === "Group") return "🛡️";
  if (definition.category === "Fun") return "🎉";
  if (definition.category === "Bot Settings") return "⚙️";
  if (definition.category === "Owner") return "👑";
  if (definition.category === "Media & Tools") return "🛠️";
  return "✨";
}

async function handleCommand(sock, msg) {
  const jid = msg.key && msg.key.remoteJid;
  if (!jid || !msg.message) return;
  const fullText = extractText(msg.message);
  if (!fullText.startsWith(config.prefix)) return;

  const body = fullText.slice(config.prefix.length).trim();
  const match = body.match(/^([^\s]+)(?:\s+([\s\S]*))?$/);
  if (!match) return;

  const commandName = match[1].toLowerCase().replace(/\.$/, "");
  const args = String(match[2] || "").trim();
  const senderJid = getSenderJid(msg, sock);
  const owner = isOwnerMessage(msg, senderJid, sock, config);

  if (!owner && await isBotCommandBannedForSender(sock, senderJid)) {
    await sendReply(
      sock, jid, "🚫 Your access to FEI XMD commands is suspended. Contact the bot owner to request an unban.",
      msg, config, {}, false
    ).catch(() => {});
    return;
  }

  // Enforce private mode before looking up the command so messages from group
  // members or other bots cannot provoke even an "unknown command" response.
  if (!canRunCommand(runtime.mode, owner)) return;

  const definition = commandLookup.get(commandName);
  if (!definition) {
    await sendReply(sock, jid, "❓ Unknown command: " + config.prefix + commandName +
      "\nType " + config.prefix + "menu to see available commands.", msg, config).catch(() => {});
    return;
  }

  const isWordChainCommand = ["wcg", "wrg"].includes(commandName) || ["wcg", "wrg"].includes(definition.name);
  const suppressChannelAttribution = new Set([
    "summarize", "summary", "ban", "unban", "warn", "warnlist", "antibot",
    "onlineusers", "getgcpp", "gicon", "setgcpp",
    "groupname", "setname", "groupdesc", "setdesc"
  ]);
  const includeChannelAttribution = !isWordChainCommand &&
    !suppressChannelAttribution.has(commandName) &&
    !suppressChannelAttribution.has(definition.name) &&
    (definition.name === "menu" || commandName === "channel" || Math.random() < 0.4);
  const ctx = {
    sock, msg, jid, command: commandName, args, senderJid, owner, config, theme,
    mode: runtime.mode,
    connectionOpen: runtime.connectionOpen,
    commands: commandDefinitions,
    groupHistory,
    reply: async (text, quoted = true, extra = {}) =>
      sendReply(sock, jid, text, quoted ? msg : null, config, extra, includeChannelAttribution),
    send: async (content, quoted = true, channelAttribution = includeChannelAttribution) =>
      sendAttributedMessage(sock, jid, content, config, quoted ? msg : null, channelAttribution),
    react: async emoji => {
      try {
        await sock.sendMessage(jid, { react: { text: String(emoji), key: msg.__feiReactionKey || msg.key } });
      } catch (error) {
        console.warn("Could not react to the command message.");
      }
    },
    setMode: async mode => {
      if (mode !== "private" && mode !== "public") throw new Error("Mode must be public or private.");
      await saveBotState({ mode, prefix: config.prefix });
      runtime.mode = mode;
    },
    setPrefix: async prefix => {
      if (!isValidPrefix(prefix)) {
        throw new Error("Prefix must be 1–3 symbols with no spaces or letters/numbers.");
      }
      await saveBotState({ mode: runtime.mode, prefix });
      config.prefix = prefix;
    },
    buildMenu: () => buildMenu({
      pushName: msg.pushName,
      mode: runtime.mode,
      connected: runtime.connectionOpen,
      config,
      theme,
      commands: commandDefinitions,
      uptimeSeconds: process.uptime()
    })
  };

  if (definition.ownerOnly && !owner) {
    await ctx.reply("⛔ This command is reserved for the bot owner.");
    return;
  }

  try {
    // React to the command before its response starts. Categories use consistent icons.
    if (!definition.noReaction && commandName !== "react" && commandName !== "vv2" && !msg.__feiEmojiShortcut) await ctx.react(reactionFor(definition));
    await definition.run(ctx);
  } catch (error) {
    console.error("Command ." + commandName + " failed:", error && (error.stack || error.message) || error);
    const detail = String((error && error.message) || "Unknown error").slice(0, 220);
    await ctx.reply("❌ The ." + commandName + " command failed.\n" + detail).catch(() => {});
  }
}

async function main() {
  console.log("\n╔══════════════════════════════╗\n" +
    "║           FEI XMD            ║\n" +
    "║       Modular bot v" + config.version + "      ║\n" +
    "╚══════════════════════════════╝\n");

  const loaded = await loadCommands();
  commandDefinitions = loaded.commands;
  commandLookup = loaded.lookup;
  const savedState = await loadBotState(config.defaultMode, config.prefix);
  runtime.mode = savedState.mode;
  config.prefix = savedState.prefix;
  wordChainGame.setPrefixProvider(() => config.prefix);
  await groupHistory.load();
  startWordChainTicker();
  console.log("Current mode: " + runtime.mode.toUpperCase());

  const shutdown = async () => {
    if (stopped) return;
    stopped = true;
    clearTimeout(reconnectTimer);
    if (presenceHeartbeat) clearInterval(presenceHeartbeat);
    if (wordChainTicker) clearInterval(wordChainTicker);
    if (stopTelegram) stopTelegram();
    if (stopSessionManager) {
      await stopSessionManager().catch(error => console.warn("Could not stop all session workers:", error && error.message));
    }
    await flushAntiDeleteCache().catch(error => console.warn("Could not flush anti-delete cache:", error && error.message));
    await groupHistory.flush().catch(error => console.warn("Could not flush group message history:", error && error.message));
    try { if (activeSocket) activeSocket.end(undefined); } catch {}
    console.log("\nFEI XMD stopped.");
    process.exit(0);
  };
  process.once("SIGINT", () => { void shutdown(); });
  process.once("SIGTERM", () => { void shutdown(); });

  if (IS_SESSION_WORKER) {
    process.on("message", message => { void handleWorkerMessage(message); });
  }

  await startSocket();

  if (IS_SESSION_WORKER) {
    const status = getPrimarySessionStatus();
    sendWorkerMessage({
      type: "worker-ready",
      sessionId: String(process.env.FEI_SESSION_ID || "session"),
      phoneNumber: String(process.env.FEI_SESSION_PHONE || ""),
      paired: status.paired,
      connected: status.connected,
      status: status.status
    });
    console.log("FEI XMD session worker ready: " + String(process.env.FEI_SESSION_ID || "session"));
    return;
  }

  if (config.pairingMethod === "telegram") {
    if (!config.telegramToken || !config.telegramAllowedUserIds.length) {
      throw new Error("Telegram pairing requires TELEGRAM_BOT_TOKEN and TELEGRAM_ALLOWED_USER_IDS in .env.");
    }
    sessionManager = createSessionManager({
      dataDirectory: process.env.FEI_DATA_DIR || "./data",
      maxSessions: process.env.FEI_MAX_SESSIONS || 2,
      getPrimaryStatus: getPrimarySessionStatus,
      requestPrimaryPairingCode: requestPairingCode,
      deletePrimarySession
    });
    await sessionManager.start();
    stopSessionManager = () => sessionManager.stop();

    stopTelegram = startTelegramPairingBot({
      token: config.telegramToken,
      allowedUserIds: config.telegramAllowedUserIds,
      requestPairingCode: sessionManager.requestPairingCode,
      getSessions: sessionManager.getSessions,
      getSessionStatus: sessionManager.getSessionStatus,
      deleteSession: sessionManager.deleteSession,
      maxSessions: sessionManager.maxSessions
    });
    if (!activeCreds || !isPaired(activeCreds)) {
      console.log("Waiting for an authorized Telegram user to send /pair COUNTRYCODE+NUMBER in a private chat.");
    }
    console.log("Telegram session manager initialized. Maximum total WhatsApp sessions: " + sessionManager.maxSessions);
    return;
  }

  if (!activeCreds || isPaired(activeCreds)) return;
  console.log("Waiting for WhatsApp pairing to become ready...");
  try {
    await waitForPairingReady(45000);
  } catch (error) {
    console.error(error.message);
    console.error("You can restart FEI XMD and try again.");
    return;
  }

  const prompt = readline.createInterface({ input: stdin, output: stdout });
  try {
    const phoneNumber = String(
      await prompt.question("Enter WhatsApp number with country code (digits only, e.g. 2348012345678): ")
    ).replace(/\D/g, "");
    if (!/^\d{8,15}$/.test(phoneNumber)) {
      console.error("Invalid number. Include country code, no + sign or spaces.");
      return;
    }

    const code = await requestPairingCode(phoneNumber);
    const pretty = (code.match(/.{1,4}/g) || [code]).join("-");
    console.log("\n╭━━━━━━━━━━━━━━━━━━━━━━━━━━╮\n" +
      "┃      FEI XMD PAIRING     ┃\n" +
      "┃      " + pretty + "       ┃\n" +
      "╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n" +
      "On your phone: WhatsApp > Settings > Linked Devices > Link a Device > Link with phone number instead.\n" +
      "Pairing codes expire quickly. Never share your code.");
  } catch (error) {
    console.error("Pairing failed:", error.message);
  } finally {
    prompt.close();
  }
}

main().catch(error => {
  console.error("FEI XMD startup error:", error && (error.stack || error.message) || error);
  process.exitCode = 1;
});
