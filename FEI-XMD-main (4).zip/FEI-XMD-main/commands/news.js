import { POWERED_FOOTER, unicodeBox } from "../lib/api-client.js";

export const NEWS_SOURCES = Object.freeze({
  aj: { name: "Al Jazeera", feedUrl: "https://www.aljazeera.com/xml/rss/all.xml", homeUrl: "https://www.aljazeera.com", aliases: ["aljazeera", "al-jazeera"] },
  cnn: { name: "CNN", feedUrl: "http://rss.cnn.com/rss/edition.rss", homeUrl: "https://edition.cnn.com", aliases: [] },
  bbc: { name: "BBC News", feedUrl: "https://feeds.bbci.co.uk/news/rss.xml", homeUrl: "https://www.bbc.com/news", aliases: [] },
  gd: { name: "The Guardian", feedUrl: "https://www.theguardian.com/world/rss", homeUrl: "https://www.theguardian.com", aliases: ["guardian"] },
  npr: { name: "NPR", feedUrl: "https://feeds.npr.org/1001/rss.xml", homeUrl: "https://www.npr.org/sections/news/", aliases: [] },
  nyt: { name: "New York Times", feedUrl: "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml", homeUrl: "https://www.nytimes.com", aliases: ["nytimes"] },
  fox: { name: "Fox News", feedUrl: "https://moxie.foxnews.com/google-publisher/latest.xml", homeUrl: "https://www.foxnews.com", aliases: ["foxnews"] },
  sky: { name: "Sky News", feedUrl: "https://feeds.skynews.com/feeds/rss/home.xml", homeUrl: "https://news.sky.com", aliases: [] },
  dw: { name: "DW", feedUrl: "https://rss.dw.com/rdf/rss-en-all", homeUrl: "https://www.dw.com/en/", aliases: [] },
  f24: { name: "France 24", feedUrl: "https://www.france24.com/en/rss", homeUrl: "https://www.france24.com/en/", aliases: ["france24"] },
  wp: { name: "Washington Post", feedUrl: "https://feeds.washingtonpost.com/rss/world", homeUrl: "https://www.washingtonpost.com", aliases: ["washingtonpost", "wapo"] },
  toi: { name: "Times of India", feedUrl: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms", homeUrl: "https://timesofindia.indiatimes.com", aliases: ["timesofindia"] },
  punch: { name: "Punch Nigeria", feedUrl: "https://punchng.com/feed/", homeUrl: "https://punchng.com", aliases: ["punchng"] },
  abc: { name: "ABC News (US)", feedUrl: "https://abcnews.go.com/abcnews/topstories", homeUrl: "https://abcnews.go.com", aliases: ["abcnews"] }
});

const REQUEST_HEADERS = {
  "user-agent": "Mozilla/5.0 (compatible; FEI-XMD-News/1.0; +https://github.com/Benfeitech/FEI-XMD)",
  accept: "application/rss+xml, application/atom+xml, application/xml, text/xml, text/html;q=0.8, */*;q=0.5"
};
const REQUEST_TIMEOUT_MS = 15000;
const MAX_DOCUMENT_CHARS = 4 * 1024 * 1024;
const MAX_MESSAGE_CHARS = 3000;

const sourceLookup = new Map();
for (const [code, source] of Object.entries(NEWS_SOURCES)) {
  sourceLookup.set(code, code);
  for (const alias of source.aliases) sourceLookup.set(alias, code);
  sourceLookup.set(source.name.toLowerCase(), code);
}

function decodeEntities(value) {
  return String(value || "")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&#x([0-9a-f]+);/gi, (_, digits) => {
      const point = Number.parseInt(digits, 16);
      return Number.isFinite(point) && point >= 0 && point <= 0x10ffff ? String.fromCodePoint(point) : " ";
    })
    .replace(/&#(\d+);/g, (_, digits) => {
      const point = Number.parseInt(digits, 10);
      return Number.isFinite(point) && point >= 0 && point <= 0x10ffff ? String.fromCodePoint(point) : " ";
    })
    .replace(/&nbsp;/gi, " ")
    .replace(/&quot;/gi, '"')
    .replace(/&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&amp;/gi, "&");
}

export function cleanNewsText(value, limit = 300) {
  let text = decodeEntities(value)
    .replace(/<[^>]*>/g, " ")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (text.length > limit) text = text.slice(0, Math.max(0, limit - 1)).trimEnd() + "…";
  return text;
}

function tagContent(block, localName) {
  const escaped = localName;
  const pattern = new RegExp(
    "<(?:[\\w.-]+:)?" + escaped + "\\b[^>]*>([\\s\\S]*?)<\\/(?:[\\w.-]+:)?" + escaped + "\\s*>",
    "i"
  );
  const match = String(block || "").match(pattern);
  return match ? match[1] : "";
}
function getTagText(block, names, limit) {
  for (const name of names) {
    const value = cleanNewsText(tagContent(block, name), limit);
    if (value) return value;
  }
  return "";
}

function resolveArticleUrl(value, baseUrl) {
  if (!value) return "";
  try {
    const url = new URL(decodeEntities(value).trim(), baseUrl);
    return url.protocol === "https:" || url.protocol === "http:" ? url.href : "";
  } catch {
    return "";
  }
}

function articleLink(block, baseUrl) {
  const tags = [...String(block || "").matchAll(
    /<(?:[\w.-]+:)?link\b([^>]*?)(?:\/>|>([\s\S]*?)<\/(?:[\w.-]+:)?link\s*>)/gi
  )];
  let fallback = "";

  for (const tag of tags) {
    const attributes = tag[1] || "";
    const hrefMatch = attributes.match(/\bhref\s*=\s*(["'])(.*?)\1/i);
    const relMatch = attributes.match(/\brel\s*=\s*(["'])(.*?)\1/i);
    const rel = (relMatch && relMatch[2] || "").toLowerCase();
    const href = hrefMatch ? hrefMatch[2] : cleanNewsText(tag[2] || "", 1000);
    const resolved = resolveArticleUrl(href, baseUrl);
    if (!resolved) continue;
    if (!rel || rel === "alternate") return resolved;
    if (!fallback) fallback = resolved;
  }

  return fallback;
}

export function parseNewsFeed(content, baseUrl, limit = 5) {
  const xml = String(content || "");
  const entryPattern = /<(?:[\w.-]+:)?(?:item|entry)\b[^>]*>[\s\S]*?<\/(?:[\w.-]+:)?(?:item|entry)\s*>/gi;
  const entries = xml.match(entryPattern) || [];
  const articles = [];

  for (const entry of entries) {
    const title = getTagText(entry, ["title"], 200);
    if (!title) continue;
    const summary = getTagText(entry, ["description", "summary", "encoded", "content"], 240);
    const date = getTagText(entry, ["pubDate", "published", "updated", "date"], 80);
    const link = articleLink(entry, baseUrl);
    articles.push({ title, link, summary, date });
    if (articles.length >= limit) break;
  }

  return articles;
}

function htmlAttribute(tag, name) {
  const text = String(tag || "");
  const pattern = new RegExp("\\b" + name + "\\s*=", "i");
  const match = pattern.exec(text);
  if (!match) return "";
  const start = match.index + match[0].length;
  const remainder = text.slice(start);
  const trimmed = remainder.trimStart();
  const quote = trimmed[0];
  if (quote !== "\"" && quote !== "'") return "";
  const valueStart = start + remainder.length - trimmed.length + 1;
  const end = text.indexOf(quote, valueStart);
  return end >= 0 ? text.slice(valueStart, end) : "";
}
async function fetchDocument(url, accept = REQUEST_HEADERS.accept) {
  const response = await fetch(url, {
    headers: { ...REQUEST_HEADERS, accept },
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    redirect: "follow"
  });

  if (!response.ok) throw new Error("HTTP " + response.status);
  const declaredSize = Number(response.headers.get("content-length") || 0);
  if (declaredSize > MAX_DOCUMENT_CHARS) throw new Error("The news source returned an oversized document.");

  const body = await response.text();
  if (body.length > MAX_DOCUMENT_CHARS) throw new Error("The news source returned an oversized document.");
  return body;
}

async function scrapeHomepage(source, limit) {
  const html = await fetchDocument(source.homeUrl, "text/html, application/xhtml+xml;q=0.9, */*;q=0.5");
  const headings = html.match(/<h[1-3]\b[^>]*>[\s\S]*?<\/h[1-3]\s*>/gi) || [];
  const seen = new Set();
  const articles = [];

  for (const heading of headings) {
    const title = cleanNewsText(heading, 200);
    if (title.length < 20 || seen.has(title)) continue;
    const anchorTag = heading.match(/<a\b[^>]*>/i);
    if (!anchorTag) continue;
    const href = htmlAttribute(anchorTag[0], "href");
    const link = resolveArticleUrl(href, source.homeUrl);
    if (!link) continue;
    seen.add(title);
    articles.push({ title, link, summary: "", date: "" });
    if (articles.length >= limit) break;
  }
  return articles;
}

async function fetchNews(source, limit) {
  let feedError;
  try {
    const xml = await fetchDocument(source.feedUrl);
    const articles = parseNewsFeed(xml, source.feedUrl, limit);
    if (articles.length) return articles;
    feedError = "the feed contained no readable headlines";
  } catch (error) {
    feedError = error && error.message ? error.message : "feed request failed";
  }

  try {
    const articles = await scrapeHomepage(source, limit);
    if (articles.length) return articles;
  } catch {}

  throw new Error("The RSS feed and website fallback were unavailable (" + feedError + ").");
}

function sourceMenu(ctx) {
  const lines = Object.entries(NEWS_SOURCES).map(([code, source]) => "• *" + code + "* — " + source.name);
  lines.push(
    "",
    "*Usage*",
    "• " + ctx.config.prefix + "news bbc 5 — five BBC headlines",
    "• " + ctx.config.prefix + "n punch 5 — five Punch Nigeria headlines",
    "• " + ctx.config.prefix + "news all 1 — one headline from each source",
    "",
    "_Individual sources: 1–10 stories. All sources: 1–2 stories per source._"
  );
  return unicodeBox("📰 ɴᴇᴡs ᴍᴇɴᴜ", lines.join("\n"), { footer: true });
}

async function mapWithLimit(items, concurrency, work) {
  const results = new Array(items.length);
  let cursor = 0;
  const workers = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      try {
        results[index] = { source: items[index], articles: await work(items[index]) };
      } catch (error) {
        results[index] = {
          source: items[index],
          articles: [],
          error: error && error.message ? error.message : "The source could not be reached."
        };
      }
    }
  });
  await Promise.all(workers);
  return results;
}

function articleBlock(article, index, includeSummary) {
  const lines = ["*" + index + ". " + article.title + "*"];
  if (article.date) lines.push("🕒 _" + article.date + "_");
  if (includeSummary && article.summary && article.summary.toLowerCase() !== article.title.toLowerCase()) {
    lines.push(article.summary);
  }
  if (article.link) lines.push("🔗 " + article.link);
  return lines.join("\n");
}

function toMessageChunks(blocks) {
  const messages = [];
  let current = "📰 *LATEST NEWS*\n";
  for (const block of blocks) {
    const addition = "\n\n" + block;
    if (current.length + addition.length > MAX_MESSAGE_CHARS && current.trim()) {
      messages.push(current.trim());
      current = block;
    } else {
      current += addition;
    }
  }
  if (current.trim()) messages.push(current.trim());
  if (!messages.length) messages.push("No headlines were returned.");
  messages[messages.length - 1] += "\n\n" + POWERED_FOOTER;
  return messages;
}

const NEWS_COMMAND_NAMES = Object.freeze({
  aj: "aljazeera",
  cnn: "cnn",
  bbc: "bbc",
  gd: "guardian",
  npr: "npr",
  nyt: "nytimes",
  fox: "foxnews",
  sky: "skynews",
  dw: "dw",
  f24: "france24",
  wp: "washingtonpost",
  toi: "timesofindia",
  punch: "punchnews",
  abc: "abcnews"
});

async function runNews(ctx, forcedSourceCode = null) {
    const rawTokens = String(ctx.args || "").trim().toLowerCase().split(/\s+/).filter(Boolean);
    const tokens = forcedSourceCode ? [forcedSourceCode, ...rawTokens] : rawTokens;
    const selector = tokens[0];

    if (!selector || ["help", "menu", "list", "sources"].includes(selector)) {
      await ctx.reply(sourceMenu(ctx), false);
      return;
    }

    const allSources = selector === "all";
    const sourceCode = sourceLookup.get(selector);
    if (!allSources && !sourceCode) {
      await ctx.reply("❓ Unknown news source: *" + selector + "*\nUse " + ctx.config.prefix + "news to view source codes.", false);
      return;
    }

    if (tokens.length > 2) {
      await ctx.reply("Usage: " + ctx.config.prefix + "news <source|all> [count]", false);
      return;
    }

    const defaultCount = allSources ? 1 : 5;
    const maxCount = allSources ? 2 : 10;
    const count = tokens[1] === undefined ? defaultCount : Number(tokens[1]);
    if (!Number.isInteger(count) || count < 1 || count > maxCount || (tokens[1] && !/^\d+$/.test(tokens[1]))) {
      await ctx.reply(
        "Choose a story count from 1–" + maxCount + (allSources ? " for all sources." : " for one source.") +
        "\nExample: " + ctx.config.prefix + "news " + (allSources ? "all" : sourceCode) + " " + defaultCount,
        false
      );
      return;
    }

    await ctx.reply("📰 _Fetching the latest headlines. Please wait while the news sources respond._", false);

    if (!allSources) {
      const source = NEWS_SOURCES[sourceCode];
      try {
        const articles = await fetchNews(source, count);
        const blocks = [
          "*" + source.name.toUpperCase() + "* — " + articles.length + " headline" + (articles.length === 1 ? "" : "s")
        ];
        articles.forEach((article, index) => blocks.push(articleBlock(article, index + 1, true)));
        for (const message of toMessageChunks(blocks)) await ctx.reply(message, false);
      } catch {
        await ctx.reply("⚠️ Could not retrieve headlines from *" + source.name + "* right now. Please try again later.", false);
      }
      return;
    }

    const selected = Object.entries(NEWS_SOURCES);
    const results = await mapWithLimit(selected, 4, ([, source]) => fetchNews(source, count));
    const blocks = [];
    let total = 0;

    for (const result of results) {
      const [code, source] = result.source;
      if (!result.articles.length) {
        blocks.push("⚠️ *" + source.name + "* (" + code + "): unavailable right now.");
        continue;
      }
      total += result.articles.length;
      blocks.push("*" + source.name.toUpperCase() + "* — " + result.articles.length + " headline" +
        (result.articles.length === 1 ? "" : "s"));
      result.articles.forEach((article, index) => blocks.push(articleBlock(article, index + 1, false)));
    }

    if (!total) {
      await ctx.reply("⚠️ No headlines could be retrieved from the configured sources. Please try again later.", false);
      return;
    }

    blocks.unshift("_Retrieved " + total + " headline" + (total === 1 ? "" : "s") +
      " from " + results.filter(result => result.articles.length).length + " source(s)._");
    for (const message of toMessageChunks(blocks)) await ctx.reply(message, false);
}

export default [
  {
    name: "news",
    aliases: ["n"],
    category: "News",
    description: "Show headlines from any of the 14 news platforms.",
    run: ctx => runNews(ctx)
  },
  ...Object.entries(NEWS_SOURCES).map(([code, source]) => {
    const name = NEWS_COMMAND_NAMES[code];
    const aliases = [...new Set([code, ...source.aliases])]
      .filter(alias => alias !== name && alias !== "fox" && alias !== "punch");
    return {
      name,
      aliases,
      category: "News",
      description: "Fetch headlines from " + source.name + ".",
      run: ctx => runNews(ctx, code)
    };
  })
];
