import {
  requestApiJson,
  requestApiImage,
  extractImageUrls,
  unicodeBox,
  withPoweredFooter,
  validateHttpUrl
} from "../lib/api-client.js";
import { getContextInfo, getMentionedJids, normalizeJid } from "../lib/utils.js";
import { Buffer } from "node:buffer";

function firstArgUrl(ctx, label) {
  const value = String(ctx.args || "").trim().split(/\s+/)[0];
  if (!value) throw new Error("Usage: " + ctx.config.prefix + ctx.command + " " + label + "-URL");
  return validateHttpUrl(value, label);
}

function normalizeImage(value) {
  if (Buffer.isBuffer(value)) return value;
  if (typeof value !== "string") throw new Error("The image service returned an invalid image.");
  if (/^data:image\/(?:png|jpe?g|webp);base64,/i.test(value)) {
    return Buffer.from(value.slice(value.indexOf(",") + 1), "base64");
  }
  const parsed = new URL(value);
  if (parsed.protocol !== "https:") throw new Error("The image service returned an unsupported image URL.");
  return { url: parsed.toString() };
}

async function sendImage(ctx, value, caption) {
  const image = normalizeImage(value);
  await ctx.send({
    image,
    caption: withPoweredFooter(caption, 900)
  }, false);
}

function getTargetForPp(ctx) {
  const info = getContextInfo(ctx.msg.message);
  const mentioned = getMentionedJids(ctx.msg);
  if (mentioned.length) return mentioned[0];

  const quotedParticipant = normalizeJid((info && info.participant) || "");
  if (quotedParticipant) return quotedParticipant;

  if (info && info.quotedMessage && !ctx.jid.endsWith("@g.us")) {
    return normalizeJid(ctx.jid);
  }
  return normalizeJid(ctx.senderJid || "");
}

export default [
  {
    name: "ssweb",
    category: "Media & Tools",
    description: "Take a screenshot of a public website.",
    run: async ctx => {
      const parts = String(ctx.args || "").trim().split(/\s+/).filter(Boolean);
      if (!parts.length) throw new Error("Usage: " + ctx.config.prefix + "ssweb https://google.com [full|mobile|desktop]");
      const url = validateHttpUrl(parts[0], "website");
      const device = String(parts[1] || "full").toLowerCase();
      if (!["full", "mobile", "desktop"].includes(device)) throw new Error("Device must be full, mobile, or desktop.");
      await ctx.reply(unicodeBox("🌐 ᴡᴇʙsɪᴛᴇ sᴄʀᴇᴇɴsʜᴏᴛ",
        "Website URL: " + url + "\nDevice profile: " + device + "\n\nSubmitting the capture request to the screenshot service. Please wait while the image is generated.", { footer: false }));
      const image = await requestApiImage("ssweb", { url, device });
      await sendImage(ctx, image, "🌐 *WEBSITE SCREENSHOT*\n🔗 _URL:_ `" + url + "`\n📱 _Device:_ *" + device.toUpperCase() + "*");
    }
  },
  {
    name: "removebg",
    category: "Media & Tools",
    description: "Remove the background from an image URL.",
    run: async ctx => {
      const url = firstArgUrl(ctx, "image");
      await ctx.reply(unicodeBox("✂️ ʙᴀᴄᴋɢʀᴏᴜɴᴅ ʀᴇᴍᴏᴠᴀʟ",
        "Submitting the image to the background-removal service. Please wait while processing completes.", { footer: false }));
      const image = await requestApiImage("removebg", { url });
      await sendImage(ctx, image, "✅ *BACKGROUND REMOVED*");
    }
  },
  {
    name: "bible",
    category: "Media & Tools",
    description: "Look up a Bible verse or passage by reference.",
    run: async ctx => {
      const reference = String(ctx.args || "").trim();
      if (!reference) throw new Error("Usage: " + ctx.config.prefix + "bible John 3:16");
      if (reference.length > 180) throw new Error("Keep the Bible reference under 180 characters.");

      await ctx.reply(unicodeBox("📖 ʙɪʙʟᴇ sᴇᴀʀᴄʜ",
        "Reference: *" + reference + "*\n\nSubmitting the passage lookup request to the Bible text service...", { footer: false }));
      const payload = await requestExternalJson("https://eliteprotech-apis.zone.id/search/bible", { q: reference });
      const text = String(payload && payload.text || "").trim();
      if (!text) throw new Error("No Bible passage was returned for that reference.");
      const header = [
        "*" + String(payload.title || "THE HOLY BIBLE") + "*",
        "📍 _Reference:_ *" + String(payload.reference || reference) + "*",
        payload.version ? "📚 _Version:_ `" + String(payload.version) + "`" : ""
      ].filter(Boolean).join("\n");
      await ctx.reply(unicodeBox("📖 ʙɪʙʟᴇ sᴇᴀʀᴄʜ", header + "\n\n*PASSAGE*\n" + text, { footer: true }), false);
    }
  },
  {
    name: "quote",
    category: "Fun",
    description: "Get a random motivational quote.",
    run: async ctx => {
      await ctx.reply(unicodeBox("💬 ʀᴀɴᴅᴏᴍ ǫᴜᴏᴛᴇ",
        "Requesting a random quote from the content API...", { footer: false }));
      const payload = await requestApiJson("randomquotes");
      const quote = String(payload && payload.quotes || "").trim();
      if (!quote) throw new Error("No quote was returned. Please try again.");
      const author = String(payload.by || "").trim();
      await ctx.reply(unicodeBox("💬 ʀᴀɴᴅᴏᴍ ǫᴜᴏᴛᴇ", "_" + quote + "_" + (author ? "\n\n*— " + author + "*" : "")), false);
    }
  },
  {
    name: "fact",
    category: "Fun",
    description: "Get a random fact.",
    run: async ctx => {
      await ctx.reply(unicodeBox("🧠 ʀᴀɴᴅᴏᴍ ғᴀᴄᴛ",
        "Requesting a random fact from the content API...", { footer: false }));
      const payload = await requestApiJson("facts");
      const fact = String(payload && payload.fact || "").trim();
      if (!fact) throw new Error("No fact was returned. Please try again.");
      await ctx.reply(unicodeBox("🧠 ʀᴀɴᴅᴏᴍ ғᴀᴄᴛ", "*DID YOU KNOW?*\n\n_" + fact + "_"), false);
    }
  },
  {
    name: "waifu",
    category: "Media & Tools",
    description: "Get a random waifu image.",
    run: async ctx => {
      await ctx.reply(unicodeBox("🌸 ᴡᴀɪғᴜ",
        "Requesting an image from the image service...", { footer: false }));
      const image = await requestApiImage("waifu");
      await sendImage(ctx, image, "🌸 Random waifu image");
    }
  },
  {
    name: "couplepp",
    category: "Media & Tools",
    description: "Get matching male and female couple profile pictures.",
    run: async ctx => {
      await ctx.reply(unicodeBox("💞 ᴄᴏᴜᴘʟᴇ ᴘʀᴏғɪʟᴇ ᴘɪᴄs",
        "Requesting a matching profile-picture pair from the API...", { footer: false }));
      const payload = await requestApiJson("couplepp");
      const data = payload && payload.data;
      const male = data && data.male;
      const female = data && data.female;
      const urls = extractImageUrls({ male, female });
      if (typeof male !== "string" || typeof female !== "string" || urls.length < 2) {
        throw new Error("The service did not return both profile pictures.");
      }
      await sendImage(ctx, male, "♂️ *MATCHING COUPLE PROFILE PICTURE*\n_Male version_");
      await sendImage(ctx, female, "♀️ *MATCHING COUPLE PROFILE PICTURE*\n_Female version_");
    }
  },
  {
    name: "pp",
    category: "Media & Tools",
    description: "Show your profile picture or the picture of a replied-to user.",
    run: async ctx => {
      const target = getTargetForPp(ctx);
      if (!target) throw new Error("Reply to a user's message or mention that user.");
      let imageUrl;
      try {
        imageUrl = await ctx.sock.profilePictureUrl(target, "image");
      } catch {
        throw new Error("That user has no profile picture available to this account.");
      }
      if (!imageUrl || !/^https:\/\//i.test(imageUrl)) {
        throw new Error("That user's profile picture is unavailable.");
      }
      await ctx.send({
        image: { url: imageUrl },
        caption: withPoweredFooter("👤 *PROFILE PICTURE*\n_Account:_ @" + target.split("@")[0].split(":")[0], 900)
      }, false);
    }
  }
];
