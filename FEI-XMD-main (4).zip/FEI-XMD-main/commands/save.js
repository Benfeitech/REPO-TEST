import { downloadMediaMessage } from "@whiskeysockets/baileys";
import {
  getContextInfo, getQuotedKey, getQuotedMessage, getSelfJids, unwrapMessage
} from "../lib/utils.js";
import { hasViewOnceWrapperDeep } from "../lib/view-once-shortcuts.js";

const SAVE_ALIASES = ["💯", "🙂"];

function quotedParts(ctx) {
  const info = getContextInfo(ctx.msg.message);
  const message = (info && info.quotedMessage) || getQuotedMessage(ctx.msg);
  if (!info || !info.stanzaId || !message) return null;
  const key = getQuotedKey(ctx.msg, ctx.sock) || {
    remoteJid: ctx.jid,
    id: info.stanzaId,
    fromMe: false
  };
  if (info.participant) key.participant = info.participant;
  return {
    info,
    message,
    key,
    wrapped: { key, message, messageTimestamp: ctx.msg.messageTimestamp }
  };
}

function mediaKind(message) {
  const body = unwrapMessage(message);
  if (body.imageMessage) return "image";
  if (body.videoMessage) return "video";
  if (body.audioMessage) return "audio";
  if (body.stickerMessage) return "sticker";
  if (body.documentMessage) return "document";
  return "";
}

function connectedAccountJid(ctx) {
  const selfJids = getSelfJids(ctx.sock);
  return selfJids.find(jid => jid.endsWith("@s.whatsapp.net")) || selfJids[0] || "";
}

function quotedText(body) {
  return String(
    body.conversation ||
    (body.extendedTextMessage && body.extendedTextMessage.text) ||
    (body.imageMessage && body.imageMessage.caption) ||
    (body.videoMessage && body.videoMessage.caption) ||
    (body.documentMessage && body.documentMessage.caption) ||
    ""
  ).trim();
}

export function createSaveCommand(options = {}) {
  const download = options.downloadQuotedMedia || (async (ctx, quoted) =>
    downloadMediaMessage(quoted.wrapped, "buffer", {}, {
      reuploadRequest: ctx.sock.updateMediaMessage
    })
  );

  return {
    name: "save",
    aliases: SAVE_ALIASES,
    hiddenAliases: SAVE_ALIASES,
    category: "Media & Tools",
    description: "Save a replied-to status or supported media to the connected WhatsApp account's own DM.",
    noReaction: true,
    run: async ctx => {
      const quoted = quotedParts(ctx);
      if (!quoted) {
        await ctx.reply("❌ Reply to a status or media with " + ctx.config.prefix + "save.");
        return;
      }

      if (hasViewOnceWrapperDeep(quoted.message)) {
        await ctx.reply("🔒 View-once media cannot be saved with this command.");
        return;
      }

      const destination = connectedAccountJid(ctx);
      if (!destination) {
        await ctx.reply("❌ Could not determine the connected WhatsApp account's own DM.");
        return;
      }

      const body = unwrapMessage(quoted.message);
      const kind = mediaKind(quoted.message);
      if (kind) {
        const media = body[kind + "Message"] || {};
        const buffer = await download(ctx, quoted);
        if (!buffer || !buffer.length) throw new Error("The quoted media could not be downloaded.");

        let content;
        if (kind === "image" || kind === "video") {
          content = { [kind]: buffer };
          if (media.caption) content.caption = String(media.caption);
        } else if (kind === "audio") {
          content = {
            audio: buffer,
            mimetype: media.mimetype || (media.ptt ? "audio/ogg; codecs=opus" : "audio/mpeg"),
            ptt: Boolean(media.ptt)
          };
        } else if (kind === "sticker") {
          content = { sticker: buffer };
        } else {
          content = {
            document: buffer,
            mimetype: media.mimetype || "application/octet-stream",
            fileName: media.fileName || "saved-status"
          };
          if (media.caption) content.caption = String(media.caption);
        }

        await ctx.sock.sendMessage(destination, content);
      } else {
        const text = quotedText(body);
        if (!text) {
          await ctx.reply("❌ Reply to a text status, image, video, audio, sticker or document.");
          return;
        }
        await ctx.sock.sendMessage(destination, { text });
      }

    }
  };
}

export default createSaveCommand();
