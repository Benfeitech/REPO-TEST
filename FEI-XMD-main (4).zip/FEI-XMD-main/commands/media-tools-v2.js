import {
  extractImageUrls,
  requestExternalJson,
  unicodeBox,
  withPoweredFooter
} from "../lib/api-client.js";

const OMEGATECH = "https://api.omegatech.app/api";

function safeHttpsUrl(value, allowedSuffixes, label) {
  let url;
  try {
    url = new URL(String(value || "").trim());
  } catch {
    throw new Error("The " + label + " service returned an invalid URL.");
  }
  const host = url.hostname.toLowerCase();
  if (url.protocol !== "https:" || url.username || url.password ||
      !allowedSuffixes.some(suffix => host === suffix || host.endsWith("." + suffix))) {
    throw new Error("The " + label + " service returned an unsupported URL.");
  }
  return url.toString();
}

function requireInput(ctx, example) {
  const input = String(ctx.args || "").trim();
  if (!input) throw new Error("Usage: " + ctx.config.prefix + ctx.command + " " + example);
  if (input.length > 1800) throw new Error("Keep the input under 1800 characters.");
  return input;
}

async function sendTextResult(ctx, title, body) {
  await ctx.send({
    text: withPoweredFooter(unicodeBox(title, body, { footer: false }), 3500)
  }, false, true);
}

function imageValue(payload) {
  const direct = [
    payload && payload.data && payload.data.imageUrl,
    payload && payload.imageUrl,
    payload && payload.data && payload.data.url,
    payload && payload.url,
    payload && payload.result && payload.result.imageUrl,
    payload && payload.result && payload.result.url,
    typeof (payload && payload.result) === "string" ? payload.result : ""
  ].find(value => typeof value === "string" && value.trim());
  return direct || extractImageUrls(payload)[0] || "";
}

async function sendGeneratedImage(ctx, imageValueFromApi, title, prompt) {
  const imageUrl = safeHttpsUrl(imageValueFromApi, ["pollinations.ai"], "image-generation");
  await ctx.send({
    image: { url: imageUrl },
    caption: withPoweredFooter(
      unicodeBox(title, "📝 Prompt: " + prompt.slice(0, 650), { footer: false }),
      900
    )
  }, false, true);
}

function makeImageCommand({ name, title, endpoint, params, requestJson = requestExternalJson }) {
  return {
    name,
    category: "AI & Chat",
    description: "Generate an image from a text prompt.",
    run: async ctx => {
      const prompt = requireInput(ctx, "describe the image you want");
      const payload = await requestJson(endpoint, params(prompt));
      const imageUrl = imageValue(payload);
      if (!imageUrl) throw new Error("The image-generation service did not return an image URL.");
      await sendGeneratedImage(ctx, imageUrl, title, prompt);
    }
  };
}

function profileStats(profile, stats) {
  const following = stats.followingCount ?? (stats.following_count || 0);
  const followers = stats.followerCount ?? (stats.follower_count || 0);
  const likes = stats.heartCount ?? stats.heart ?? stats.heart_count ?? 0;
  const videos = stats.videoCount ?? stats.video_count ?? 0;
  return [
    "👤 Username: @" + (profile.uniqueId || profile.username || "unknown"),
    "📛 Display name: " + (profile.nickname || profile.name || "Not provided"),
    "✅ Verified: " + (profile.verified ? "Yes" : "No"),
    "🔒 Private account: " + (profile.privateAccount ? "Yes" : "No"),
    "👥 Followers: " + followers,
    "➡️ Following: " + following,
    "❤️ Likes: " + likes,
    "🎬 Videos: " + videos
  ].join("\n");
}

function validTikTokAvatar(value) {
  try {
    return safeHttpsUrl(value, [
      "tiktokcdn-us.com",
      "tiktokcdn.com",
      "tiktokcdn-eu.com",
      "tiktokcdn.com",
      "ibytedtos.com",
      "byteoversea.com"
    ], "TikTok avatar");
  } catch {
    return "";
  }
}

export function createMediaToolsV2Commands({ requestJson = requestExternalJson } = {}) {
  const commands = [
  makeImageCommand({
    name: "flux",
    title: "🎨 FLUX IMAGE GENERATION",
    endpoint: OMEGATECH + "/ai/pollination2",
    params: prompt => ({ action: "generate", prompt, model: "flux", format: "jpg", safe: "true" }),
    requestJson
  }),
  makeImageCommand({
    name: "pollination",
    title: "🎨 POLLINATION AI",
    endpoint: OMEGATECH + "/ai/polination",
    params: prompt => ({ action: "generate", prompt, shape: "square" }),
    requestJson
  }),
  {
    name: "tiktokstalk",
    category: "Media & Tools",
    description: "Look up a TikTok public profile, follower statistics, and avatar.",
    run: async ctx => {
      const username = requireInput(ctx, "TikTok username").replace(/^@/, "").split(/\s+/)[0];
      if (!/^[a-zA-Z0-9._]{1,30}$/.test(username)) {
        throw new Error("Enter a valid TikTok username without spaces.");
      }
      const payload = await requestJson("https://zellapi.autos/stalk/tiktok", { username });
      const profile = payload && payload.user || payload && payload.data && payload.data.user || {};
      const stats = payload && payload.stats || payload && payload.data && payload.data.stats || {};
      if (!profile.uniqueId && !profile.username && !profile.id) {
        throw new Error(String(payload && (payload.message || payload.error) || "The TikTok profile was not found."));
      }

      const body = profileStats(profile, stats);
      const avatar = validTikTokAvatar(profile.avatarLarger || profile.avatarMedium || profile.avatarThumb);
      if (avatar) {
        await ctx.send({
          image: { url: avatar },
          caption: withPoweredFooter(unicodeBox("🎵 TIKTOK PROFILE", body, { footer: false }), 900)
        }, false, true);
      } else {
        await sendTextResult(ctx, "🎵 TIKTOK PROFILE", body);
      }
    }
  },
  {
    name: "lyrics",
    category: "Media & Tools",
    description: "Find a song's artist and official lyrics page.",
    run: async ctx => {
      const query = requireInput(ctx, "song title or artist");
      const payload = await requestJson(OMEGATECH + "/tools/lyrics", { query });
      if (payload && payload.found === false) throw new Error("No matching song was found. Try the title and artist.");
      const title = String(payload && payload.title || query).slice(0, 180);
      const artist = String(payload && payload.artist || "Unknown artist").slice(0, 180);
      const source = String(payload && payload.url || "");
      const excerpt = String(payload && payload.lyrics || "").replace(/\s+/g, " ").trim().slice(0, 90);
      const safeSource = (() => {
        try { return safeHttpsUrl(source, ["azlyrics.com", "genius.com", "musixmatch.com"], "lyrics source"); }
        catch { return ""; }
      })();
      const lines = [
        "🎵 Title: " + title,
        "🎤 Artist: " + artist,
        excerpt ? "Excerpt: “" + excerpt + (String(payload.lyrics || "").length > 90 ? "…" : "") + "”" : "",
        safeSource ? "Lyrics page: " + safeSource : ""
      ].filter(Boolean);
      await sendTextResult(ctx, "🎼 LYRICS SEARCH", lines.join("\n"));
    }
  }
  ];

  return commands;
}

export default createMediaToolsV2Commands();
