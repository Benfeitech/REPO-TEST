export default [
  {
    name: "ownerinfo",
    aliases: ["botinfo"],
    category: "Owner",
    ownerOnly: true,
    description: "Show owner-only bot information.",
    run: async ctx => {
      await ctx.reply(
        "👑 " + ctx.config.name + " OWNER INFO\n" +
        "Owner: " + ctx.config.ownerName + "\n" +
        "Version: " + ctx.config.version + "\n" +
        "Mode: " + ctx.mode.toUpperCase() + "\n" +
        "Prefix: " + ctx.config.prefix
      );
    }
  },
  {
    name: "settings",
    category: "Bot Settings",
    ownerOnly: true,
    description: "Show bot settings.",
    run: async ctx => {
      await ctx.reply("⚙️ " + ctx.config.name + " Settings\n" +
        "• Prefix: " + ctx.config.prefix + "\n" +
        "• Mode: " + ctx.mode.toUpperCase() + "\n" +
        "• Version: " + ctx.config.version + "\n" +
        "• Channel attribution: " + (ctx.config.channel.jid ? "Random (~20% of command interactions)" : "Disabled") + "\n" +
        "• Pairing method: " + ctx.config.pairingMethod);
    }
  },
  {
    name: "setprefix",
    category: "Bot Settings",
    ownerOnly: true,
    description: "Choose the symbol used to start bot commands.",
    run: async ctx => {
      const prefix = String(ctx.args || "").trim();
      if (!prefix) {
        await ctx.reply("Usage: " + ctx.config.prefix + "setprefix !\nChoose 1–3 symbols, with no spaces.");
        return;
      }
      await ctx.setPrefix(prefix);
      await ctx.reply("✅ Prefix saved as " + prefix + "\nUse " + prefix + "menu to open the menu.");
    }
  },
  {
    name: "privacy",
    category: "Bot Settings",
    ownerOnly: true,
    description: "Explain current privacy mode.",
    run: async ctx => {
      await ctx.reply("🔐 Current mode: " + ctx.mode.toUpperCase() + "\n" +
        (ctx.mode === "private"
          ? "Only the owner can run commands. Other users' commands are ignored."
          : "Commands are available to users. Owner-only commands remain protected.") +
        "\nChange it with " + ctx.config.prefix + "mode private or " + ctx.config.prefix + "mode public.");
    }
  },
  {
    name: "mode",
    category: "Bot Settings",
    ownerOnly: true,
    description: "Switch between public and private mode.",
    run: async ctx => {
      const mode = String(ctx.args || "").trim().toLowerCase();
      if (!mode) {
        await ctx.reply("🔐 Current mode: " + ctx.mode.toUpperCase() +
          "\nUsage: " + ctx.config.prefix + "mode public OR " + ctx.config.prefix + "mode private");
        return;
      }
      if (mode !== "public" && mode !== "private") {
        await ctx.reply("Choose either public or private.");
        return;
      }
      await ctx.setMode(mode);
      await ctx.reply("✅ " + ctx.config.name + " mode changed to " + mode.toUpperCase() + ".");
    }
  },
  {
    name: "public",
    category: "Bot Settings",
    ownerOnly: true,
    description: "Enable public mode.",
    run: async ctx => {
      await ctx.setMode("public");
      await ctx.reply("🌐 Public mode enabled. Commands are available to users; owner commands remain protected.");
    }
  },
  {
    name: "private",
    category: "Bot Settings",
    ownerOnly: true,
    description: "Enable private mode.",
    run: async ctx => {
      await ctx.setMode("private");
      await ctx.reply("🔒 Private mode enabled. Only the owner can run commands.");
    }
  },
  {
    name: "restart",
    category: "Bot Settings",
    ownerOnly: true,
    description: "Explain how to restart the process safely.",
    run: async ctx => {
      await ctx.reply("♻️ Restart FEI XMD from your terminal or process manager so the WhatsApp session can close cleanly.");
    }
  }
];
