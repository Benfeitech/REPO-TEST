import { calculateExpression, extractText, getQuotedKey, getQuotedMessage } from "../lib/utils.js";

const eightBallAnswers = [
  "Yes, definitely. ✅",
  "It looks promising. ✨",
  "Ask again later. 🔄",
  "Hard to tell right now. 🤔",
  "Probably not. 🌧️",
  "The signs point to yes. 🌟"
];

export default [
  {
    name: "echo",
    aliases: ["say"],
    category: "Fun",
    description: "Repeat text.",
    run: async ctx => {
      if (!ctx.args) {
        await ctx.reply("Usage: " + ctx.config.prefix + ctx.command + " text to repeat");
        return;
      }
      await ctx.reply(ctx.args.slice(0, 3000));
    }
  },
  {
    name: "calc",
    category: "Fun",
    description: "Safely calculate a math expression.",
    run: async ctx => {
      try { await ctx.reply("🧮 " + ctx.args + " = " + calculateExpression(ctx.args)); }
      catch (error) { await ctx.reply("❌ " + error.message); }
    }
  },
  {
    name: "quoted",
    category: "Fun",
    description: "Repeat the text of a replied-to message.",
    run: async ctx => {
      const quoted = getQuotedMessage(ctx.msg);
      if (!quoted) {
        await ctx.reply("Reply to a message with " + ctx.config.prefix + "quote.");
        return;
      }
      await ctx.reply("🗨️ Quoted message:\n" +
        (extractText(quoted) || "(The quoted message has no readable text or caption.)").slice(0, 2500));
    }
  },
  {
    name: "react",
    category: "Fun",
    description: "React to a replied-to message.",
    run: async ctx => {
      const key = getQuotedKey(ctx.msg, ctx.sock);
      const emoji = String(ctx.args || "").trim();
      if (!key) {
        await ctx.reply("Reply to a message and use " + ctx.config.prefix + "react ❤️");
        return;
      }
      if (!emoji || emoji.length > 8 || /[\r\n]/.test(emoji)) {
        await ctx.reply("Usage: reply to a message with " + ctx.config.prefix + "react ❤️");
        return;
      }
      await ctx.sock.sendMessage(ctx.jid, { react: { text: emoji, key } });
      await ctx.reply("✅ Reaction added.");
    }
  },
  {
    name: "poll",
    category: "Fun",
    description: "Create a WhatsApp poll.",
    run: async ctx => {
      const parts = String(ctx.args || "").split("|").map(part => part.trim()).filter(Boolean);
      if (parts.length < 3) {
        await ctx.reply("Usage: " + ctx.config.prefix + "poll Question | Option 1 | Option 2");
        return;
      }
      const question = parts[0];
      const values = parts.slice(1);
      if (values.length > 12 || question.length > 250 || values.some(value => value.length > 100)) {
        await ctx.reply("A poll needs 2–12 options; keep the question under 250 characters and each option under 100.");
        return;
      }
      await ctx.send({ poll: { name: question, values, selectableCount: 1 } }, true);
    }
  },
  {
    name: "coinflip",
    aliases: ["flip"],
    category: "Fun",
    description: "Flip a virtual coin.",
    run: async ctx => { await ctx.reply("🪙 " + (Math.random() < 0.5 ? "Heads" : "Tails")); }
  },
  {
    name: "dice",
    aliases: ["roll"],
    category: "Fun",
    description: "Roll a six-sided die.",
    run: async ctx => { await ctx.reply("🎲 You rolled: " + (Math.floor(Math.random() * 6) + 1)); }
  },
  {
    name: "8ball",
    category: "Fun",
    description: "Give a playful random answer.",
    run: async ctx => {
      if (!ctx.args) {
        await ctx.reply("Ask a question. Example: " + ctx.config.prefix + "8ball Will today be a good day?");
        return;
      }
      await ctx.reply("🎱 " + eightBallAnswers[Math.floor(Math.random() * eightBallAnswers.length)]);
    }
  },
  {
    name: "choose",
    category: "Fun",
    description: "Choose between options separated by |.",
    run: async ctx => {
      const options = String(ctx.args || "").split("|").map(value => value.trim()).filter(Boolean);
      if (options.length < 2) {
        await ctx.reply("Usage: " + ctx.config.prefix + "choose tea | coffee");
        return;
      }
      await ctx.reply("🎯 My choice: " + options[Math.floor(Math.random() * options.length)]);
    }
  }
];
