const items = [
  ["toimg", "Media & Tools"],
  ["qr", "Media & Tools"],
  ["shorturl", "Media & Tools"],
  ["weather", "Media & Tools"]
];

export default items.map(([name, category]) => ({
  name,
  category,
  description: "Reserved for a future API integration.",
  run: async ctx => {
    await ctx.reply("🧩 ." + ctx.command + " is reserved for a future integration.\n" +
      "The command is registered, but its API is not connected yet. Add the implementation when ready.");
  }
}));
