import { requestXrinaImage } from "../lib/xrina-api.js";
import { unicodeBox, withPoweredFooter } from "../lib/api-client.js";

function cleanField(value, label, maxLength = 350) {
  const text = String(value || "").trim();
  if (!text) throw new Error("Please provide " + label + ".");
  if (text.length > maxLength) throw new Error(label + " must be " + maxLength + " characters or fewer.");
  return text;
}

function pipeFields(ctx, count, usage) {
  const raw = String(ctx.args || "").trim();
  if (!raw) throw new Error("Usage: " + ctx.config.prefix + ctx.command + " " + usage);
  const fields = raw.split("|").map(value => value.trim());
  if (fields.length !== count || fields.some(value => !value)) {
    throw new Error("Usage: " + ctx.config.prefix + ctx.command + " " + usage);
  }
  return fields;
}

async function generateCanvas(ctx, title, route, params, description) {
  await ctx.reply(unicodeBox(title,
    "🎨 Creating your canvas image...\n" + description + "\n\nPlease wait while the image is generated.",
    { footer: false }), false);

  const image = await requestXrinaImage("canvas/" + route, params);
  await ctx.send({
    image,
    caption: withPoweredFooter(unicodeBox(title, description, { footer: false }), 1000)
  }, false);
}

function canvasCommand(name, description, title, route, readParams) {
  return {
    name,
    category: "Canvas",
    description,
    run: async ctx => {
      const params = readParams(ctx);
      await generateCanvas(ctx, title, route, params.values, params.description);
    }
  };
}

export const CANVAS_COMMANDS = Object.freeze([
  "fakettc", "wndwqute", "canvasquote", "nokiamsg", "meme2",
  "fakeff", "fakeffduo", "iqc", "ffgirl"
]);

export default [
  canvasCommand("fakettc", "Generate a fake text-message conversation canvas.", "💬 FAKE TEXT CHAT",
    "ttqc", ctx => {
      const [name, text] = pipeFields(ctx, 2, "name | message");
      return {
        values: { name: cleanField(name, "a name", 80), text: cleanField(text, "the message") },
        description: "Name: " + name + "\nMessage: " + text
      };
    }),

  canvasCommand("wndwqute", "Create a Windows-style quote canvas.", "🪟 WINDOWS QUOTE",
    "windows", ctx => {
      const text = cleanField(ctx.args, "the quote");
      return { values: { text }, description: text };
    }),

  canvasCommand("canvasquote", "Create a quote canvas with an author name.", "✨ CANVAS QUOTE",
    "quotes", ctx => {
      const [text, name] = pipeFields(ctx, 2, "quote text | author name");
      return {
        values: { text: cleanField(text, "the quote"), name: cleanField(name, "the author name", 100) },
        description: "“" + text + "”\n— " + name
      };
    }),

  canvasCommand("nokiamsg", "Create a Nokia-style message canvas.", "📱 NOKIA MESSAGE",
    "nokia", ctx => {
      const [message, sender, date] = pipeFields(ctx, 3, "message | sender | date");
      return {
        values: {
          message: cleanField(message, "the message"),
          sender: cleanField(sender, "the sender name", 80),
          date: cleanField(date, "the date", 40)
        },
        description: "Sender: " + sender + "\nDate: " + date + "\nMessage: " + message
      };
    }),

  canvasCommand("meme2", "Generate the canvas police meme with a username and text.", "🚨 POLICE MEME",
    "meme-polisi", ctx => {
      const [username, text] = pipeFields(ctx, 2, "username | text");
      return {
        values: { username: cleanField(username, "a username", 80), text: cleanField(text, "the meme text") },
        description: "Username: " + username + "\nText: " + text
      };
    }),

  canvasCommand("fakeff", "Create a fake Free Fire lobby canvas.", "🎮 FAKE FREE FIRE LOBBY",
    "fakeff", ctx => {
      const [name, lobby] = pipeFields(ctx, 2, "name | lobby number");
      return {
        values: { name: cleanField(name, "a player name", 80), lobby: cleanField(lobby, "a lobby number", 30) },
        description: "Player: " + name + "\nLobby: " + lobby
      };
    }),

  canvasCommand("fakeffduo", "Create a two-player fake Free Fire canvas.", "🎮 FREE FIRE DUO",
    "fakeffduo", ctx => {
      const [name1, name2] = pipeFields(ctx, 2, "first player | second player");
      return {
        values: {
          name1: cleanField(name1, "the first player name", 80),
          name2: cleanField(name2, "the second player name", 80)
        },
        description: name1 + "  ×  " + name2
      };
    }),

  canvasCommand("iqc", "Create an iPhone-style quote/message canvas.", "📲 IPHONE QUOTE",
    "iqc", ctx => {
      const [text, time] = pipeFields(ctx, 2, "text | time (e.g. 13:34)");
      return {
        values: { text: cleanField(text, "the text"), time: cleanField(time, "the time", 20) },
        description: "Time: " + time + "\n" + text
      };
    }),

  canvasCommand("ffgirl", "Generate a Free Fire girl profile canvas.", "🎮 FREE FIRE GIRL",
    "ffgirl", ctx => {
      const username = cleanField(ctx.args, "a username", 80);
      return { values: { username }, description: "Username: " + username };
    })
];
