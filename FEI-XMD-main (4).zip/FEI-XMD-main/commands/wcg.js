import { wordChainGame, wordChainRules } from "../lib/wcg-game.js";

async function sendOtherGameMessages(ctx, messages = []) {
  for (const item of messages) {
    if (!item || !item.chat || item.chat === ctx.jid) continue;
    try {
      await ctx.sock.sendMessage(item.chat, {
        text: String(item.text || ""),
        mentions: Array.isArray(item.mentions) ? item.mentions : []
      });
    } catch (error) {
      console.warn("Could not notify a Word Chain participant:", error && error.message);
    }
  }
}

async function runWordChain(ctx) {
  const action = String(ctx.args || "").trim().toLowerCase();

  if (["help", "rules"].includes(action)) {
    await ctx.reply(wordChainRules(ctx.config.prefix), false);
    return;
  }

  if (["end", "stop", "cancel"].includes(action)) {
    const stopped = wordChainGame.stop(ctx.jid, ctx.senderJid, ctx.owner);
    if (stopped.ok) await sendOtherGameMessages(ctx, stopped.messages);
    await ctx.reply(stopped.text, true);
    return;
  }

  if (action) {
    await ctx.reply("Usage: " + ctx.config.prefix + ctx.command + " [rules|end]", false);
    return;
  }

  const started = wordChainGame.start(ctx.jid, ctx.senderJid, ctx.msg && ctx.msg.pushName);
  await ctx.reply(started.text, true, { mentions: started.mentions || [] });
}

export default [
  {
    name: "wcg",
    category: "Games",
    description: "Start a 60-second multiplayer Word Chain lobby. FEI XMD judges; humans play.",
    run: runWordChain
  },
  {
    name: "wrg",
    category: "Games",
    description: "Alternate command for the multiplayer Word Chain game.",
    run: runWordChain
  }
];
