import {
  extractApiText,
  requestExternalJson,
  unicodeBox,
  withPoweredFooter
} from "../lib/api-client.js";

const MAX_PROMPT = 3500;
const OMEGATECH = "https://api.omegatech.app/api";

function valueAt(payload, paths) {
  for (const path of paths) {
    let value = payload;
    for (const key of path.split(".")) value = value && value[key];
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return "";
}

function requirePrompt(ctx, example = "your question") {
  const query = String(ctx.args || "").trim();
  if (!query) throw new Error("Usage: " + ctx.config.prefix + ctx.command + " " + example);
  if (query.length > MAX_PROMPT) throw new Error("Please keep your input under " + MAX_PROMPT + " characters.");
  return query;
}

async function sendTextResult(ctx, title, body) {
  await ctx.send({
    text: withPoweredFooter(unicodeBox(title, body, { footer: false }), 3600)
  }, false, true);
}

function createChatCommand({ name, title, endpoint, params, paths, description, usage, requestJson = requestExternalJson }) {
  return {
    name,
    category: "AI & Chat",
    description,
    run: async ctx => {
      const message = requirePrompt(ctx, usage || "your question");
      const payload = await requestJson(endpoint, params(message));
      const answer = valueAt(payload, paths) || extractApiText(payload);
      if (!answer) throw new Error("The AI service did not return a readable answer.");
      await sendTextResult(ctx, title, answer);
    }
  };
}

function validateAudioUrl(value) {
  let url;
  try {
    url = new URL(String(value || "").trim());
  } catch {
    throw new Error("The speech service returned an invalid audio URL.");
  }
  const host = url.hostname.toLowerCase();
  const allowedSuffixes = [
    "clideo.com",
    "catbox.moe",
    "replicate.delivery",
    "malvryx.dev",
    "googleapis.com"
  ];
  if (url.protocol !== "https:" || url.username || url.password ||
      !allowedSuffixes.some(suffix => host === suffix || host.endsWith("." + suffix))) {
    throw new Error("The speech service returned an unsupported audio URL.");
  }
  return url.toString();
}

async function sendAudioResult(ctx, audioValue, title, text) {
  const audioUrl = validateAudioUrl(audioValue);
  await ctx.send({
    audio: { url: audioUrl },
    mimetype: "audio/mpeg",
    ptt: false
  }, false, true);

  await ctx.send({
    text: withPoweredFooter(
      unicodeBox("🔊 " + title, String(text || "").slice(0, 1800), { footer: false }),
      2800
    )
  }, false, true);
}

function createTtsCommand({ name, title, endpoint, params, audioPaths, optionParser, description, requestJson = requestExternalJson }) {
  return {
    name,
    category: "AI & Chat",
    description,
    run: async ctx => {
      const parsed = optionParser
        ? optionParser(String(ctx.args || ""))
        : { text: String(ctx.args || "").trim(), options: [] };
      const text = String(parsed.text || "").trim();
      if (!text) throw new Error("Usage: " + ctx.config.prefix + name + " your text to speak");
      if (text.length > 1800) throw new Error("Please keep the text under 1800 characters.");
      const payload = await requestJson(endpoint, params(text, parsed.options || []));
      const audio = valueAt(payload, audioPaths);
      if (!audio) throw new Error("The speech service did not return an audio file.");
      await sendAudioResult(ctx, audio, title, "Text: " + text);
    }
  };
}

function splitTtsOptions(input, defaults) {
  const parts = String(input || "").split("|");
  return {
    text: String(parts[0] || "").trim(),
    options: defaults.map((fallback, index) => String(parts[index + 1] || fallback).trim())
  };
}

export function createAiV2Commands({ requestJson = requestExternalJson } = {}) {
  const aiCommands = [
    createChatCommand({
      name: "fable5",
      title: "🧠 CLAUDE FABLE 5",
      endpoint: OMEGATECH + "/ai/Secret",
      params: message => ({ action: "chat", message }),
      paths: ["data.reply", "reply", "data.response"],
      description: "Ask the Claude Fable 5 model a question.",
      requestJson
    }),
    createChatCommand({
      name: "qwen",
      title: "🧠 QWEN",
      endpoint: OMEGATECH + "/ai/Qwen-Claude-Haiku",
      params: message => ({ message, model: "qwen" }),
      paths: ["answer", "data.answer", "reply", "data.reply", "response"],
      description: "Ask the Qwen model a question.",
      requestJson
    }),
    createChatCommand({
      name: "deepseek2",
      title: "🧠 DEEPSEEK V3.2",
      endpoint: OMEGATECH + "/ai/Deepseek",
      params: message => ({ message, model: "v32" }),
      paths: ["answer", "data.answer", "reply", "data.reply"],
      description: "Ask the DeepSeek V3.2 model.",
      requestJson
    }),
    createChatCommand({
      name: "deepseek3",
      title: "🧠 DEEPSEEK V4",
      endpoint: OMEGATECH + "/ai/Deepseek2",
      params: message => ({ action: "chat", message, model: "v4" }),
      paths: ["reply", "data.reply", "answer", "data.answer"],
      description: "Ask the DeepSeek V4 model.",
      requestJson
    }),
    createChatCommand({
      name: "gemini2",
      title: "🧠 GEMINI 2",
      endpoint: OMEGATECH + "/ai/Gemini2",
      params: message => ({ action: "chat", message }),
      paths: ["data.response", "response", "data.reply"],
      description: "Ask the Gemini 2 model.",
      requestJson
    }),
    {
      name: "aidetect",
      category: "AI & Chat",
      description: "Estimate whether supplied text appears AI-generated.",
      run: async ctx => {
        const text = requirePrompt(ctx, "paste text to analyze");
        const payload = await requestJson(OMEGATECH + "/ai/zerochat", {
          action: "detect",
          text
        });
        const data = payload && payload.data || payload || {};
        const feedback = String(data.feedback || data.verdict || "Result unavailable");
        const fake = Number(data.fake_percentage);
        const human = Number(data.is_human);
        const lines = [
          "Verdict: " + feedback,
          "AI likelihood: " + (Number.isFinite(fake) ? fake + "%" : "not provided"),
          "Human likelihood: " + (Number.isFinite(human) ? human + "%" : "not provided"),
          "Words analyzed: " + (Number(data.text_words) || "not provided")
        ];
        if (data.additional_feedback) lines.push("Note: " + String(data.additional_feedback).slice(0, 400));
        await sendTextResult(ctx, "🔎 AI TEXT DETECTOR", lines.join("\n"));
      }
    },
    createTtsCommand({
      name: "tts",
      title: "TEXT TO SPEECH",
      endpoint: OMEGATECH + "/ai/clideo",
      params: (text, options) => ({ action: "generate", text, mood: options[0] || "NORMAL" }),
      audioPaths: ["data.previewUrl", "previewUrl"],
      optionParser: input => splitTtsOptions(input, ["NORMAL"]),
      description: "Convert text to speech. Optional mood: text | mood.",
      requestJson
    }),
    createTtsCommand({
      name: "tts2",
      title: "GEMINI TEXT TO SPEECH",
      endpoint: OMEGATECH + "/ai/Gemini-tts",
      params: text => ({ text }),
      audioPaths: ["result", "data.result", "audio"],
      description: "Generate speech audio using the Gemini TTS endpoint.",
      requestJson
    }),
    createTtsCommand({
      name: "tts3",
      title: "TEXT2SPEECH V3",
      endpoint: OMEGATECH + "/ai/text2speech-v3",
      params: (text, options) => ({ text, voice: options[0] || "woman1", language: options[1] || "English" }),
      audioPaths: ["audio", "data.audio", "result"],
      optionParser: input => splitTtsOptions(input, ["woman1", "English"]),
      description: "Generate speech with a selectable voice and language. Usage: text | voice | language.",
      requestJson
    }),
    createTtsCommand({
      name: "tts4",
      title: "TEXT TO SPEECH V2",
      endpoint: OMEGATECH + "/ai/text-to-speech2",
      params: (text, options) => ({ text, voice: options[0] || "NORMAL MALE" }),
      audioPaths: ["result", "data.result", "audio"],
      optionParser: input => splitTtsOptions(input, ["NORMAL MALE"]),
      description: "Generate speech with the alternate text-to-speech voice endpoint. Usage: text | voice.",
      requestJson
    }),
    createTtsCommand({
      name: "tts5",
      title: "MULTI TEXT TO SPEECH",
      endpoint: OMEGATECH + "/ai/Multi-Text-to-speech",
      params: text => ({ action: "tts", text }),
      audioPaths: ["data.audio_url", "audio_url", "result"],
      description: "Generate MP3 speech from text using the multi-TTS endpoint.",
      requestJson
    })
  ];

  return aiCommands;
}

export default createAiV2Commands();
