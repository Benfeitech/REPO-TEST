import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { POWERED_FOOTER } from "../lib/api-client.js";
import { withChannelAttribution } from "../lib/channel.js";
import {
  getContextInfo, getQuotedKey, getQuotedMessage, getSelfJids, getTargets,
  numberFromJid, participantJid, participantIsAdmin, unwrapMessage
} from "../lib/utils.js";
import { requireGroupAdmin, getGroupInfo } from "../lib/groups.js";
import {
  addWarning, getChatSettings, getEnabledChats, listWarnings, setChatSetting,
  getBotCommandBanAliases, isBotCommandBanned, setBotCommandBanned
} from "../lib/feature-state.js";
import { getCachedPoll } from "../lib/baileys-events.js";

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

async function canManage(ctx, label) {
  if (ctx.jid.endsWith("@g.us")) {
    const group = await requireGroupAdmin(ctx, { requireBotAdmin: false });
    return Boolean(group);
  }
  if (ctx.owner) return true;
  await ctx.reply("⛔ Only the bot owner can manage " + (label || "this feature") + " in a private chat.");
  return false;
}

async function ownerOnly(ctx, label) {
  if (ctx.owner) return true;
  await ctx.reply("⛔ Only the bot owner can use this command" + (label ? " for " + label : "") + ".");
  return false;
}

async function groupAdmin(ctx, requireBotAdmin = false) {
  if (!ctx.jid.endsWith("@g.us")) {
    await ctx.reply("Use this command inside a WhatsApp group.");
    return null;
  }
  return requireGroupAdmin(ctx, { requireBotAdmin });
}

function makeToggle(name, setting, category, options = {}) {
  return {
    name, category,
    aliases: options.aliases || [],
    description: options.description || "Toggle the " + name + " feature.",
    run: async ctx => {
      const target = options.global ? "global" : ctx.jid;
      if (options.ownerOnly) {
        if (!(await ownerOnly(ctx, name))) return;
      } else {
        if (options.groupOnly && !ctx.jid.endsWith("@g.us")) {
          await ctx.reply("Use " + ctx.config.prefix + name + " on/off inside a group.");
          return;
        }
        if (!(await canManage(ctx, name))) return;
      }
      const current = await getChatSettings(target);
      const value = String(ctx.args || "").trim().toLowerCase();
      if (value !== "on" && value !== "off") {
        await ctx.reply("⚙️ " + name + ": " + (current[setting] ? "ON" : "OFF") +
          "\nUsage: " + ctx.config.prefix + name + " on/off");
        return;
      }
      const enabled = value === "on";
      await setChatSetting(target, setting, enabled);
      if (options.onChange) await options.onChange(ctx, enabled);
      await ctx.reply((enabled ? "✅ Enabled " : "🔕 Disabled ") + name + ".");
    }
  };
}

function quotedParts(ctx) {
  const info = getContextInfo(ctx.msg.message);
  const message = (info && info.quotedMessage) || getQuotedMessage(ctx.msg);
  if (!info || !info.stanzaId || !message) return null;
  const key = getQuotedKey(ctx.msg, ctx.sock) || {
    remoteJid: ctx.jid,
    id: info.stanzaId,
    fromMe: Boolean(info.participant && getSelfJids(ctx.sock).includes(info.participant))
  };
  if (info.participant) key.participant = info.participant;
  return { info, message, key, wrapped: { key, message, messageTimestamp: ctx.msg.messageTimestamp } };
}

function isViewOnce(message) {
  return Object.keys(message || {}).some(key => /viewOnceMessage/i.test(key));
}

function mediaKind(message) {
  const body = unwrapMessage(message);
  if (body.imageMessage) return "image";
  if (body.videoMessage) return "video";
  if (body.audioMessage) return "audio";
  if (body.stickerMessage) return "sticker";
  if (body.documentMessage) return "document";
  return "";
}

async function downloadQuotedMedia(ctx, quoted) {
  return downloadMediaMessage(quoted.wrapped, "buffer", {}, {
    reuploadRequest: ctx.sock.updateMediaMessage
  });
}

function splitTextPreservingFormat(input, limit = 1024) {
  if (!input) return [];
  const chunks = [];
  let remaining = String(input);
  while (remaining.length > limit) {
    let splitAt = remaining.lastIndexOf("\n", limit);
    if (splitAt <= 0) splitAt = remaining.lastIndexOf(" ", limit);
    if (splitAt <= 0) splitAt = limit;
    chunks.push(remaining.slice(0, splitAt));
    remaining = remaining.slice(splitAt).replace(/^\s+/, "");
  }
  if (remaining.length) chunks.push(remaining);
  return chunks;
}

function groupStatusSourceType(content) {
  if (content.text) return "TEXT";
  if (content.image) return "IMAGE";
  if (content.video) return "VIDEO";
  if (content.audio) return "AUDIO";
  if (content.sticker) return "IMAGE";
  return "TEXT";
}

async function postGroupStatus(ctx, content) {
  const statusPayload = {
    ...content,
    contextInfo: {
      ...((content && content.contextInfo) || {}),
      isGroupStatus: true,
      statusSourceType: groupStatusSourceType(content),
      statusAttributions: [{ type: 10 }],
      statusAudienceMetadata: { audienceType: "CLOSE_FRIENDS" }
    }
  };
  return ctx.sock.sendMessage(ctx.jid, statusPayload);
}

const commands = [
  {
    name: "ban",
    category: "Owner",
    ownerOnly: true,
    description: "Block a mentioned, replied-to, or specified user from running bot commands until unbanned.",
    run: async ctx => {
      if (!ctx.owner) return;
      const targets = getTargets(ctx.msg, ctx.args).slice(0, 10);
      if (!targets.length) {
        await ctx.reply("Usage: " + ctx.config.prefix + "ban @user (mention, reply, or phone number).");
        return;
      }
      const ownerNumber = String(ctx.config.ownerNumber || "").replace(/\D/g, "");
      const selfJids = new Set(getSelfJids(ctx.sock));
      const changed = [];
      const skipped = [];
      for (const target of targets) {
        const number = numberFromJid(target);
        if (selfJids.has(target) || (ownerNumber && number === ownerNumber)) {
          skipped.push("@" + number + " (protected account)");
          continue;
        }
        const aliases = await getBotCommandBanAliases(ctx.sock, target);
        const alreadyBanned = (await Promise.all(aliases.map(isBotCommandBanned))).some(Boolean);
        for (const alias of aliases) await setBotCommandBanned(alias, true, ctx.senderJid);
        if (alreadyBanned) {
          skipped.push("@" + number + " (already banned)");
          continue;
        }
        changed.push(target);
      }
      const lines = ["🚫 *BOT COMMAND ACCESS UPDATE*"];
      if (changed.length) lines.push("Banned: " + changed.map(jid => "@" + numberFromJid(jid)).join(", "));
      if (skipped.length) lines.push("Skipped: " + skipped.join(", "));
      lines.push("Banned users cannot use bot commands until an owner unbans them.");
      await ctx.send({ text: lines.join("\n"), mentions: changed }, true, false);
    }
  },
  {
    name: "unban",
    category: "Owner",
    ownerOnly: true,
    description: "Restore a user's ability to run bot commands.",
    run: async ctx => {
      if (!ctx.owner) return;
      const targets = getTargets(ctx.msg, ctx.args).slice(0, 10);
      if (!targets.length) {
        await ctx.reply("Usage: " + ctx.config.prefix + "unban @user (mention, reply, or phone number).");
        return;
      }
      const changed = [];
      const absent = [];
      for (const target of targets) {
        const aliases = await getBotCommandBanAliases(ctx.sock, target);
        const wasBanned = (await Promise.all(aliases.map(isBotCommandBanned))).some(Boolean);
        if (!wasBanned) {
          absent.push("@" + numberFromJid(target));
          continue;
        }
        for (const alias of aliases) await setBotCommandBanned(alias, false, ctx.senderJid);
        changed.push(target);
      }
      const lines = ["✅ *BOT COMMAND ACCESS UPDATE*"];
      if (changed.length) lines.push("Unbanned: " + changed.map(jid => "@" + numberFromJid(jid)).join(", "));
      if (absent.length) lines.push("Not on the ban list: " + absent.join(", "));
      await ctx.send({ text: lines.join("\n"), mentions: changed }, true, false);
    }
  },
  {
    name: "typing", category: "Presence",
    description: "Show a typing indicator briefly in this chat.",
    run: async ctx => {
      if (!(await canManage(ctx, "presence indicators"))) return;
      await ctx.sock.sendPresenceUpdate("composing", ctx.jid);
      await wait(2200);
      await ctx.sock.sendPresenceUpdate("paused", ctx.jid).catch(() => {});
      await ctx.reply("⌨️ Typing indicator sent.");
    }
  },
  {
    name: "recording", category: "Presence",
    description: "Show a recording indicator without sending audio.",
    run: async ctx => {
      if (!(await canManage(ctx, "presence indicators"))) return;
      await ctx.sock.sendPresenceUpdate("recording", ctx.jid);
      await wait(2200);
      await ctx.sock.sendPresenceUpdate("paused", ctx.jid).catch(() => {});
      await ctx.reply("🎙️ Recording indicator sent. No audio was recorded or sent.");
    }
  },
  makeToggle("autotype", "autotype", "Presence", {
    description: "Show a typing indicator when this chat sends a message."
  }),
  makeToggle("online", "alwayson", "Presence", {
    aliases: ["alwayson"],
    global: true, ownerOnly: true,
    description: "Toggle whether FEI XMD publishes its online presence continuously.",
    onChange: async (ctx, enabled) => {
      await ctx.sock.sendPresenceUpdate(enabled ? "available" : "unavailable").catch(() => {});
    }
  }),


makeToggle("statusreact", "statusreact", "Status", {
  global: true,
  ownerOnly: true,
  description: "Automatically react to every WhatsApp status posted by your contacts."
}),

{ name: "statusreactmode", category: "Status", description: "Choose the emoji used by status auto-react.", run: async ctx => {
  if (!(await ownerOnly(ctx, "status auto-react"))) return;
  const emoji = String(ctx.args || "").trim();
  const settings = await getChatSettings("global");
  if (!emoji) {
    await ctx.reply("Current status auto-react emoji: " + (settings.statusreactmode || "random") +
      "\nUsage: " + ctx.config.prefix + "statusreactmode random\nOr: " + ctx.config.prefix + "statusreactmode ❤️");
    return;
  }
  if (emoji.length > 8 || /[\r\n]/.test(emoji)) {
    await ctx.reply("Use 'random' or one short emoji.");
    return;
  }
  await setChatSetting("global", "statusreactmode", emoji === "random" ? "random" : emoji);
  await ctx.reply("✅ Status auto-react emoji set to " + emoji + ".");
}},

{ name: "statusreactkeys", category: "Status", description: "Only auto-react to statuses containing specific words.", run: async ctx => {
  if (!(await ownerOnly(ctx, "status auto-react keywords"))) return;
  const raw = String(ctx.args || "").trim();
  if (!raw) {
    const settings = await getChatSettings("global");
    await ctx.reply("Current status auto-react keywords: " +
      ((settings.statusreactkeys || []).join(", ") || "All statuses") +
      "\nUsage: " + ctx.config.prefix + "statusreactkeys word1, word2\nUse " + ctx.config.prefix + "statusreactkeys clear to remove the filter.");
    return;
  }
  const values = raw.toLowerCase() === "clear" ? [] : raw.split(",").map(v => v.trim().slice(0, 60)).filter(Boolean).slice(0, 20);
  await setChatSetting("global", "statusreactkeys", values);
  await ctx.reply("✅ Status auto-react keyword filter " + (values.length ? "set: " + values.join(", ") : "cleared; all statuses can be reacted to.") + ".");
}},


  makeToggle("autorec", "autorec", "Presence", {
    description: "Show a brief recording indicator for incoming messages."
  }),
  {
    name: "pres", category: "Presence",
    description: "Set the bot's WhatsApp availability.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "presence"))) return;
      const value = String(ctx.args || "").trim().toLowerCase();
      if (value !== "online" && value !== "offline") {
        await ctx.reply("Usage: " + ctx.config.prefix + "pres online/offline");
        return;
      }
      await ctx.sock.sendPresenceUpdate(value === "online" ? "available" : "unavailable");
      await ctx.reply("✅ Presence set to " + value + ".");
    }
  },
  {
    name: "sendvv", category: "Media & Tools",
    description: "Resend a normal image or video as view-once.",
    run: async ctx => {
      const quoted = quotedParts(ctx);
      if (!quoted) {
        await ctx.reply("Reply to a normal image or video with " + ctx.config.prefix + "sendvv [optional caption].");
        return;
      }
      if (isViewOnce(quoted.message)) {
        await ctx.reply("🔒 View-once media cannot be retrieved or converted. Reply to a normal image or video instead.");
        return;
      }
      const kind = mediaKind(quoted.message);
      if (kind !== "image" && kind !== "video") {
        await ctx.reply("Only normal images and videos can be resent as view-once.");
        return;
      }
      const buffer = await downloadQuotedMedia(ctx, quoted);
      const body = unwrapMessage(quoted.message);
      const caption = String(ctx.args || (body.imageMessage && body.imageMessage.caption) ||
        (body.videoMessage && body.videoMessage.caption) || "").trim();
      const content = { [kind]: buffer, viewOnce: true };
      if (caption) content.caption = caption.slice(0, 1000);
      await ctx.send(content);
    }
  },
  {
    name: "vvinfo", category: "Media & Tools",
    description: "Show type and metadata for a replied-to message without opening its media.",
    run: async ctx => {
      const quoted = quotedParts(ctx);
      if (!quoted) {
        await ctx.reply("Reply to a message with " + ctx.config.prefix + "vvinfo.");
        return;
      }
      const viewOnce = isViewOnce(quoted.message);
      const body = unwrapMessage(quoted.message);
      const kind = mediaKind(quoted.message) || Object.keys(body)[0] || "message";
      const caption = body.imageMessage && body.imageMessage.caption ||
        body.videoMessage && body.videoMessage.caption ||
        body.documentMessage && body.documentMessage.caption || "";
      await ctx.reply("🔎 Message info\nType: " + kind.replace(/Message$/, "") +
        "\nView-once: " + (viewOnce ? "Yes" : "No") +
        "\nCaption: " + (caption ? String(caption).slice(0, 250) : "None") +
        (viewOnce ? "\n🔒 The media itself was not retrieved." : ""));
    }
  },
  makeToggle("autoreact", "autoreact", "Bot Settings", {
    description: "Automatically react to incoming messages in this chat."
  }),
  {
    name: "reactmode", category: "Bot Settings",
    description: "Choose the emoji used by autoreact.",
    run: async ctx => {
      if (!(await canManage(ctx, "auto-reactions"))) return;
      const emoji = String(ctx.args || "").trim();
      if (!emoji) {
        const settings = await getChatSettings(ctx.jid);
        await ctx.reply("Current reaction: " + settings.reactmode + "\nUsage: " + ctx.config.prefix + "reactmode ❤️");
        return;
      }
      if (emoji.length > 8 || /[\r\n]/.test(emoji)) {
        await ctx.reply("Use one emoji or a short emoji combination.");
        return;
      }
      await setChatSetting(ctx.jid, "reactmode", emoji);
      await ctx.reply("✅ Auto-reaction set to " + emoji + ".");
    }
  },
  {
    name: "reactkeys", category: "Bot Settings",
    description: "Limit auto-reactions to messages containing specific words.",
    run: async ctx => {
      if (!(await canManage(ctx, "auto-reaction keywords"))) return;
      const settings = await getChatSettings(ctx.jid);
      const raw = String(ctx.args || "").trim();
      if (!raw) {
        await ctx.reply("Current keywords: " + ((settings.reactkeys || []).join(", ") || "All messages") +
          "\nUsage: " + ctx.config.prefix + "reactkeys word1, word2\nUse " + ctx.config.prefix + "reactkeys clear to remove the filter.");
        return;
      }
      const values = raw.toLowerCase() === "clear" ? [] :
        raw.split(",").map(value => value.trim().slice(0, 60)).filter(Boolean).slice(0, 20);
      await setChatSetting(ctx.jid, "reactkeys", values);
      await ctx.reply("✅ Auto-reaction keyword filter " +
        (values.length ? "set: " + values.join(", ") : "cleared; all messages can be reacted to.") + ".");
    }
  },
  makeToggle("antidel", "antidel", "Chat & Privacy", {
    global: true,
    ownerOnly: true,
    description: "Enable anti-delete across all private chats and groups, including messages from numbers that are not saved as contacts. Reports include the sender name/number when available and the source group.",
    onChange: async (_ctx, enabled) => {
      // Older versions stored anti-delete independently per chat. Clear those
      // legacy overrides when the global switch is turned off so it truly stops everywhere.
      if (!enabled) {
        for (const jid of await getEnabledChats("antidel")) {
          await setChatSetting(jid, "antidel", false);
        }
      }
    }
  }),
  makeToggle("antiedit", "antiedit", "Chat & Privacy", {
    description: "Report edited message text/captions while FEI XMD is connected. Requires the original message to have been cached after enabling this feature."
  }),
  {
    name: "banchecker", category: "Chat & Privacy",
    description: "Check the WhatsApp ban status of a phone number using the Benfei Tech verification API.",
    run: async ctx => {
      const raw = String(ctx.args || "").trim();
      const phoneNumber = raw.replace(/\D/g, "");
      if (!/^\d{8,15}$/.test(phoneNumber)) {
        await ctx.reply("Usage: " + ctx.config.prefix + "banchecker 2349012345678\nInclude the country code; use digits only.");
        return;
      }

      await ctx.reply("🛡️ _Submitting the number to Benfei Tech’s WhatsApp account-status endpoint. Please wait for the verification response._");
      let response;
      try {
        response = await fetch("https://benfeitech.com/api/ban-check", {
          method: "POST",
          headers: { "content-type": "application/json", accept: "application/json" },
          body: JSON.stringify({ phoneNumber }),
          signal: AbortSignal.timeout(30000)
        });
      } catch (error) {
        if (error && error.name === "TimeoutError") throw new Error("The verification API timed out. Please try again.");
        throw new Error("The verification API could not be reached. Check connectivity and try again.");
      }

      const rawResponse = await response.text();
      let payload;
      try {
        payload = JSON.parse(rawResponse);
      } catch {
        throw new Error("The verification API returned an invalid response (HTTP " + response.status + ").");
      }
      if (!response.ok) {
        throw new Error(String(payload && payload.error || "The verification API returned HTTP " + response.status + ".").slice(0, 240));
      }

      const status = String(payload && payload.status || "").trim().toLowerCase().replace(/[\s-]+/g, "_");
      let resultLabel;
      if (status === "banned") resultLabel = "❌ *BANNED*";
      else if (["not_banned", "notbanned", "clear", "active", "not_blocked"].includes(status)) resultLabel = "✅ *NOT BANNED*";
      else throw new Error("The API returned an unrecognized account status. No conclusion was reported.");

      const checkedNumber = String(payload.phoneNumber || phoneNumber).replace(/\D/g, "");
      const checkedAt = String(payload.checkedAt || "Not provided by API");
      const footer = "⚡ *𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐁𝐄𝐍𝐅𝐄𝐈 𝐓𝐄𝐂𝐇*";
      await ctx.reply(
        "╭━━〔 📱 *WHATSAPP BAN CHECK* 〕━━┈⊷\n" +
        "┃ ✧ *NUMBER:* +" + checkedNumber + "\n" +
        "┃ ✧ *STATUS:* " + resultLabel + "\n" +
        "┃ ✧ *CHECKED AT:* " + checkedAt + "\n" +
        "╰━━━━━━━━━━━━┈⊷\n\n" + footer,
        false
      );
    }
  },
  {
    name: "autostatus",
    aliases: ["autoview"],
    category: "Status",
    description: "Automatically view new statuses and control status reactions.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "automatic status view"))) return;
      const parts = String(ctx.args || "").trim().toLowerCase().split(/\s+/).filter(Boolean);
      const settings = await getChatSettings("global");
      if (!parts.length) {
        await ctx.reply(
          "📱 Auto status view: " + (settings.autoview ? "ON" : "OFF") +
          "\n💚 Status reactions: " + (settings.statusreact ? "ON" : "OFF") +
          "\nUsage: " + ctx.config.prefix + "autostatus on/off" +
          "\n       " + ctx.config.prefix + "autostatus react on/off"
        );
        return;
      }
      if (parts[0] === "on" || parts[0] === "off") {
        const enabled = parts[0] === "on";
        await setChatSetting("global", "autoview", enabled);
        await ctx.reply("✅ Automatic status viewing " + (enabled ? "enabled." : "disabled."));
        return;
      }
      if (parts[0] === "react" && (parts[1] === "on" || parts[1] === "off") && parts.length === 2) {
        const enabled = parts[1] === "on";
        await setChatSetting("global", "statusreact", enabled);
        await ctx.reply("✅ Automatic status reactions " + (enabled ? "enabled." : "disabled."));
        return;
      }
      await ctx.reply(
        "Usage: " + ctx.config.prefix + "autostatus on/off" +
        "\nOr: " + ctx.config.prefix + "autostatus react on/off"
      );
    }
  },
  makeToggle("anticall", "anticall", "Bot Settings", {
    global: true, ownerOnly: true,
    description: "Reject incoming WhatsApp calls where the installed Baileys build supports rejection."
  }),
  {
    name: "pollres", category: "Chat & Privacy",
    description: "Show cached results for a replied-to poll.",
    run: async ctx => {
      const quoted = quotedParts(ctx);
      if (!quoted) {
        await ctx.reply("Reply to a poll message with " + ctx.config.prefix + "pollres.");
        return;
      }
      const poll = getCachedPoll(ctx.jid, quoted.key.id);
      if (!poll) {
        await ctx.reply("Poll results are available only for polls and votes received while FEI XMD was online.");
        return;
      }
      try {
        const { getAggregateVotesInPollMessage } = await import("@whiskeysockets/baileys");
        const aggregate = getAggregateVotesInPollMessage({
          message: poll.msg.message, pollUpdates: poll.updates
        }, ctx.sock.user && ctx.sock.user.id);
        const options = aggregate && Array.isArray(aggregate.options) ? aggregate.options : [];
        if (!options.length) {
          await ctx.reply("No poll votes have been cached yet. Check the poll in WhatsApp for the live result.");
          return;
        }
        await ctx.reply("📊 Poll results\n" + options.map(option => {
          const voters = Array.isArray(option.voters) ? option.voters.length : Number(option.votes || 0);
          return "• " + String(option.name || "Option") + ": " + voters;
        }).join("\n"));
      } catch {
        await ctx.reply("Could not calculate cached poll results. WhatsApp still shows the live poll totals.");
      }
    }
  },
  {
    name: "unsend", category: "Chat & Privacy",
    description: "Delete a replied-to message sent by the bot.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "unsend"))) return;
      const quoted = quotedParts(ctx);
      if (!quoted || !quoted.key.fromMe) {
        await ctx.reply("Reply to a message sent by FEI XMD with " + ctx.config.prefix + "unsend.");
        return;
      }
      await ctx.sock.sendMessage(ctx.jid, { delete: quoted.key });
      await ctx.reply("✅ Delete request sent.");
    }
  },
  {
    name: "edit", category: "Chat & Privacy",
    description: "Edit a replied-to text message sent by the bot.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "message editing"))) return;
      const quoted = quotedParts(ctx);
      const text = String(ctx.args || "").trim();
      if (!quoted || !quoted.key.fromMe || !text) {
        await ctx.reply("Reply to a text message sent by FEI XMD: " + ctx.config.prefix + "edit corrected text");
        return;
      }
      if (text.length > 4000) {
        await ctx.reply("Keep the replacement text below 4,000 characters.");
        return;
      }
      await ctx.sock.sendMessage(ctx.jid, { text, edit: quoted.key });
      await ctx.reply("✅ Edit request sent.");
    }
  },
  {
    name: "gcreate", category: "Group",
    description: "Create a group and add participants.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "group creation"))) return;
      const parts = String(ctx.args || "").split("|").map(value => value.trim());
      const subject = parts[0] || "";
      const numbers = (parts[1] || "").match(/\+?\d{8,15}/g) || [];
      if (!subject || !numbers.length) {
        await ctx.reply("Usage: " + ctx.config.prefix + "gcreate Group name | 2348012345678, 2348098765432");
        return;
      }
      const participants = Array.from(new Set(numbers.map(value => value.replace(/\D/g, "") + "@s.whatsapp.net")));
      const created = await ctx.sock.groupCreate(subject.slice(0, 100), participants);
      const groupJid = created && (created.id || created.gid);
      await ctx.reply("✅ Group creation requested.\nName: " + subject.slice(0, 100) +
        (groupJid ? "\nGroup ID: " + groupJid : "") +
        (created && created.subject ? "\nSubject: " + created.subject : ""));
    }
  },
  {
    name: "gjoin", category: "Group",
    description: "Join a group using an invite link or code.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "group joining"))) return;
      const value = String(ctx.args || "").trim();
      const match = value.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/i);
      const code = match ? match[1] : value;
      if (!/^[A-Za-z0-9_-]{8,}$/.test(code)) {
        await ctx.reply("Usage: " + ctx.config.prefix + "gjoin https://chat.whatsapp.com/INVITECODE");
        return;
      }
      const result = await ctx.sock.groupAcceptInvite(code);
      await ctx.reply("✅ Group join request completed.\nGroup ID: " + String(result || "Accepted by WhatsApp."));
    }
  },
  {
    name: "greq", category: "Group",
    description: "List pending requests to join the current group.",
    run: async ctx => {
      const group = await groupAdmin(ctx, true);
      if (!group) return;
      if (typeof ctx.sock.groupRequestParticipantsList !== "function") {
        await ctx.reply("This Baileys build does not expose group join-request listing.");
        return;
      }
      const requests = await ctx.sock.groupRequestParticipantsList(ctx.jid);
      await ctx.reply("📥 Pending join requests: " + requests.length + "\n" +
        (requests.length ? requests.map((item, index) => (index + 1) + ". " + String(item.jid || item.id || "Unknown")).join("\n") : "No pending requests."));
    }
  },
  { name: "gapprove", category: "Group", description: "Approve a group join request.", run: async ctx => updateJoinRequest(ctx, "approve") },
  { name: "greject", category: "Group", description: "Reject a group join request.", run: async ctx => updateJoinRequest(ctx, "reject") },
  {
    name: "gaddmode", category: "Group",
    description: "Set whether all members or only admins can add group members.",
    run: async ctx => {
      const group = await groupAdmin(ctx, true);
      if (!group) return;
      const value = String(ctx.args || "").trim().toLowerCase();
      if (value !== "admin" && value !== "all") {
        await ctx.reply("Usage: " + ctx.config.prefix + "gaddmode admin/all");
        return;
      }
      await ctx.sock.groupMemberAddMode(ctx.jid, value === "admin" ? "admin_add" : "all_member_add");
      await setChatSetting(ctx.jid, "gaddmode", value);
      await ctx.reply("✅ Member-add mode set to " + value + ".");
    }
  },
  {
    name: "gjoinmode", category: "Group",
    description: "Turn group join-request approval on or off.",
    run: async ctx => {
      const group = await groupAdmin(ctx, true);
      if (!group) return;
      const value = String(ctx.args || "").trim().toLowerCase();
      if (value !== "on" && value !== "off") {
        await ctx.reply("Usage: " + ctx.config.prefix + "gjoinmode on/off");
        return;
      }
      await ctx.sock.groupJoinApprovalMode(ctx.jid, value);
      await setChatSetting(ctx.jid, "gjoinmode", value);
      await ctx.reply("✅ Group join approval set to " + value.toUpperCase() + ".");
    }
  },
  {
    name: "gicon", aliases: ["setgcpp"], category: "Group",
    description: "Update the current group's picture using an attached or replied-to image.",
    run: async ctx => {
      const group = await groupAdmin(ctx, true);
      if (!group) return;
      if (typeof ctx.sock.updateProfilePicture !== "function") {
        await ctx.reply("This Baileys build does not expose group picture updates.");
        return;
      }
      let buffer;
      const body = unwrapMessage(ctx.msg.message);
      if (body.imageMessage) {
        buffer = await downloadMediaMessage(ctx.msg, "buffer", {}, { reuploadRequest: ctx.sock.updateMediaMessage });
      } else {
        const quoted = quotedParts(ctx);
        if (!quoted || mediaKind(quoted.message) !== "image" || isViewOnce(quoted.message)) {
          await ctx.reply("Attach an image with " + ctx.config.prefix + ctx.command + ", or reply to a normal image with " + ctx.config.prefix + ctx.command + ".");
          return;
        }
        buffer = await downloadQuotedMedia(ctx, quoted);
      }
      await ctx.sock.updateProfilePicture(ctx.jid, buffer);
      await ctx.reply("✅ Group picture update requested.");
    }
  },
  {
    name: "tagadmins", category: "Group",
    description: "Mention all administrators in the current group.",
    run: async ctx => {
      if (!ctx.jid.endsWith("@g.us")) {
        await ctx.reply("Use this command inside a WhatsApp group.");
        return;
      }
      const metadata = await getGroupInfo(ctx.sock, ctx.jid);
      const admins = (metadata.participants || []).filter(participantIsAdmin);
      const mentions = admins.map(participantJid).filter(Boolean);
      if (!mentions.length) {
        await ctx.reply("No group administrators were found.");
        return;
      }
      await ctx.reply("🛡️ Group admins\n" + admins.map(item => "@" + numberFromJid(participantJid(item))).join(" "), true, { mentions });
    }
  },
  makeToggle("welcome", "welcome", "Group", { groupOnly: true, description: "Welcome members who join this group." }),
  makeToggle("goodbye", "goodbye", "Group", { groupOnly: true, description: "Send a goodbye message when members leave this group." }),
  {
    name: "warn", category: "Group",
    description: "Owner-controlled link warning enforcement, or add a manual warning to a group member.",
    run: async ctx => {
      const mode = String(ctx.args || "").trim().toLowerCase();
      if (mode === "on" || mode === "off") {
        if (!ctx.owner) {
          await ctx.reply("⛔ Only the bot owner can turn automatic link warnings on or off.");
          return;
        }
        const group = await groupAdmin(ctx, mode === "on");
        if (!group) return;
        await setChatSetting(ctx.jid, "warnlinks", mode === "on");
        await ctx.send({
          text: mode === "on"
            ? "✅ *LINK WARNINGS ENABLED*\nLinks from non-admin members will be deleted immediately. Each member gets 3 warnings; the third triggers removal."
            : "🔕 Automatic link warnings are now disabled for this group."
        }, true, false);
        return;
      }

      if (!(await groupAdmin(ctx, false))) return;
      const targets = getTargets(ctx.msg, ctx.args);
      if (!targets.length) {
        const settings = await getChatSettings(ctx.jid);
        await ctx.reply("Automatic link warnings: " + (settings.warnlinks ? "ON" : "OFF") +
          "\nUsage: " + ctx.config.prefix + "warn @user (manual warning), or owner: " + ctx.config.prefix + "warn on/off");
        return;
      }
      const reason = String(ctx.args || "").replace(/\+?\d{8,15}/g, "").trim().slice(0, 250);
      const lines = [];
      for (const target of targets.slice(0, 5)) {
        const count = await addWarning(ctx.jid, target);
        lines.push("@" + numberFromJid(target) + ": warning " + count + "/3" + (reason ? " — " + reason : ""));
      }
      await ctx.send({ text: "⚠️ Warning recorded\n" + lines.join("\n"), mentions: targets.slice(0, 5) }, true, false);
    }
  },
  {
    name: "warnlist", category: "Group",
    description: "List members who have warnings in the current group.",
    run: async ctx => {
      if (!(await groupAdmin(ctx, false))) return;
      const warnings = await listWarnings(ctx.jid);
      await ctx.reply("⚠️ Group warning list\n" +
        (warnings.length ? warnings.map(item => "@" + numberFromJid(item.jid) + ": " + item.count).join("\n") : "No warnings recorded."),
        true, { mentions: warnings.map(item => item.jid) });
    }
  },
  makeToggle("antilink", "antilink", "Group", { groupOnly: true, description: "Delete links posted by non-admins in this group." }),
  makeToggle("antibot", "antibot", "Group", { groupOnly: true, description: "Delete bot commands sent by non-admins and tag the sender." }),
  makeToggle("antispam", "antispam", "Group", { groupOnly: true, description: "Detect bursts of messages from non-admins in this group." }),
  makeToggle("antitag", "antitag", "Group", { groupOnly: true, description: "Prevent mass mentions in this group." }),
  {
    name: "slowmode", category: "Group",
    description: "Set a per-member message cooldown in seconds; use 0 to turn it off.",
    run: async ctx => {
      const group = await groupAdmin(ctx, true);
      if (!group) return;
      const settings = await getChatSettings(ctx.jid);
      const raw = String(ctx.args || "").trim().toLowerCase();
      if (!raw) {
        await ctx.reply("Current slow mode: " + (settings.slowmode ? settings.slowmode + " seconds" : "OFF") +
          "\nUsage: " + ctx.config.prefix + "slowmode 10 (or off)");
        return;
      }
      const seconds = raw === "off" ? 0 : Number(raw);
      if (!Number.isInteger(seconds) || seconds < 0 || seconds > 3600) {
        await ctx.reply("Choose 0/off to disable, or a cooldown between 1 and 3600 seconds.");
        return;
      }
      await setChatSetting(ctx.jid, "slowmode", seconds);
      await ctx.reply("✅ Slow mode " + (seconds ? "set to " + seconds + " seconds." : "disabled."));
    }
  },
  {
    name: "status", category: "Status",
    description: "Post a text WhatsApp status.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "status posting"))) return;
      const text = String(ctx.args || "").trim();
      if (!text) {
        await ctx.reply("Usage: " + ctx.config.prefix + "status Your status text");
        return;
      }
      await ctx.sock.sendMessage("status@broadcast", { text: text.slice(0, 65000) });
      await ctx.reply("✅ Status post request sent. Confirm it appears in WhatsApp; status posting can vary by WhatsApp/Baileys version.");
    }
  },
  {
    name: "gcstatus",
    aliases: ["groupstatus"],
    category: "Status",
    description: "Post text, image, video, audio or sticker as a status for this group.",
    run: async ctx => {
      const group = await groupAdmin(ctx, false);
      if (!group) return;

      const quoted = quotedParts(ctx);
      const body = quoted ? unwrapMessage(quoted.message) : null;
      const kind = body ? mediaKind(quoted.message) : "";
      const text = String(ctx.args || "").trim();

      if (!kind && !text) {
        await ctx.reply(
          "Reply to an image, video, audio or sticker with " + ctx.config.prefix + "gcstatus [caption]" +
          "\nOr post text with " + ctx.config.prefix + "gcstatus Your text here"
        );
        return;
      }
      if (kind && !["image", "video", "audio", "sticker"].includes(kind)) {
        await ctx.reply("Unsupported quoted media. Reply to an image, video, audio or sticker.");
        return;
      }

      await ctx.react("⏳");
      try {
        if (!kind) {
          for (const part of splitTextPreservingFormat(text)) {
            await postGroupStatus(ctx, {
              text: part,
              backgroundColor: "#9C27B0"
            });
          }
        } else {
          const buffer = await downloadQuotedMedia(ctx, quoted);
          if (!buffer || !buffer.length) throw new Error("The quoted media could not be downloaded.");
          const captionSource = text ||
            (body.imageMessage && body.imageMessage.caption) ||
            (body.videoMessage && body.videoMessage.caption) || "";
          const captions = splitTextPreservingFormat(String(captionSource).trim());

          if (kind === "audio") {
            const media = body.audioMessage || {};
            await postGroupStatus(ctx, {
              audio: buffer,
              mimetype: media.mimetype || "audio/ogg; codecs=opus",
              ptt: Boolean(media.ptt)
            });
          } else if (kind === "sticker") {
            await postGroupStatus(ctx, { sticker: buffer });
          } else {
            const parts = captions.length ? captions : [""];
            for (const part of parts) {
              await postGroupStatus(ctx, { [kind]: buffer, caption: part });
            }
          }
        }
        await ctx.react("✅");
        const successMessage = "✅ Group status posted successfully.\n\n" + POWERED_FOOTER;
        await ctx.send(withChannelAttribution(ctx.config, { text: successMessage }, true));
      } catch (error) {
        await ctx.react("❌");
        await ctx.reply("⚠️ Failed to post group status: " + String(error && error.message || error).slice(0, 220));
      }
    }
  },
  {
    name: "statusinfo", category: "Status",
    description: "Show basic metadata for a replied-to status update.",
    run: async ctx => {
      const info = getContextInfo(ctx.msg.message);
      if (!info || !info.stanzaId) {
        await ctx.reply("Reply to a status update with " + ctx.config.prefix + "statusinfo.");
        return;
      }
      await ctx.reply("📱 Status information\nMessage ID: " + info.stanzaId +
        "\nPosted by: " + String(info.participant || "Unavailable") +
        "\nMedia/content: not downloaded by this command.");
    }
  },
  {
    name: "statusmention", category: "Status",
    description: "Post a text status mentioning the current group's members.",
    run: async ctx => {
      const group = await groupAdmin(ctx, false);
      if (!group) return;
      const text = String(ctx.args || "").trim();
      if (!text) {
        await ctx.reply("Usage: " + ctx.config.prefix + "statusmention Your status text");
        return;
      }
      const mentions = (group.participants || []).map(participantJid).filter(Boolean).slice(0, 100);
      await ctx.sock.sendMessage("status@broadcast", { text: text.slice(0, 60000), mentions }, { statusJidList: mentions });
      await ctx.reply("✅ Status-with-mentions request sent. Confirm display in WhatsApp.");
    }
  },
  {
    name: "pin", category: "Chat & Privacy",
    description: "Pin this chat in the bot's WhatsApp chat list.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "chat pinning"))) return;
      await ctx.sock.chatModify({ pin: true }, ctx.jid);
      await ctx.reply("📌 Chat pin request sent.");
    }
  },
  {
    name: "unpin", category: "Chat & Privacy",
    description: "Unpin this chat in the bot's WhatsApp chat list.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "chat pinning"))) return;
      await ctx.sock.chatModify({ pin: false }, ctx.jid);
      await ctx.reply("📌 Chat unpin request sent.");
    }
  },
  {
    name: "star", category: "Chat & Privacy",
    description: "Star a replied-to message.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "message starring"))) return;
      const quoted = quotedParts(ctx);
      if (!quoted) {
        await ctx.reply("Reply to a message with " + ctx.config.prefix + "star.");
        return;
      }
      await ctx.sock.star(ctx.jid, [{ id: quoted.key.id, fromMe: quoted.key.fromMe }], true);
      await ctx.reply("⭐ Star request sent.");
    }
  },
  {
    name: "unstar", category: "Chat & Privacy",
    description: "Unstar a replied-to message.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "message starring"))) return;
      const quoted = quotedParts(ctx);
      if (!quoted) {
        await ctx.reply("Reply to a message with " + ctx.config.prefix + "unstar.");
        return;
      }
      await ctx.sock.star(ctx.jid, [{ id: quoted.key.id, fromMe: quoted.key.fromMe }], false);
      await ctx.reply("⭐ Unstar request sent.");
    }
  },
  {
    name: "forward", category: "Chat & Privacy",
    description: "Forward a replied-to normal message into the current chat.",
    run: async ctx => {
      const quoted = quotedParts(ctx);
      if (!quoted) {
        await ctx.reply("Reply to a message with " + ctx.config.prefix + "forward.");
        return;
      }
      if (isViewOnce(quoted.message)) {
        await ctx.reply("🔒 View-once messages cannot be forwarded by this command.");
        return;
      }
      await ctx.sock.sendMessage(ctx.jid, { forward: quoted.wrapped });
      await ctx.reply("✅ Forward request sent.");
    }
  },
  {
    name: "archive", category: "Chat & Privacy",
    description: "Archive the current chat in the bot's WhatsApp account.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "chat archiving"))) return;
      await ctx.sock.chatModify({ archive: true, lastMessages: [ctx.msg] }, ctx.jid);
      await ctx.reply("📦 Archive request sent.");
    }
  },
  {
    name: "unarchive", category: "Chat & Privacy",
    description: "Unarchive the current chat.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "chat archiving"))) return;
      await ctx.sock.chatModify({ archive: false, lastMessages: [ctx.msg] }, ctx.jid);
      await ctx.reply("📦 Unarchive request sent.");
    }
  },
  {
    name: "mutechat", category: "Chat & Privacy",
    description: "Mute the current chat for 8h, 24h, 7d, or forever.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "chat muting"))) return;
      const value = String(ctx.args || "8h").trim().toLowerCase();
      const durations = { "8h": 8 * 60 * 60 * 1000, "24h": 24 * 60 * 60 * 1000, "7d": 7 * 24 * 60 * 60 * 1000, forever: 20 * 365 * 24 * 60 * 60 * 1000 };
      if (!Object.prototype.hasOwnProperty.call(durations, value)) {
        await ctx.reply("Usage: " + ctx.config.prefix + "mutechat 8h/24h/7d/forever");
        return;
      }
      await ctx.sock.chatModify({ mute: Date.now() + durations[value] }, ctx.jid);
      await ctx.reply("🔕 Chat mute request sent (" + value + ").");
    }
  },
  {
    name: "unmutechat", category: "Chat & Privacy",
    description: "Unmute the current chat.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "chat muting"))) return;
      await ctx.sock.chatModify({ mute: null }, ctx.jid);
      await ctx.reply("🔔 Unmute request sent.");
    }
  },
  {
    name: "readchat", category: "Chat & Privacy",
    description: "Mark the current chat as read.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "chat read state"))) return;
      await ctx.sock.chatModify({ markRead: true, lastMessages: [ctx.msg] }, ctx.jid);
      await ctx.reply("✅ Mark-as-read request sent.");
    }
  },
  {
    name: "unreadchat", category: "Chat & Privacy",
    description: "Mark the current chat as unread.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "chat read state"))) return;
      await ctx.sock.chatModify({ markRead: false, lastMessages: [ctx.msg] }, ctx.jid);
      await ctx.reply("✅ Mark-as-unread request sent.");
    }
  },
  {
    name: "disappear", category: "Chat & Privacy",
    description: "Set disappearing messages to 24h, 7d, 90d, or off.",
    run: async ctx => {
      const value = String(ctx.args || "").trim().toLowerCase();
      const durations = { "24h": 86400, "7d": 604800, "90d": 7776000, off: 0 };
      if (!Object.prototype.hasOwnProperty.call(durations, value)) {
        await ctx.reply("Usage: " + ctx.config.prefix + "disappear 24h/7d/90d/off");
        return;
      }
      if (ctx.jid.endsWith("@g.us")) {
        const group = await groupAdmin(ctx, true);
        if (!group) return;
        await ctx.sock.groupToggleEphemeral(ctx.jid, durations[value]);
      } else {
        if (!(await ownerOnly(ctx, "disappearing messages"))) return;
        await ctx.sock.sendMessage(ctx.jid, { disappearingMessagesInChat: durations[value] });
      }
      await ctx.reply("✅ Disappearing-message setting request sent: " + value + ".");
    }
  },
  {
    name: "block", category: "Chat & Privacy",
    description: "Block a mentioned, replied-to, or specified contact.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "contact blocking"))) return;
      const targets = getTargets(ctx.msg, ctx.args);
      if (!targets.length) {
        await ctx.reply("Usage: " + ctx.config.prefix + "block 2348012345678 (or mention/reply to the contact)");
        return;
      }
      for (const target of targets.slice(0, 5)) await ctx.sock.updateBlockStatus(target, "block");
      await ctx.reply("✅ Block request sent for " + targets.slice(0, 5).map(numberFromJid).join(", ") + ".");
    }
  },
  {
    name: "unblock", category: "Chat & Privacy",
    description: "Unblock a mentioned, replied-to, or specified contact.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "contact blocking"))) return;
      const targets = getTargets(ctx.msg, ctx.args);
      if (!targets.length) {
        await ctx.reply("Usage: " + ctx.config.prefix + "unblock 2348012345678 (or mention/reply to the contact)");
        return;
      }
      for (const target of targets.slice(0, 5)) await ctx.sock.updateBlockStatus(target, "unblock");
      await ctx.reply("✅ Unblock request sent for " + targets.slice(0, 5).map(numberFromJid).join(", ") + ".");
    }
  },
  {
    name: "prvset", category: "Bot Settings",
    description: "Show the WhatsApp account's current privacy settings.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "WhatsApp privacy settings"))) return;
      if (typeof ctx.sock.fetchPrivacySettings !== "function") {
        await ctx.reply("This Baileys build does not expose privacy-setting reads.");
        return;
      }
      const settings = await ctx.sock.fetchPrivacySettings(true);
      await ctx.reply("🔒 WhatsApp privacy settings\n" +
        Object.entries(settings || {}).map(([key, value]) => "• " + key + ": " + String(value)).join("\n"));
    }
  },
  {
    name: "readreceipt", category: "Bot Settings",
    description: "Enable or disable WhatsApp read receipts for the bot account.",
    run: async ctx => {
      if (!(await ownerOnly(ctx, "read receipts"))) return;
      const value = String(ctx.args || "").trim().toLowerCase();
      if (value !== "on" && value !== "off") {
        await ctx.reply("Usage: " + ctx.config.prefix + "readreceipt on/off");
        return;
      }
      await ctx.sock.updateReadReceiptsPrivacy(value === "on" ? "all" : "none");
      await ctx.reply("✅ Read receipts set to " + value + ".");
    }
  }
];

async function updateJoinRequest(ctx, action) {
  const group = await groupAdmin(ctx, true);
  if (!group) return;
  const targets = getTargets(ctx.msg, ctx.args);
  if (!targets.length) {
    await ctx.reply("Usage: " + ctx.config.prefix + (action === "approve" ? "gapprove" : "greject") + " @user");
    return;
  }
  const result = await ctx.sock.groupRequestParticipantsUpdate(ctx.jid, targets, action);
  await ctx.reply("✅ Join request " + action + " request sent.\n" + JSON.stringify(result).slice(0, 1200));
}

export default commands;
