import { formatAdmins, getGroupInfo, requireGroupAdmin } from "../lib/groups.js";
import { getKnownOnlineJids } from "../lib/presence-tracker.js";
import { getTargets, numberFromJid, participantJid } from "../lib/utils.js";

const wait = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));

export default [
  {
    name: "groupinfo",
    category: "Group",
    description: "Show group metadata.",
    run: async ctx => {
      const metadata = await getGroupInfo(ctx.sock, ctx.jid);
      const participants = metadata.participants || [];
      const adminCount = participants.filter(p => p.admin === "admin" || p.admin === "superadmin").length;
      await ctx.reply("👥 Group information\n" +
        "📌 Name: " + (metadata.subject || "Unnamed group") + "\n" +
        "🆔 ID: " + ctx.jid + "\n" +
        "👤 Members: " + participants.length + "\n" +
        "🛡️ Admins: " + adminCount + "\n" +
        "📝 Description: " + (metadata.desc || "No description"));
    }
  },
  {
    name: "getgcpp",
    category: "Group",
    description: "Fetch and display the current group's profile picture.",
    run: async ctx => {
      if (!String(ctx.jid || "").endsWith("@g.us")) {
        await ctx.reply("Use this command inside a WhatsApp group.");
        return;
      }
      if (typeof ctx.sock.profilePictureUrl !== "function") {
        await ctx.reply("This Baileys build does not expose group profile-picture lookup.");
        return;
      }
      try {
        const url = await ctx.sock.profilePictureUrl(ctx.jid, "image");
        if (!url) {
          await ctx.reply("This group does not currently expose a profile picture.");
          return;
        }
        await ctx.send({ image: { url }, caption: "📷 *GROUP PROFILE PICTURE*" }, false, false);
      } catch {
        await ctx.reply("I couldn't fetch this group's profile picture. It may be hidden by WhatsApp privacy settings.");
      }
    }
  },
  {
    name: "onlineusers",
    category: "Group",
    description: "List online members of the current group.",
    run: async ctx => {
      if (!String(ctx.jid || "").endsWith("@g.us")) {
        await ctx.reply("Use this command inside a WhatsApp group.");
        return;
      }
      const metadata = await getGroupInfo(ctx.sock, ctx.jid);
      const participants = (metadata.participants || []).map(participant => ({
        participant,
        jid: participantJid(participant)
      })).filter(item => item.jid);
      if (typeof ctx.sock.presenceSubscribe === "function") {
        for (let offset = 0; offset < participants.length; offset += 25) {
          await Promise.allSettled(participants.slice(offset, offset + 25).map(item =>
            ctx.sock.presenceSubscribe(item.jid)
          ));
          if (offset + 25 < participants.length) await wait(100);
        }
        await wait(1200);
      }
      const onlineJids = new Set(getKnownOnlineJids(participants.map(item => item.jid)));
      const online = participants.filter(item => onlineJids.has(item.jid.replace(/^(\d+):\d+@/, "$1@")));
      if (!online.length) {
        await ctx.send({
          text: "🟢 *ONLINE USERS*\n\nNo online users found."
        }, false, false);
        return;
      }
      const mentions = online.map(item => item.jid);
      const lines = online.map((item, index) =>
        (index + 1) + ". @" + numberFromJid(item.jid)
      );
      let text = "🟢 *ONLINE USERS*\n";
      text += "👥 Online now: *" + online.length + " / " + participants.length + "*\n\n";
      text += lines.join("\n");
      await ctx.send({ text, mentions }, false, false);
    }
  },
  {
    name: "admins",
    category: "Group",
    description: "Mention group admins.",
    run: async ctx => {
      const metadata = await getGroupInfo(ctx.sock, ctx.jid);
      const info = formatAdmins(metadata.participants || []);
      if (!info.admins.length) {
        await ctx.reply("No group admins were found.");
        return;
      }
      const lines = info.admins.map((participant, index) =>
        (index + 1) + ". @" + numberFromJid(participantJid(participant)));
      await ctx.reply("🛡️ Admins in " + (metadata.subject || "this group") + "\n\n" + lines.join("\n"), true, {
        mentions: info.mentions
      });
    }
  },
  {
    name: "tagall",
    aliases: ["hidetag", "tag", "👋"],
    hiddenAliases: ["👋"],
    category: "Group",
    description: "Mention all group members.",
    run: async ctx => {
      const group = await requireGroupAdmin(ctx, { requireBotAdmin: false });
      if (!group) return;
      const mentions = (group.participants || []).map(participantJid).filter(Boolean);
      if (!mentions.length) {
        await ctx.reply("No group participants were found.");
        return;
      }
      const hidden = ["hidetag", "tag", "👋"].includes(ctx.command);
      const prefixText = ctx.args || (hidden ? "📢" : "📢 Attention everyone!");
      const mentionLines = hidden ? "‎" : group.participants
        .map(participant => "@" + numberFromJid(participantJid(participant))).join(" ");
      const text = hidden ? prefixText + "\n‎" : prefixText + "\n\n" + mentionLines;
      // Tag-style commands must never add the channel newsletter attribution.
      await ctx.send({ text, mentions }, true, false);
    }
  },
  {
    name: "link",
    category: "Group",
    description: "Get the group invite link.",
    run: async ctx => {
      const group = await requireGroupAdmin(ctx);
      if (!group) return;
      const code = await ctx.sock.groupInviteCode(ctx.jid);
      await ctx.reply("🔗 Group invite link:\nhttps://chat.whatsapp.com/" + code);
    }
  },
  {
    name: "revoke",
    aliases: ["resetlink"],
    category: "Group",
    description: "Reset the group invite link.",
    run: async ctx => {
      const group = await requireGroupAdmin(ctx);
      if (!group) return;
      await ctx.sock.groupRevokeInvite(ctx.jid);
      await ctx.reply("✅ The group invite link has been reset.");
    }
  },
  { name: "kick", aliases: ["remove"], category: "Group", description: "Remove group participants.", run: async ctx => updateParticipants(ctx, "remove") },
  { name: "add", category: "Group", description: "Add participants by international number.", run: async ctx => updateParticipants(ctx, "add") },
  { name: "promote", category: "Group", description: "Promote a participant to admin.", run: async ctx => updateParticipants(ctx, "promote") },
  { name: "demote", category: "Group", description: "Demote a participant from admin.", run: async ctx => updateParticipants(ctx, "demote") },
  {
    name: "groupname",
    aliases: ["setname"],
    category: "Group",
    description: "Change the group name.",
    run: async ctx => {
      if (!ctx.args) {
        await ctx.reply("Usage: " + ctx.config.prefix + ctx.command + " New group name");
        return;
      }
      const group = await requireGroupAdmin(ctx);
      if (!group) return;
      await ctx.sock.groupUpdateSubject(ctx.jid, ctx.args.slice(0, 100));
      await ctx.reply("✅ Group name updated.");
    }
  },
  {
    name: "groupdesc",
    aliases: ["setdesc"],
    category: "Group",
    description: "Change the group description.",
    run: async ctx => {
      if (!ctx.args) {
        await ctx.reply("Usage: " + ctx.config.prefix + ctx.command + " New group description");
        return;
      }
      const group = await requireGroupAdmin(ctx);
      if (!group) return;
      await ctx.sock.groupUpdateDescription(ctx.jid, ctx.args.slice(0, 2048));
      await ctx.reply("✅ Group description updated.");
    }
  },
  {
    name: "close",
    category: "Group",
    description: "Allow only admins to send group messages.",
    run: async ctx => {
      const group = await requireGroupAdmin(ctx);
      if (!group) return;
      await ctx.sock.groupSettingUpdate(ctx.jid, "announcement");
      await ctx.reply("🔒 Group closed. Only admins can send messages now.");
    }
  },
  {
    name: "open",
    category: "Group",
    description: "Allow all members to send group messages.",
    run: async ctx => {
      const group = await requireGroupAdmin(ctx);
      if (!group) return;
      await ctx.sock.groupSettingUpdate(ctx.jid, "not_announcement");
      await ctx.reply("🔓 Group opened. All members can send messages now.");
    }
  },
  {
    name: "leave",
    category: "Group",
    description: "Make the bot leave the current group.",
    run: async ctx => {
      if (!ctx.jid.endsWith("@g.us")) {
        await ctx.reply("Use " + ctx.config.prefix + "leave inside a group chat.");
        return;
      }
      const group = await requireGroupAdmin(ctx, { requireBotAdmin: false });
      if (!group) return;
      await ctx.reply("👋 Leaving this group now.");
      await ctx.sock.groupLeave(ctx.jid);
    }
  }
];

async function updateParticipants(ctx, action) {
  const group = await requireGroupAdmin(ctx);
  if (!group) return;
  const targets = getTargets(ctx.msg, ctx.args);
  if (action === "add" && !targets.length) {
    await ctx.reply("Usage: " + ctx.config.prefix + "add 2348012345678 (country code included, no + sign needed)");
    return;
  }
  if (!targets.length) {
    await ctx.reply("Tag the target, reply to their message, or provide a full international phone number.");
    return;
  }
  const result = await ctx.sock.groupParticipantsUpdate(ctx.jid, targets, action);
  const lines = Array.isArray(result)
    ? result.map(item => String(item.jid || "participant") + ": " + String(item.status || "requested")).join("\n")
    : "WhatsApp accepted the group action request.";
  await ctx.reply("✅ " + action.charAt(0).toUpperCase() + action.slice(1) + " request processed.\n" + lines);
}
