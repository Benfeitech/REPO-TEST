import {
  unicodeBox,
  withPoweredFooter,
  safeFileName,
  validateHttpUrl,
  validateHttpsUrl
} from "../lib/api-client.js";
import { requestXrinaJson, validateDownloadUrl } from "../lib/xrina-api.js";

const TIKTOK_HOSTS = ["tiktok.com", "www.tiktok.com", "m.tiktok.com", "vm.tiktok.com", "vt.tiktok.com"];

const AIO_PLATFORM_HOSTS = Object.freeze({
  fb: ["facebook.com", "www.facebook.com", "m.facebook.com", "web.facebook.com", "fb.com", "www.fb.com", "fb.watch", "www.fb.watch"],
  twitter: ["x.com", "www.x.com", "twitter.com", "www.twitter.com", "mobile.twitter.com", "t.co"],
  instagram: ["instagram.com", "www.instagram.com", "m.instagram.com", "instagr.am", "www.instagr.am"],
  ytmp4: ["youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be"],
  tiktok: TIKTOK_HOSTS
});

function requireUrl(ctx, label = "URL") {
  const value = String(ctx.args || "").trim().split(/\s+/)[0];
  if (!value) throw new Error("Usage: " + ctx.config.prefix + ctx.command + " https://...");
  return validateHttpUrl(value, label);
}

function requireTiktokUrl(ctx) {
  const value = String(ctx.args || "").trim().split(/\s+/)[0];
  if (!value) throw new Error("Usage: " + ctx.config.prefix + ctx.command + " https://www.tiktok.com/...");
  return validateHttpsUrl(value, TIKTOK_HOSTS, "TikTok");
}

function requirePlatformUrl(ctx, platform, label) {
  const value = String(ctx.args || "").trim().split(/\s+/)[0];
  if (!value) throw new Error("Usage: " + ctx.config.prefix + ctx.command + " https://...");
  return validateHttpsUrl(value, AIO_PLATFORM_HOSTS[platform], label);
}

function shortText(value, limit = 260) {
  const text = String(value == null ? "" : value).replace(/[\r\n*_~\x60]/g, " ").replace(/\s+/g, " ").trim();
  return text.length > limit ? text.slice(0, limit - 1) + "…" : text;
}

function safeMediaUrl(value, label) {
  try {
    return validateDownloadUrl(value, label);
  } catch {
    return "";
  }
}

function responseData(payload) {
  return payload && payload.data && payload.data.data
    ? payload.data.data
    : payload && payload.data
      ? payload.data
      : payload && payload.result
        ? payload.result
        : payload;
}

function ensureApiSuccess(payload) {
  const outer = payload && payload.data;
  const inner = outer && outer.data;
  if (payload && (payload.status === false || payload.success === false) ||
      outer && (outer.status === false || outer.success === false) ||
      inner && (inner.status === false || inner.success === false)) {
    throw new Error("The download service could not process that link.");
  }
}

function mediaCaption(title, fields = []) {
  return withPoweredFooter(unicodeBox("📥 DOWNLOAD READY", [
    "✅ *" + shortText(title || "Your media", 180) + "*",
    ...fields.filter(Boolean)
  ].join("\n"), { footer: false }), 1200);
}

async function deliverAudio(ctx, url, title, fields = []) {
  const caption = mediaCaption(title, fields);
  await ctx.reply(caption, false);
  try {
    await ctx.send({
      audio: { url },
      mimetype: "audio/mpeg",
      fileName: safeFileName(title, "FEI-XMD-audio") + ".mp3",
      ptt: false
    }, false);
  } catch {
    await ctx.reply("🔗 Direct audio URL:\n" + url, false);
  }
}

async function deliverVideo(ctx, url, title, fields = []) {
  const caption = mediaCaption(title, fields);
  try {
    await ctx.send({ video: { url }, mimetype: "video/mp4", caption }, false);
  } catch {
    await ctx.reply(caption + "\n\n🔗 Direct video URL:\n" + url, false);
  }
}

async function deliverDocument(ctx, url, title, extension = "bin") {
  const ext = /^[a-z0-9]{1,8}$/i.test(String(extension || "")) ? String(extension).toLowerCase() : "bin";
  const fileName = safeFileName(title, "FEI-XMD-download") + "." + ext;
  const caption = mediaCaption(title, ["📁 Format: " + ext.toUpperCase()]);
  try {
    await ctx.send({ document: { url }, fileName, mimetype: "application/octet-stream", caption }, false);
  } catch {
    await ctx.reply(caption + "\n\n🔗 Direct download URL:\n" + url, false);
  }
}

function getAioFormat(data) {
  const formats = Array.isArray(data && data.formats) ? data.formats : [];
  const usable = formats.map(format => ({
    format,
    url: safeMediaUrl(format && format.downloadUrl, "download")
  })).filter(item => item.url);

  return usable.find(item => item.format.kind === "video" && item.format.hasWatermark === false) ||
    usable.find(item => item.format.kind === "video") ||
    usable.find(item => item.format.kind === "audio") ||
    usable[0] ||
    null;
}

function inferredExtension(format, url) {
  const declared = String(format && format.ext || "").toLowerCase().replace(/^\./, "");
  if (/^[a-z0-9]{2,8}$/.test(declared)) return declared;
  try {
    const path = new URL(url).pathname;
    const match = path.match(/\.([a-z0-9]{2,8})$/i);
    return match ? match[1].toLowerCase() : "bin";
  } catch {
    return "bin";
  }
}

async function runAioDownload(ctx, url, sourceLabel = "ALL-IN-ONE") {
  const heading = sourceLabel === "ALL-IN-ONE"
    ? "📥 ᴀʟʟ-ɪɴ-ᴏɴᴇ ᴅᴏᴡɴʟᴏᴀᴅ"
    : "📥 " + sourceLabel.toUpperCase() + " ᴅᴏᴡɴʟᴏᴀᴅ";
  await ctx.reply(unicodeBox(heading,
    "🔗 Source: " + url + "\n\nFetching available media formats. Please wait...", { footer: false }), false);

  const payload = await requestXrinaJson("download/aio2", { url });
  ensureApiSuccess(payload);
  const data = responseData(payload);
  const selected = getAioFormat(data);
  if (!selected) {
    throw new Error("No directly downloadable media format was returned for that link.");
  }

  const format = selected.format;
  const title = shortText(data.title || data.platform || format.label || "Media download", 180);
  const details = [
    data.platform ? "🌐 Platform: " + shortText(data.platform, 80) : "",
    format.label ? "🎞 Format: " + shortText(format.label, 120) : "",
    data.durationLabel ? "⏱ Duration: " + shortText(data.durationLabel, 40) : "",
    format.quality ? "✨ Quality: " + shortText(format.quality, 80) : ""
  ];
  if (format.kind === "audio") {
    await deliverAudio(ctx, selected.url, title, details);
  } else if (format.kind === "video") {
    await deliverVideo(ctx, selected.url, title, details);
  } else {
    await deliverDocument(ctx, selected.url, title, inferredExtension(format, selected.url));
  }
}

export const AIO_DOWNLOAD_NAMES = Object.freeze(["aio", "fb", "twitter", "instagram", "ytmp4", "tiktok"]);
export const DOWNLOAD_V2_NAMES = Object.freeze([...AIO_DOWNLOAD_NAMES, "play2", "tiktok2"]);

function makeAioPlatformCommand(name, label, description) {
  return {
    name,
    category: "Downloads",
    description,
    run: async ctx => runAioDownload(ctx, requirePlatformUrl(ctx, name, label), label)
  };
}

export default [
  {
    name: "aio",
    category: "Downloads",
    description: "Download supported media through the Xrina all-in-one downloader.",
    run: async ctx => runAioDownload(ctx, requireUrl(ctx, "media"))
  },
  makeAioPlatformCommand("fb", "Facebook", "Download Facebook videos through the AIO downloader."),
  makeAioPlatformCommand("twitter", "Twitter / X", "Download Twitter/X videos through the AIO downloader."),
  makeAioPlatformCommand("instagram", "Instagram", "Download Instagram videos through the AIO downloader."),
  makeAioPlatformCommand("ytmp4", "YouTube MP4", "Download YouTube videos through the AIO downloader."),
  {
    ...makeAioPlatformCommand("tiktok", "TikTok", "Download TikTok videos through the AIO downloader."),
    aliases: ["ttdl"]
  },
  {
    name: "play2",
    category: "Downloads",
    description: "Search a song and send the audio file (version 2).",
    run: async ctx => {
      const query = String(ctx.args || "").trim();
      if (!query) throw new Error("Usage: " + ctx.config.prefix + "play2 song title or artist");
      if (query.length > 180) throw new Error("Keep the song query under 180 characters.");

      await ctx.reply(unicodeBox("🎵 sᴏɴɢ sᴇᴀʀᴄʜ 2",
        "🔎 Search: " + query + "\n\nFinding the audio and preparing the download...", { footer: false }), false);
      const payload = await requestXrinaJson("download/play", { q: query });
      ensureApiSuccess(payload);
      const data = responseData(payload);
      const candidate = (Array.isArray(data.media) && data.media[0]) || data.music;
      const url = safeMediaUrl(candidate, "audio");
      if (!url) throw new Error("The service did not return a valid audio file for that search.");

      const author = data.author && (data.author.nickname || data.author.unique_id);
      await deliverAudio(ctx, url, data.title || query, [
        author ? "👤 Artist: " + shortText(author, 100) : "",
        data.duration ? "⏱ Duration: " + shortText(data.duration, 40) : "",
        Number.isFinite(Number(data.views)) ? "👁 Views: " + Number(data.views).toLocaleString("en-US") : ""
      ]);
    }
  },
  {
    name: "tiktok2",
    category: "Downloads",
    description: "Download a TikTok video using the Xrina downloader (version 2).",
    run: async ctx => {
      const url = requireTiktokUrl(ctx);
      await ctx.reply(unicodeBox("🎬 ᴛɪᴋᴛᴏᴋ ᴅᴏᴡɴʟᴏᴀᴅ 2",
        "🔗 Source: " + url + "\n\nFetching the video and preparing the file...", { footer: false }), false);

      const payload = await requestXrinaJson("download/tiktok", { url });
      ensureApiSuccess(payload);
      const data = responseData(payload);
      const media = Array.isArray(data.media) ? data.media : [];
      const videoUrl = safeMediaUrl(media.find(value => safeMediaUrl(value, "video")), "video");
      if (!videoUrl) throw new Error("The service did not return a valid TikTok video URL.");

      const author = data.author && (data.author.nickname || data.author.unique_id);
      await deliverVideo(ctx, videoUrl, data.title || "TikTok video", [
        author ? "👤 Creator: " + shortText(author, 100) : "",
        data.duration ? "⏱ Duration: " + shortText(data.duration, 40) + " seconds" : "",
        Number.isFinite(Number(data.views)) ? "👁 Views: " + Number(data.views).toLocaleString("en-US") : ""
      ]);
    }
  }
];
