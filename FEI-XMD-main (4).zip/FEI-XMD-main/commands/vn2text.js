import { downloadMediaMessage } from "@whiskeysockets/baileys";
import {
  getContextInfo, getQuotedKey, getQuotedMessage, unwrapMessage
} from "../lib/utils.js";
import {
  extractApiText, requestApiJson, requestExternalJson
} from "../lib/api-client.js";
import { askAI, hasWhisperApiKey, transcribeAudioWithWhisper } from "../lib/group-ai.js";

const MENU_AI_FALLBACKS = [
  {
    name: "Gemini (menu AI)",
    ask: async prompt => extractApiText(await requestApiJson("gemini", { q: prompt }, 35000))
  },
  {
    name: "GPT (menu AI)",
    ask: async prompt => extractApiText(await requestApiJson("gptlogic", {
      q: prompt,
      prompt: "Return one concise, accurate sentence only."
    }, 35000))
  },
  {
    name: "DeepSeek (menu AI)",
    ask: async prompt => extractApiText(await requestExternalJson(
      "https://api.omegatech.app/api/ai/Deepseek",
      { message: prompt, model: "v32" },
      35000
    ))
  }
];

async function askMenuAIWithFallback(prompt, options = {}) {
  const primary = options.primary || askAI;
  const fallbacks = Array.isArray(options.fallbacks) ? options.fallbacks : MENU_AI_FALLBACKS;
  const providers = [{ name: "configured FEI XMD AI", ask: value => primary(value, { maxTokens: 100 }) }, ...fallbacks];
  const errors = [];

  for (const provider of providers) {
    try {
      const answer = String(await (typeof provider === "function" ? provider(prompt) : provider.ask(prompt)) || "").trim();
      if (answer) return answer.replace(/\s+/g, " ").slice(0, 500);
      errors.push((provider.name || "AI provider") + " returned an empty answer.");
    } catch (error) {
      const label = provider.name || "AI provider";
      errors.push(label + ": " + String(error && error.message || "request failed").slice(0, 120));
      console.warn(".vn2text summary provider failed (" + label + "):", error && error.message || error);
    }
  }

  throw new Error("All configured AI summary providers failed. " + errors.slice(0, 2).join(" | "));
}

function hasFallbackTranscriptionConfig() {
  return Boolean(String(process.env.FEI_WHISPER_FALLBACK_URL || "").trim());
}

async function transcribeWithFallback(buffer, options = {}) {
  try {
    return await transcribeAudioWithWhisper(buffer, options);
  } catch (primaryError) {
    const endpoint = String(process.env.FEI_WHISPER_FALLBACK_URL || "").trim();
    if (!endpoint) throw primaryError;

    let url;
    try {
      url = new URL(endpoint);
    } catch {
      throw new Error("FEI_WHISPER_FALLBACK_URL is not a valid URL.");
    }
    const isLocal = ["localhost", "127.0.0.1", "::1"].includes(url.hostname);
    if ((url.protocol !== "https:" && !(isLocal && url.protocol === "http:")) || url.username || url.password) {
      throw new Error("The fallback transcription URL must use HTTPS (HTTP is allowed only for localhost).");
    }

    const mimetype = String(options.mimetype || "audio/ogg; codecs=opus").split(";")[0].trim().toLowerCase();
    const extensionByType = {
      "audio/ogg": "ogg", "audio/mpeg": "mp3", "audio/mp3": "mp3",
      "audio/mp4": "m4a", "audio/x-m4a": "m4a", "audio/wav": "wav",
      "audio/x-wav": "wav", "audio/webm": "webm", "video/mp4": "mp4"
    };
    const form = new FormData();
    form.append("file", new Blob([buffer], { type: mimetype || "audio/ogg" }),
      "voice-note." + (extensionByType[mimetype] || "ogg"));
    form.append("model", String(process.env.FEI_WHISPER_FALLBACK_MODEL || "whisper-1"));

    const headers = { accept: "application/json" };
    const apiKey = String(process.env.FEI_WHISPER_FALLBACK_KEY || "").trim();
    if (apiKey) headers.authorization = "Bearer " + apiKey;

    let response;
    try {
      response = await fetch(url, {
        method: "POST",
        headers,
        body: form,
        signal: AbortSignal.timeout(Math.max(15000, Number(options.timeoutMs) || 90000))
      });
    } catch (error) {
      throw new Error("The fallback transcription service could not be reached: " +
        String(error && error.message || error).slice(0, 150));
    }

    let payload;
    try {
      payload = await response.json();
    } catch {
      throw new Error("The fallback transcription service returned an unreadable response.");
    }
    if (!response.ok || payload?.error || payload?.success === false || payload?.status === false) {
      const detail = payload?.error?.message || payload?.error || payload?.message || "The request failed.";
      throw new Error("Fallback transcription failed: " + String(detail).slice(0, 180));
    }
    const transcript = String(payload?.text || payload?.transcript || payload?.data?.text || "").trim();
    if (!transcript) throw new Error("The fallback transcription service returned no transcript.");
    console.warn(".vn2text used the configured fallback transcription service after Whisper failed.");
    return transcript;
  }
}

async function sendWithoutNewsletter(ctx, text, quoted = false) {
  if (typeof ctx.send === "function") return ctx.send({ text: String(text || "") }, quoted, false);
  return ctx.reply(String(text || ""), quoted);
}

function splitTranscript(text, maximum = 3200) {
  let remaining = String(text || "").trim();
  const chunks = [];
  while (remaining.length > maximum) {
    let splitAt = remaining.lastIndexOf("\n", maximum);
    if (splitAt < maximum * 0.55) splitAt = remaining.lastIndexOf(" ", maximum);
    if (splitAt < maximum * 0.55) splitAt = maximum;
    if (splitAt > 0 && /[\uD800-\uDBFF]/.test(remaining.charAt(splitAt - 1))) splitAt -= 1;
    chunks.push(remaining.slice(0, splitAt).trim());
    remaining = remaining.slice(splitAt).trim();
  }
  if (remaining) chunks.push(remaining);
  return chunks.length ? chunks : [""];
}

function voiceNoteFromReply(ctx) {
  const info = getContextInfo(ctx.msg && ctx.msg.message);
  const message = info && info.quotedMessage || getQuotedMessage(ctx.msg);
  if (!info || !info.stanzaId || !message) return null;
  const body = unwrapMessage(message);
  const audio = body.audioMessage;
  if (!audio) return null;
  const mimetype = String(audio.mimetype || "audio/ogg; codecs=opus");
  if (!audio.ptt && !/audio\/ogg/i.test(mimetype)) return null;
  const key = getQuotedKey(ctx.msg, ctx.sock) || {
    remoteJid: ctx.jid,
    id: info.stanzaId,
    fromMe: false
  };
  if (info.participant) key.participant = info.participant;
  return { message, audio, mimetype, wrapped: { key, message, messageTimestamp: ctx.msg.messageTimestamp } };
}

function guardedRun(run) {
  return async ctx => {
    try {
      await run(ctx);
    } catch (error) {
      console.warn(".vn2text failed:", error && (error.stack || error.message) || error);
      try {
        await sendWithoutNewsletter(ctx, "❌ I couldn't transcribe that voice note.\n" +
          String(error && error.message || "Please try again later.").slice(0, 260), true);
      } catch {}
    }
  };
}

export function createVn2TextCommand(options = {}) {
  const downloadMedia = options.downloadMedia || (async (ctx, quoted) =>
    downloadMediaMessage(quoted.wrapped, "buffer", {}, {
      reuploadRequest: ctx.sock.updateMediaMessage
    })
  );
  const transcribe = options.transcribe || transcribeWithFallback;
  const primarySummary = options.askAI || askAI;
  const summaryFallbacks = options.fallbackSummarizers || MENU_AI_FALLBACKS;
  const summarize = options.askSummary || (prompt =>
    askMenuAIWithFallback(prompt, { primary: primarySummary, fallbacks: summaryFallbacks })
  );
  const isConfigured = options.isConfigured ||
    (() => hasWhisperApiKey() || hasFallbackTranscriptionConfig());

  return {
    name: "vn2text",
    category: "Media & Tools",
    description: "Transcribe a replied-to WhatsApp voice note and provide a one-line AI summary with fallback services.",
    noReaction: true,
    run: guardedRun(async ctx => {
      const quoted = voiceNoteFromReply(ctx);
      if (!quoted) {
        await sendWithoutNewsletter(ctx, "🎙️ Reply directly to a voice note with " + ctx.config.prefix + "vn2text to transcribe it.", true);
        return;
      }
      if (!isConfigured()) {
        await sendWithoutNewsletter(ctx,
          "🔑 Voice transcription needs OPENAI_API_KEY, or a configured FEI_WHISPER_FALLBACK_URL (an OpenAI-compatible transcription endpoint).",
          true);
        return;
      }

      const audioBuffer = await downloadMedia(ctx, quoted);
      if (!audioBuffer || !audioBuffer.length) throw new Error("The voice note could not be downloaded.");
      if (audioBuffer.length > 24 * 1024 * 1024) throw new Error("This voice note is larger than the 24 MB transcription limit.");

      const transcript = String(await transcribe(audioBuffer, {
        mimetype: quoted.mimetype, timeoutMs: 90000
      }) || "").trim();
      if (!transcript) throw new Error("The transcription service returned no text.");

      let summary = "Summary unavailable; the transcript was recovered successfully.";
      try {
        const prompt = "Summarize the following voice-note transcript in one clear sentence. Do not add facts or commentary. Return only that sentence:\n\n" +
          transcript.slice(0, 3000);
        const summaryResult = String(await summarize(prompt) || "").trim();
        if (summaryResult) summary = summaryResult.replace(/\s+/g, " ").slice(0, 500);
      } catch (error) {
        console.warn(".vn2text summary generation failed after trying fallback AIs:", error && error.message || error);
      }

      const chunks = splitTranscript(transcript);
      for (let index = 0; index < chunks.length; index += 1) {
        const header = chunks.length > 1
          ? "📝 *VOICE NOTE TRANSCRIPT* (" + (index + 1) + "/" + chunks.length + ")\n\n"
          : "📝 *VOICE NOTE TRANSCRIPT*\n\n";
        await sendWithoutNewsletter(ctx, header + chunks[index]);
      }
      await sendWithoutNewsletter(ctx, "📌 *Summary:* " + summary);
      // Audio is processed in memory; no temporary files are created.
    })
  };
}

export default createVn2TextCommand();
