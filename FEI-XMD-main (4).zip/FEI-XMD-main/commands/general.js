import { formatDuration, getMessageAgeMs, getSelfJid, numberFromJid } from "../lib/utils.js";

export default [
  {
    name: "menu",
    aliases: ["help"],
    category: "General",
    description: "Show the configured image and the full Unicode menu in one message.",
    run: async ctx => {
      const caption = ctx.buildMenu();
      if (ctx.config.imageUrl) {
        try {
          // The image and full Unicode menu are one message, not separate messages.
          await ctx.send({ image: { url: ctx.config.imageUrl }, caption }, false);
          return;
        } catch (error) {
          console.warn("The menu image could not be sent. Falling back to the complete text menu.");
        }
      }
      await ctx.reply(caption, false);
    }
  },
  {
    name: "ping",
    category: "General",
    description: "Check bot responsiveness.",
    run: async ctx => {
      const age = getMessageAgeMs(ctx.msg);
      await ctx.reply(age === null
        ? "🏓 Pong!\n⏱️ Response time: unavailable"
        : "🏓 Pong!\n⏱️ Message age: " + age + " ms\n_(Estimated from the message timestamp.)_");
    }
  },
  {
    name: "alive",
    category: "General",
    description: "Show bot status and uptime.",
    run: async ctx => {
      await ctx.reply("✅ " + ctx.config.name + " is " + (ctx.connectionOpen ? "online." : "connecting.") +
        "\n🔐 Mode: " + ctx.mode.toUpperCase() +
        "\n⏱️ Uptime: " + formatDuration(process.uptime()) +
        "\n⚡ Powered by " + ctx.config.ownerName);
    }
  },
  {
    name: "owner",
    category: "General",
    description: "Show owner details.",
    run: async ctx => {
      const self = getSelfJid(ctx.sock);
      const number = ctx.config.ownerNumber || numberFromJid(self);
      await ctx.reply("👑 Owner: " + ctx.config.ownerName + (number ? "\n📱 Owner number: +" + number : ""));
    }
  },
  {
    name: "support",
    category: "General",
    description: "Show support guidance.",
    run: async ctx => {
      await ctx.reply("🛟 " + ctx.config.name + " Support\nFor setup help, contact the bot owner: " + ctx.config.ownerName + ".");
    }
  },
  {
    name: "channel",
    category: "General",
    description: "Show the official channel attribution.",
    run: async ctx => {
      const caption = "📢 Official " + ctx.config.channel.name + " WhatsApp Channel\n" +
        "Tap View channel on this message to open and follow the channel.";
      if (ctx.config.imageUrl) {
        try {
          await ctx.send({ image: { url: ctx.config.imageUrl }, caption }, true);
          return;
        } catch (error) {
          console.warn("Channel image could not be sent; using text fallback.");
        }
      }
      await ctx.reply(caption);
    }
  },
  {
    name: "runtime",
    category: "Owner",
    ownerOnly: true,
    description: "Show bot uptime.",
    run: async ctx => {
      await ctx.reply("⏱️ Bot uptime: " + formatDuration(process.uptime()));
    }
  },
  {
    name: "time",
    category: "General",
    description: "Show server time.",
    run: async ctx => { await ctx.reply("🕒 Server time: " + new Date().toLocaleTimeString()); }
  },
  {
    name: "date",
    category: "General",
    description: "Show server date.",
    run: async ctx => { await ctx.reply("📅 Server date: " + new Date().toLocaleDateString()); }
  },
  {
    name: "version",
    category: "General",
    description: "Show bot version.",
    run: async ctx => {
      await ctx.reply("🤖 " + ctx.config.name + " v" + ctx.config.version +
        "\n🟢 Status: " + (ctx.connectionOpen ? "Online" : "Connecting") +
        "\n🔐 Mode: " + ctx.mode.toUpperCase());
    }
  },
  {
    name: "jid",
    aliases: ["id"],
    category: "General",
    description: "Show chat and sender IDs.",
    run: async ctx => {
      await ctx.reply("💬 Chat ID: " + ctx.jid + "\n👤 Sender ID: " + (ctx.senderJid || "Unavailable"));
    }
  },
  {
    name: "whoami",
    category: "General",
    description: "Show your sender information.",
    run: async ctx => {
      await ctx.reply("👤 Name: " + (ctx.msg.pushName || "Unknown") +
        "\n🆔 Your ID: " + (ctx.senderJid || "Unavailable") +
        "\n👑 Owner: " + (ctx.owner ? "Yes" : "No"));
    }
  }
];
