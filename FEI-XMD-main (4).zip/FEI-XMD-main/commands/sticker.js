import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {
  getContextInfo,
  getQuotedKey,
  getQuotedMessage,
  getSelfJids,
  unwrapMessage
} from "../lib/utils.js";

const execFileAsync = promisify(execFile);
const MAX_INPUT_BYTES = 16 * 1024 * 1024;
const MAX_STICKER_BYTES = 1024 * 1024;

function containsViewOnce(message) {
  let current = message;
  for (let i = 0; i < 8 && current; i++) {
    if (current.viewOnceMessage || current.viewOnceMessageV2 || current.viewOnceMessageV2Extension) {
      return true;
    }
    if (current.ephemeralMessage && current.ephemeralMessage.message) {
      current = current.ephemeralMessage.message;
    } else if (current.documentWithCaptionMessage && current.documentWithCaptionMessage.message) {
      current = current.documentWithCaptionMessage.message;
    } else {
      break;
    }
  }
  return false;
}

function describeMedia(message) {
  if (containsViewOnce(message)) return { viewOnce: true };
  const body = unwrapMessage(message);

  if (body.imageMessage) {
    return { kind: "image", media: body.imageMessage };
  }
  if (body.videoMessage) {
    return { kind: "video", media: body.videoMessage };
  }

  // Images or videos sent as ordinary documents are accepted when their
  // declared MIME type identifies a supported media format.
  if (body.documentMessage) {
    const media = body.documentMessage;
    const mimetype = String(media.mimetype || "").toLowerCase();
    if (mimetype.startsWith("image/")) return { kind: "image", media };
    if (mimetype.startsWith("video/")) return { kind: "video", media };
  }
  return null;
}

function declaredSize(media) {
  let value = media && media.fileLength;
  if (value && typeof value.toNumber === "function") value = value.toNumber();
  if (typeof value === "bigint") value = Number(value);
  const size = Number(value);
  return Number.isFinite(size) && size > 0 ? size : 0;
}

function selectMediaTarget(ctx) {
  const current = describeMedia(ctx.msg && ctx.msg.message);
  if (current && current.viewOnce) return { viewOnce: true };
  if (current) return { wrapped: ctx.msg, descriptor: current };

  const info = getContextInfo(ctx.msg && ctx.msg.message);
  const quotedMessage = (info && info.quotedMessage) || getQuotedMessage(ctx.msg);
  if (!info || !info.stanzaId || !quotedMessage) return null;

  const quoted = describeMedia(quotedMessage);
  if (quoted && quoted.viewOnce) return { viewOnce: true };
  if (!quoted) return null;

  const key = getQuotedKey(ctx.msg, ctx.sock) || {
    remoteJid: ctx.jid,
    id: info.stanzaId,
    fromMe: Boolean(info.participant && getSelfJids(ctx.sock).includes(info.participant))
  };
  return {
    wrapped: { key, message: quotedMessage, messageTimestamp: ctx.msg.messageTimestamp },
    descriptor: quoted
  };
}

function ffmpegFilter(animated, compact) {
  const parts = [];
  if (animated) parts.push("fps=" + (compact ? "8" : "12"));
  parts.push(
    "scale=512:512:force_original_aspect_ratio=decrease:force_divisible_by=2",
    "pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000",
    "format=" + (animated ? "yuva420p" : "rgba")
  );
  return parts.join(",");
}

async function encodeSticker(inputPath, outputPath, animated, compact) {
  const args = ["-hide_banner", "-loglevel", "error", "-y", "-i", inputPath];
  if (animated) {
    args.push(
      "-t", compact ? "2" : "3",
      "-vf", ffmpegFilter(true, compact),
      "-an",
      "-c:v", "libwebp_anim",
      "-loop", "0",
      "-quality", compact ? "32" : "58",
      "-compression_level", "6",
      "-fps_mode", "passthrough",
      outputPath
    );
  } else {
    args.push(
      "-frames:v", "1",
      "-vf", ffmpegFilter(false, compact),
      "-an",
      "-c:v", "libwebp",
      "-quality", compact ? "52" : "82",
      "-compression_level", "6",
      outputPath
    );
  }

  await execFileAsync("ffmpeg", args, {
    windowsHide: true,
    timeout: 60000,
    maxBuffer: 1024 * 1024
  });
  const stat = await fs.stat(outputPath);
  if (!stat.size) throw new Error("FFmpeg produced an empty sticker.");
  return stat.size;
}

export default {
  name: "sticker",
  category: "Media & Tools",
  description: "Convert an image or a short video into a WhatsApp sticker.",
  run: async ctx => {
    const target = selectMediaTarget(ctx);
    if (target && target.viewOnce) {
      await ctx.reply("🔒 View-once media cannot be converted into a sticker. Send a normal image or video instead.");
      return;
    }
    if (!target) {
      await ctx.reply(
        "🖼️ To create a sticker, send an image or video with " + ctx.config.prefix +
        "sticker as its caption, or reply to an image/video with " + ctx.config.prefix + "sticker."
      );
      return;
    }

    const media = target.descriptor.media;
    const knownSize = declaredSize(media);
    if (knownSize > MAX_INPUT_BYTES) {
      await ctx.reply("📦 This file is too large. Send an image or video under 16 MB.");
      return;
    }

    let downloaded;
    try {
      downloaded = await downloadMediaMessage(target.wrapped, "buffer", {}, {
        reuploadRequest: ctx.sock.updateMediaMessage
      });
    } catch (error) {
      console.warn("Sticker media download failed:", error && error.message || error);
      await ctx.reply("❌ I couldn't download that media. Try sending it again or reply to the original image/video.");
      return;
    }

    const inputBuffer = Buffer.isBuffer(downloaded) ? downloaded : Buffer.from(downloaded || []);
    if (!inputBuffer.length) {
      await ctx.reply("❌ The media download was empty. Please try again.");
      return;
    }
    if (inputBuffer.length > MAX_INPUT_BYTES) {
      await ctx.reply("📦 This file is too large. Send an image or video under 16 MB.");
      return;
    }

    const animated = target.descriptor.kind === "video" ||
      String(media.mimetype || "").toLowerCase().includes("gif");
    const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "fei-xmd-sticker-"));
    const inputPath = path.join(tempDir, "source.media");
    const outputPath = path.join(tempDir, "sticker.webp");
    const compactPath = path.join(tempDir, "sticker-compact.webp");

    try {
      await fs.writeFile(inputPath, inputBuffer);
      let outputSize;
      let finalPath = outputPath;

      try {
        outputSize = await encodeSticker(inputPath, outputPath, animated, false);
      } catch (error) {
        if (error && error.code === "ENOENT") {
          throw new Error("FFmpeg is not installed on this runtime. Install FFmpeg and restart FEI XMD.");
        }
        throw new Error("FFmpeg could not convert this file. Use a standard image or a supported video/GIF.");
      }

      if (outputSize > MAX_STICKER_BYTES) {
        try {
          const compactSize = await encodeSticker(inputPath, compactPath, animated, true);
          if (compactSize < outputSize) {
            outputSize = compactSize;
            finalPath = compactPath;
          }
        } catch (error) {
          console.warn("Sticker compact re-encoding failed:", error && error.message || error);
        }
      }

      if (outputSize > MAX_STICKER_BYTES) {
        throw new Error(animated
          ? "This video is still too large after compression. Try a shorter video (about 2 seconds) or a smaller file."
          : "This image is still too large after compression. Try a smaller image.");
      }

      const stickerBuffer = await fs.readFile(finalPath);
      await ctx.send({ sticker: stickerBuffer, mimetype: "image/webp" }, true);
    } finally {
      await fs.rm(tempDir, { recursive: true, force: true }).catch(() => {});
    }
  }
};
