// commands/custom/fakemsg.js
import { getQuotedKey } from "../../lib/utils.js";
import { markTransientAlert } from "../../lib/baileys-events.js";

export default {
  name: "fakemsg",
  aliases: ["fake", "editmsg"],
  category: "Chat & Privacy",
  description: "Replace the text of a replied-to message, even if FEI XMD did not send it.",

  run: async ctx => {
    const text = String(ctx.args || "").trim();
    const key = getQuotedKey(ctx.msg, ctx.sock);

    if (!key) {
      await ctx.reply("⚠️ Reply to the message you want to replace.");
      return;
    }
    if (!text) {
      await ctx.reply("⚠️ Provide new text.\n\nExample: " + ctx.config.prefix + "fakemsg This is the fake message");
      return;
    }
    if (text.length > 4000) {
      await ctx.reply("Keep the replacement text below 4,000 characters.");
      return;
    }

    markTransientAlert(ctx.jid, key.id);

    // Same edit twice, differing only in the key's fromMe. The version that
    // visibly worked targeted the bot's OWN message, so cover both conventions.
    for (const fromMe of [false, true]) {
      await ctx.sock.relayMessage(
        ctx.jid,
        {
          protocolMessage: {
            key: { ...key, fromMe },
            type: 14, // proto.Message.ProtocolMessage.Type.MESSAGE_EDIT
            editedMessage: {
              extendedTextMessage: { text }
            }
          }
        },
        {} // no additionalAttributes — the working version had none
      );
    }

    await ctx.reply("✅ Message replaced successfully.");
  }
};