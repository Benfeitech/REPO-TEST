export default {
  name: "hello",
  aliases: [],
  category: "Fun",
  description: "Example custom command. Edit or replace this file.",
  run: async ({ reply, config, args }) => {
    await reply("👋 Hello from " + config.name + "!" + (args ? "\nYou wrote: " + args : ""));
  }
};
