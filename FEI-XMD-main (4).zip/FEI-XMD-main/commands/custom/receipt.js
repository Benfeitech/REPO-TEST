// commands/custom/receipt.js
import {
  resolveBankCode,
  verifyAccountName,
  generateReceiptImage,
} from '../../lib/receipt-generator.js';

/* ---------- Channel newsletter identity ---------- */
const CHANNEL_JID  = '120363413231189335@newsletter';
const CHANNEL_NAME = 'BENFEI TECH';

const channelContext = {
  forwardingScore: 999,
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: CHANNEL_JID,
    newsletterName: CHANNEL_NAME,
    serverMessageId: 0,
  },
};

/* ---------- Amount formatter ---------- */
function formatAmount(raw) {
  if (!raw) return '₦50,000,000.00';

  const trimmed = String(raw).trim();

  // Only reformat if the input is clearly numeric
  // (optionally prefixed with ₦ or N, with commas / decimal point allowed)
  const match = trimmed.match(/^[₦N]?\s*([\d,]+(?:\.\d+)?)$/i);
  if (!match) return trimmed; // e.g. "1 million" → returned as-is

  const cleaned = match[1].replace(/,/g, '');
  const num = parseFloat(cleaned);
  if (isNaN(num)) return trimmed;

  return '₦' + num.toLocaleString('en-NG', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export default {
  name: 'receipt',
  aliases: ['rcpt'],
  category: 'Media & Tools',
  description:
    'Generate a transaction receipt. Usage: .receipt RecipientBank | RecipientAccount | SenderName | [SenderBank] | SenderAccount | [Amount]',

  run: async (ctx) => {
    const prefix = ctx.config?.prefix || '.';
    const raw = String(ctx.args || '').trim();

    if (!raw) {
      return ctx.reply(
        `*Usage:*\n` +
          `${prefix}receipt RecipientBank | RecipientAccount | SenderName | [SenderBank] | SenderAccount | [Amount]\n\n` +
          `*Example:*\n` +
          `${prefix}receipt Opay | 9060715145 | Benfei Tech | Opay | 7083279647 | 1,000,000\n\n` +
          `*Defaults:* SenderBank = Opay, Amount = ₦50,000,000.00`
      );
    }

    const parts = raw.split('|').map(s => s.trim());
    if (parts.length < 4) {
      return ctx.reply(
        `Invalid format. Use:\n` +
          `${prefix}receipt RecipientBank | RecipientAccount | SenderName | [SenderBank] | SenderAccount | [Amount]`
      );
    }

    const recipientBank = parts[0];
    const recipientAcc  = parts[1];
    const senderName    = parts[2];

    if (!recipientBank) {
      return ctx.reply('Recipient bank is required.');
    }
    if (!/^\d{10}$/.test(recipientAcc)) {
      return ctx.reply('Recipient account must be exactly 10 digits.');
    }
    if (!senderName) {
      return ctx.reply('Sender name is required.');
    }

    /* ---------- Classify remaining parts ---------- */
    //  - pure 10-digit number  → account
    //  - contains any letter   → bank name
    //  - otherwise (digits/₦/,) → amount
    const rest     = parts.slice(3).filter(Boolean);
    const accounts = [];
    const banks    = [];
    const amounts  = [];

    for (const part of rest) {
      if (/^\d{10}$/.test(part)) {
        accounts.push(part);
      } else if (/[a-zA-Z]/.test(part)) {
        banks.push(part);
      } else if (/\d/.test(part)) {
        amounts.push(part);
      }
    }

    const senderAcc  = accounts[0] || '';
    const senderBank = banks[0] || 'Opay';          // default bank
    const amount     = formatAmount(amounts[0]);    // default amount handled inside

    if (!senderAcc) {
      return ctx.reply('Sender account number (10 digits) is required.');
    }

    /* ---------- 1. Resolve recipient bank code ---------- */
    const bankCode = await resolveBankCode(recipientBank);
    if (!bankCode) {
      return ctx.reply(
        `Unknown recipient bank: "${recipientBank}". Try Opay, PalmPay, Access, GTBank, Zenith, UBA, etc.`
      );
    }

    /* ---------- 2. Verify recipient account ---------- */
    await ctx.react('⏳');

    const verification = await verifyAccountName(recipientAcc, bankCode);
    if (!verification.ok) {
      await ctx.react('❌');
      return ctx.reply(`Verification failed: ${verification.error}`);
    }

    const recipientName = verification.accountName;

    /* ---------- 3. Generate the receipt image ---------- */
    let imageBuffer;
    try {
      imageBuffer = await generateReceiptImage({
        amount,
        recipientName,
        recipientBank,
        recipientAccount: recipientAcc,
        senderName,
        senderBank,
        senderAccount: senderAcc,
      });
    } catch (err) {
      await ctx.react('❌');
      return ctx.reply(`Could not generate the receipt image: ${err.message}`);
    }

    /* ---------- 4. Send with channel-newsletter context ---------- */
    const caption =
      `✅ *Receipt Successfully Generated.*\n\n` +
      `Name: *${recipientName}*\n\n` +
      `⚡ *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ʙᴇɴꜰᴇɪ ᴛᴇᴄʜ*`;

    await ctx.send({
      image: imageBuffer,
      caption,
      mimetype: 'image/png',
      contextInfo: channelContext,
    });

    await ctx.react('✅');
  },
};