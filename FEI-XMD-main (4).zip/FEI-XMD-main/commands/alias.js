import { HIDDEN_VIEW_ONCE_SHORTCUTS } from "../lib/view-once-shortcuts.js";

function getRegisteredHiddenAliases(commands) {
  return (Array.isArray(commands) ? commands : [])
    .map(command => {
      const hidden = new Set(Array.isArray(command.hiddenAliases) ? command.hiddenAliases : []);
      const aliases = (command.aliases || []).filter(alias => hidden.has(alias));
      return { command, aliases };
    })
    .filter(entry => entry.aliases.length);
}

function describeRegisteredAlias(entry, prefix) {
  const { command, aliases } = entry;

  if (command.name === "tagall" && aliases.includes("👋")) {
    return [
      "👋 / " + prefix + "👋 (type in a group or react to a group message) → " + prefix + "hidetag",
      "   Mentions all group members without displaying their @names in the message text. Group-admin/owner permissions still apply."
    ];
  }

  if (command.name === "save") {
    return [
      aliases.join(" / ") + " → " + prefix + "save",
      "   Reply to a status or supported media with either emoji to save it to the connected WhatsApp account's own DM."
    ];
  }

  return [
    aliases.join(" / ") + " → " + prefix + command.name,
    "   " + String(command.description || "No description available.")
  ];
}

export default {
  name: "alias",
  category: "General",
  description: "List hidden command aliases and emoji shortcuts that are intentionally omitted from the main menu.",
  run: async ctx => {
    const prefix = String(ctx.config && ctx.config.prefix || ".");
    const lines = [
      "╭━━〔 🧩 ʜɪᴅᴅᴇɴ ᴄᴏᴍᴍᴀɴᴅs & sʜᴏʀᴛᴄᴜᴛs 〕━━┈⊷",
      "┃",
      "┃ ✧ These aliases are intentionally left out of the main menu.",
      "┃",
      "┃ ✧ HIDDEN COMMAND ALIASES"
    ];

    const registered = getRegisteredHiddenAliases(ctx.commands);
    if (registered.length) {
      for (const entry of registered) lines.push(...describeRegisteredAlias(entry, prefix));
    } else {
      lines.push("┃ ✧ No registered hidden aliases were found.");
    }

    lines.push(
      "┃",
      "┃ ✧ VIEW-ONCE EMOJI SHORTCUTS",
      HIDDEN_VIEW_ONCE_SHORTCUTS.vv.join(" / ") + " → " + prefix + "vv",
      "   Reply to view-once image, video, voice-note or document media with one of these emojis to recover it in the current chat.",
      HIDDEN_VIEW_ONCE_SHORTCUTS.vv2.join(" / ") + " → " + prefix + "vv2",
      "   Reply to view-once media with one of these emojis to send the recovered media to your DM with the bot.",
      "┃",
      "┃ ✧ The view-once emojis work as reply text, not as WhatsApp reactions.",
      "╰━━━━━━━━━━━━┈⊷"
    );

    await ctx.reply(lines.join("\n"));
  }
};
