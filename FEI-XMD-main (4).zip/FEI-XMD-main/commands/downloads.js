import { requestApiJson, requestExternalJson, unicodeBox, safeFileName, validateHttpsUrl } from "../lib/api-client.js";

const YOUTUBE_HOSTS = ["youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be"];
const TIKTOK_HOSTS = ["tiktok.com", "www.tiktok.com", "m.tiktok.com", "vm.tiktok.com", "vt.tiktok.com"];
const SPOTIFY_HOSTS = ["spotify.com", "www.spotify.com", "open.spotify.com"];

function getUrlArg(ctx) {
  const url = String(ctx.args || "").trim().split(/\s+/)[0];
  if (!url) throw new Error("Add a media URL after the command.");
  return url;
}

function mediaDetails(title, duration, quality, kind = "ᴅᴏᴡɴʟᴏᴀᴅ ʀᴇᴀᴅʏ") {
  return unicodeBox(kind, [
    "✅ *" + String(title || "Download ready").replace(/[\\*_~`]/g, "") + "*",
    duration ? "⏱️ _Duration:_ " + duration : "",
    quality ? "🎞️ _Quality:_ *" + quality + "*" : ""
  ].filter(Boolean).join("\n"), { footer: true });
}

async function announceDownload(ctx, detail = "Submitting your download request to the media service") {
  await ctx.reply(unicodeBox("📥 ᴅᴏᴡɴʟᴏᴀᴅ ɪɴ ᴘʀᴏɢʀᴇss",
    detail + "\n\nPlease wait while the service processes the request and prepares the file.", { footer: false }));
}

async function sendAudio(ctx, url, title, duration, quality) {
  // First display the branded result, then deliver the actual audio file.
  await ctx.reply(mediaDetails(title, duration, quality, "🎵 ᴀᴜᴅɪᴏ ʀᴇᴀᴅʏ"), false);
  const fileName = safeFileName(title, "FEI-XMD-audio") + ".mp3";

  try {
    await ctx.send({ audio: { url }, mimetype: "audio/mpeg", fileName, ptt: false }, false);
  } catch (error) {
    await ctx.reply(unicodeBox("🔗 ᴅɪʀᴇᴄᴛ ᴅᴏᴡɴʟᴏᴀᴅ",
      String(title || "Audio download") + "\n" + url, { footer: true }), false);
  }
}

async function sendVideo(ctx, url, title, duration, quality) {
  const caption = mediaDetails(title, duration, quality, "🎬 ᴠɪᴅᴇᴏ ʀᴇᴀᴅʏ");
  try {
    await ctx.send({ video: { url }, mimetype: "video/mp4", caption }, false);
  } catch (error) {
    await ctx.reply(unicodeBox("🎬 ᴠɪᴅᴇᴏ ʀᴇᴀᴅʏ",
      [
        "✅ " + String(title || "Video ready"),
        duration ? "⏱️ Duration: " + duration : "",
        quality ? "🎞️ Quality: " + quality : "",
        "",
        "🔗 Direct download:",
        url
      ].filter(Boolean).join("\n"), { footer: true }), false);
  }
}

export default [
  {
    name: "song",
    aliases: ["play", "ytmp3"],
    category: "Downloads",
    description: "Download audio from a YouTube video.",
    run: async ctx => {
      const url = validateHttpsUrl(getUrlArg(ctx), YOUTUBE_HOSTS, "YouTube");
      await announceDownload(ctx, "Submitting the YouTube URL to the audio extraction service...");
      const payload = await requestApiJson("ytdl", { format: "mp3", url });
      const result = payload && payload.result;
      const downloadUrl = result && result.download;
      if (typeof downloadUrl !== "string" || !downloadUrl.startsWith("https://")) {
        throw new Error("No audio download was returned for that video.");
      }
      await sendAudio(ctx, downloadUrl, result.title || "YouTube audio",
        result.duration, result.quality || result.format || "MP3");
    }
  },
  {
    name: "video",
    category: "Downloads",
    description: "Download a YouTube video.",
    run: async ctx => {
      const url = validateHttpsUrl(getUrlArg(ctx), YOUTUBE_HOSTS, "YouTube");
      await announceDownload(ctx, "Requesting the video metadata and available download quality...");
      const payload = await requestApiJson("ytv", { url });
      const result = payload && (payload.results || payload.result);
      const downloadUrl = result && (result.downloadUrl || result.download || result.url);
      if (typeof downloadUrl !== "string" || !downloadUrl.startsWith("https://")) {
        throw new Error("No video download was returned for that link.");
      }
      await sendVideo(ctx, downloadUrl, result.title || "YouTube video",
        result.duration, result.quality || "Available");
    }
  },
  {
    name: "ytsearch",
    category: "Downloads",
    description: "Search YouTube and list matching videos.",
    run: async ctx => {
      const query = String(ctx.args || "").trim();
      if (!query) throw new Error("Usage: " + ctx.config.prefix + "ytsearch song or artist name");
      if (query.length > 200) throw new Error("Keep the search query under 200 characters.");

      await ctx.reply(unicodeBox("🔎 ʏᴏᴜᴛᴜʙᴇ sᴇᴀʀᴄʜ",
        "Query: " + query + "\n\nSubmitting the search query and retrieving matching videos from YouTube...", { footer: false }));
      const payload = await requestExternalJson("https://eliteprotech-apis.zone.id/search/ytsearch", { q: query });
      const videos = payload && payload.results && Array.isArray(payload.results.videos)
        ? payload.results.videos : [];
      if (!videos.length) throw new Error("No YouTube videos were found for that search.");

      const entries = videos.slice(0, 5).map((video, index) => {
        const title = String(video && video.title || "Untitled video").slice(0, 180);
        const author = String(video && video.author && video.author.name || "Unknown creator").slice(0, 100);
        const duration = String(video && video.duration || "Unknown");
        const views = Number(video && video.views);
        const viewText = Number.isFinite(views) && views >= 0 ? views.toLocaleString("en-US") : "Unknown";
        const uploaded = String(video && video.uploaded || "Unknown");
        let url = String(video && video.url || "");
        try {
          const parsed = new URL(url);
          if (parsed.protocol !== "https:" || !["youtube.com", "www.youtube.com", "youtu.be"].includes(parsed.hostname.toLowerCase())) {
            url = "";
          }
        } catch {
          url = "";
        }
        return [
          (index + 1) + ". *" + title.replace(/[\\*_~`]/g, "") + "*",
          "   👤 _Creator:_ " + author,
          "   ⏱️ _Duration:_ *" + duration + "*  •  👁️ _Views:_ " + viewText,
          "   🕒 _Uploaded:_ " + uploaded,
          url ? "   🔗 `" + url + "`" : ""
        ].filter(Boolean).join("\n");
      });
      await ctx.reply(unicodeBox("🔎 ʏᴏᴜᴛᴜʙᴇ sᴇᴀʀᴄʜ ʀᴇsᴜʟᴛs", entries.join("\n\n"), { footer: true }), false);
    }
  },
  {
    name: "spotify",
    category: "Downloads",
    description: "Download a Spotify track.",
    run: async ctx => {
      const url = validateHttpsUrl(getUrlArg(ctx), SPOTIFY_HOSTS, "Spotify");
      await announceDownload(ctx, "Requesting track metadata and preparing the audio download...");
      const payload = await requestApiJson("spotifydl", { url });
      const result = payload && payload.result;
      const downloadUrl = result && (result.url || result.downloadUrl);
      if (typeof downloadUrl !== "string" || !downloadUrl.startsWith("https://")) {
        throw new Error("No audio download was returned for that track.");
      }
      const title = [result.title, result.artist].filter(Boolean).join(" - ") || "Spotify track";
      await sendAudio(ctx, downloadUrl, title, result.duration, result.quality || result.extension || "MP3");
    }
  }
];
